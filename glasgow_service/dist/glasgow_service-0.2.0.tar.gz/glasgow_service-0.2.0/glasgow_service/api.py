"""FastAPI app exposing the Glasgow service over REST + WebSocket.

Run:
    uvicorn glasgow_service.api:app --host 127.0.0.1 --port 8765

Swagger UI:   http://127.0.0.1:8765/docs
ReDoc:        http://127.0.0.1:8765/redoc
OpenAPI JSON: http://127.0.0.1:8765/openapi.json
"""
import asyncio
import logging
from contextlib import asynccontextmanager

from fastapi import FastAPI, HTTPException, Depends, Query, Request, WebSocket, WebSocketDisconnect
from typing import Literal

from .service import DeviceService, DeviceBusy, DeviceNotReady
from .models  import (
    RasterRequest, VectorRequest, AdcTestRequest, DacRampRequest,
    BeamHoldRequest, ScanResult, ServiceStatus,
)
from .auth    import require_token
from . import scan_assets
from .processing_reference_api import router as processing_reference_router
from .config  import find_config_path
from .service import LOG_NAME
from AutomationPy.buildingblocks.automation_log import AutomationLog

svc: "DeviceService | None" = None

logger      = AutomationLog.GetLogger(LOG_NAME)

@asynccontextmanager
async def lifespan(app: FastAPI):
    global svc
    config_path = find_config_path()
    logger.info("Glasgow config: %s", config_path)
    svc = DeviceService(str(config_path))
    await svc.start()
    try:
        yield
    finally:
        await svc.stop()


app = FastAPI(
    title="Glasgow Device Service",
    version="0.3.0",
    description=(
        "Long-lived HTTP/WebSocket interface to a single Glasgow device.\n\n"
        "**Concurrency:** one scan at a time. Concurrent requests return 409.\n\n"
        "**Blocking REST endpoints** (`/scan/raster/run`, `/scan/vector/run`) buffer all "
        "chunks and run the same validation checks as the stand-alone pytest wet-run tests. "
        "Use these when you care about the validation report.\n\n"
        "**WebSocket endpoints** (`/scan/raster/stream`, `/scan/vector/stream`) stream chunks "
        "live; validate flag is ignored there.\n\n"
        "**Last-scan downloads** (`/scan/last/csv`, `/scan/last/figure`) serve the most "
        "recently completed scan as a CSV or matplotlib PNG. Both blocking and streaming "
        "scans populate the cache."
    ),
    lifespan=lifespan,
    openapi_tags=[
        {"name": "status", "description": "Service health, configuration defaults."},
        {"name": "scan",   "description": "Raster and vector scan execution, last-scan downloads."},
        {"name": "admin",  "description": "Lifecycle: reconnect the device."},
    ],
)


# ---------- status ---------------------------------------------------------

@app.get("/status", response_model=ServiceStatus, tags=["status"],
         summary="Current device state")
async def get_status():
    return svc.status()


@app.get("/defaults", tags=["status"],
         summary="Default scan parameters from streamData.json")
async def get_defaults():
    return svc.defaults()


app.include_router(processing_reference_router)


# ---------- raster ---------------------------------------------------------

@app.post("/scan/assets/prepare", dependencies=[Depends(require_token)], tags=["scan"])
async def prepare_scan_asset(body: dict):
    try:
        return await asyncio.to_thread(
            scan_assets.prepare, str(body.get("asset_id", "")), int(body.get("total_bytes", 0)))
    except (ValueError, TypeError) as exc:
        raise HTTPException(400, str(exc)) from exc


@app.put("/scan/assets/{asset_id}/chunk", dependencies=[Depends(require_token)], tags=["scan"])
async def append_scan_asset(asset_id: str, request: Request, offset: int = Query(..., ge=0)):
    data = bytearray()
    async for part in request.stream():
        if len(part) > scan_assets.MAX_CHUNK_BYTES - len(data):
            raise HTTPException(413, f"chunk must be at most {scan_assets.MAX_CHUNK_BYTES} bytes")
        data.extend(part)
    try:
        return await asyncio.to_thread(scan_assets.append, asset_id, offset, bytes(data))
    except ValueError as exc:
        raise HTTPException(400, str(exc)) from exc


@app.post("/scan/assets/{asset_id}/complete", dependencies=[Depends(require_token)], tags=["scan"])
async def complete_scan_asset(asset_id: str):
    try:
        return await asyncio.to_thread(scan_assets.complete_upload, asset_id)
    except (ValueError, TypeError) as exc:
        raise HTTPException(400, str(exc)) from exc

@app.post(
    "/scan/raster/run",
    response_model=ScanResult,
    tags=["scan"],
    summary="Run one raster scan (blocking); returns timing and validation report",
    responses={
        409: {"description": "Device busy — another scan is running"},
        503: {"description": "Device not ready (disconnected or error state)"},
    },
    dependencies=[Depends(require_token)],
)
async def run_raster(req: RasterRequest):
    try:
        return await svc.run_raster(req)
    except DeviceBusy as e:
        raise HTTPException(409, str(e) or "device busy")
    except DeviceNotReady as e:
        raise HTTPException(503, str(e))


@app.post(
    "/scan/dac_ramp/run",
    response_model=ScanResult,
    tags=["scan"],
    summary="Run a single-axis DAC ramp/linearity check (blocking)",
    description=(
        "Sweeps one DAC axis across its full 14-bit range while the other "
        "axis is held at `fixed_code`, mirroring upstream OBI's "
        "manual_dac_ctrl.RampControl test. Use this — not "
        "`/scan/vector/run` with the default `scan_path` — to verify DAC "
        "output against a reference OBI capture: vertical_raster's default "
        "axis order makes the slow axis look like a staircase on a scope, "
        "which is a scan-pattern artifact, not a DAC fault."
    ),
    responses={
        409: {"description": "Device busy — another scan is running"},
        503: {"description": "Device not ready (disconnected or error state)"},
    },
    dependencies=[Depends(require_token)],
)
async def run_dac_ramp(req: DacRampRequest):
    try:
        return await svc.run_dac_ramp(req)
    except DeviceBusy as e:
        raise HTTPException(409, str(e) or "device busy")
    except DeviceNotReady as e:
        raise HTTPException(503, str(e))


@app.websocket("/scan/raster/stream")
async def stream_raster(ws: WebSocket):
    """Client sends RasterRequest as JSON, then receives binary chunk frames,
    terminated by `{"event":"done","chunks":N}` or an error event.
    The validate flag in the request is ignored here; the live stream is
    cached for /scan/last/* downloads.

    With `continuous: true` (Infinite / live scan) the service keeps one
    FPGA command stream open and scans frame after frame until
    POST /scan/abort; pixels stream without a gap at frame boundaries and
    `done` is sent only after Stop (the last complete frame is cached).
    An `update_geometry` JSON control frame changes ROI coordinates on a
    following frame without closing the WebSocket or releasing the scan."""
    await _stream_scan(ws, lambda p: svc.raster_scan(RasterRequest(**p)), kind="raster")


# ---------- vector ---------------------------------------------------------

@app.post(
    "/scan/vector/run",
    response_model=ScanResult,
    tags=["scan"],
    summary="Run one vector scan (blocking); returns timing and validation report",
    description=(
        "`pattern=default` generates the selected production `scan_path` at `vector_resolution` with the requested `dwell`.\n\n"
        "`pattern=custom` consumes the `points` array (capped at 1M points per request).\n\n"
        "`pre_process=true` calls `_pre_process_chunks` before transfer and times it "
        "separately — matches the timing breakdown in your wet-run test."
    ),
    responses={
        400: {"description": "Invalid request (e.g. pattern=custom with no points)"},
        409: {"description": "Device busy"},
        503: {"description": "Device not ready"},
    },
    dependencies=[Depends(require_token)],
)
async def run_vector(req: VectorRequest):
    try:
        return await svc.run_vector(req)
    except ValueError as e:
        raise HTTPException(400, str(e))
    except DeviceBusy as e:
        raise HTTPException(409, str(e) or "device busy")
    except DeviceNotReady as e:
        raise HTTPException(503, str(e))


@app.websocket("/scan/vector/stream")
async def stream_vector(ws: WebSocket):
    """Stream vector samples; continuous scans accept in-band ROI updates.

    An `update_geometry` control frame can carry `geometry.gray_rule` to update
    bitmap simulation between passes without reconnecting.
    """
    await _stream_scan(ws, lambda p: svc.vector_scan(VectorRequest(**p)), kind="vector")


@app.websocket("/scan/dac_ramp/stream")
async def stream_dac_ramp(ws: WebSocket):
    """Live counterpart of /scan/dac_ramp/run, for the Vector panel's
    DAC Ramp toggle. Same frame shape as /scan/raster/stream and
    /scan/vector/stream (binary uint16-BE sample chunks, then a
    `{"event":"done",...}` control frame), so the browser side reuses
    the existing decode path."""
    await _stream_scan(ws, lambda p: svc.dac_ramp_scan(DacRampRequest(**p)))


@app.websocket("/scan/beam_hold/stream")
async def stream_beam_hold(ws: WebSocket):
    """Blank takeover diagnostic: park the beam, take over the relays and
    stream ADC samples until `duration_s` or Stop, then hand back.

    First frame is a `{"event":"metadata","sample_period_us":...}` text
    frame; then binary uint16-BE sample chunks and a `done` event, the same
    shape as /scan/dac_ramp/stream."""
    def start(p):
        req = BeamHoldRequest(**p)
        svc.check_beam_hold_allowed(req)   # hardware only: refuse before metadata
        return svc.beam_hold_scan(req), svc.beam_hold_metadata(req)
    await _stream_scan(ws, start)


@app.websocket("/adc/stream")
async def stream_adc(ws: WebSocket):
    """Stream uint16 ADC samples from the DAC-free diagnostic image."""
    await ws.accept()
    gen = None
    chunks = 0
    metadata_sent = False
    try:
        req = AdcTestRequest(**(await ws.receive_json()))
        gen = svc.adc_stream(req)
        async for chunk in gen:
            if not metadata_sent:
                await ws.send_json({
                    "event": "metadata",
                    "duration_minutes": req.duration_minutes,
                    "simulation": req.simulation,
                    "sample_bits": 14,
                    "wire_format": "uint16-be",
                })
                metadata_sent = True
            await ws.send_bytes(chunk)
            chunks += 1
        await ws.send_json({"event": "done", "chunks": chunks})
    except DeviceBusy as e:
        await ws.send_json({"event": "error", "code": "busy",
                            "detail": str(e) or "device busy"})
    except DeviceNotReady as exc:
        await ws.send_json({
            "event": "error", "code": "not_ready", "detail": str(exc),
        })
    except WebSocketDisconnect:
        pass
    except Exception as exc:
        logger.exception("ADC stream error")
        try:
            await ws.send_json({"event": "error", "message": repr(exc)})
        except Exception:
            pass
    finally:
        if gen is not None:
            await gen.aclose()
        try:
            await ws.close()
        except Exception:
            pass


@app.post("/scan/abort", tags=["scan"], dependencies=[Depends(require_token)])
async def abort_scan():
    """Signal the active FPGA command; the stream closes after safe cleanup."""
    if not svc.abort_active_scan():
        raise HTTPException(409, "no active scan")
    return {"aborted": True}


# ---------- admin ----------------------------------------------------------

@app.post("/admin/reconnect", tags=["admin"],
          summary="Drop and re-establish the USB connection",
          dependencies=[Depends(require_token)])
async def reconnect():
    await svc.reconnect()
    return svc.status()


# ---------- last-scan downloads -------------------------------------------

from fastapi import Response


@app.get("/scan/last/meta", tags=["scan"],
         summary="Metadata for the last completed scan (chunks, kind, source)")
async def get_last_meta():
    """Returns null if nothing has been scanned yet. The browser uses
    this to decide whether to enable the download buttons."""
    return svc.last_meta()


@app.get("/scan/last/csv", tags=["scan"],
        summary="Download the last scan as CSV (space-delimited uint16)",
        responses={
            404: {"description": "No scan data cached"},
        })
async def get_last_csv():
    if not svc.has_last():
        raise HTTPException(404, "no scan data cached")
    body = svc.last_csv_bytes()
    fname = svc.last_csv_filename()
    return Response(
        content=body,
        media_type="text/csv; charset=utf-8",
        headers={"Content-Disposition": f'attachment; filename="{fname}"'},
    )


@app.get("/scan/last/figure", tags=["scan"],
        summary="Download the last scan as a publication-quality PNG figure",
        responses={
            404: {"description": "No scan data cached"},
            500: {"description": "matplotlib not installed or render failed"},
        })
async def get_last_figure(
    render: Literal["native", "decimated"] = Query(
        "decimated",
        description=(
            "Vector-scan render mode. 'decimated' draws an edge x edge image "
            "(dense, fills the canvas). 'native' draws a 2048x2048 image "
            "with stride block-fill so pixel coordinates equal DAC codes. "
            "Raster scans ignore this parameter."
        ),
    ),
    view: Literal["figure", "texture"] = Query(
        "figure",
        description=(
            "'figure' includes matplotlib title/axes/colorbar. 'texture' "
            "returns only the scan image pixels, intended for the live UI panel."
        ),
    ),
):
    if not svc.has_last():
        raise HTTPException(404, "no scan data cached")
    try:
        body = svc.last_figure_png(render_mode=render, view=view)
    except ModuleNotFoundError as e:
        raise HTTPException(500, f"figure rendering needs matplotlib + numpy: {e}")
    fname = svc.last_figure_filename()
    return Response(
        content=body,
        media_type="image/png",
        headers={"Content-Disposition": f'attachment; filename="{fname}"'},
    )


# ---------- shared WS plumbing --------------------------------------------

async def _watch_client_disconnect(ws: WebSocket, owner, kind: str | None = None) -> None:
    """Stop this stream's scan as soon as its client goes away.

    The scan generator only notices a closed socket on its next send, and
    during connection set-up (bitstream load, first chunk: ~8-12 s) it sends
    nothing. Without this, a browser that restarted or navigated away left
    an unattended scan holding the device, and the next Run was rejected as
    "busy" while that scan's own result was never delivered."""
    try:
        while True:
            message = await ws.receive()
            if message.get("type") == "websocket.disconnect":
                break
            if kind and message.get("text"):
                control = None
                try:
                    import json
                    control = json.loads(message["text"])
                    if control.get("event") == "update_geometry":
                        logger.info("[%s] live geometry request id=%s diagnostics=%s",
                                    kind, control.get("id"), control.get("diagnostics"))
                        geometry = control.get("geometry", {})
                        if isinstance(geometry, dict) and "gray_rule" in geometry:
                            await asyncio.to_thread(svc.update_live_scan_geometry, kind, geometry, owner=owner)
                        else:
                            svc.update_live_scan_geometry(kind, geometry, owner=owner)
                        logger.info("[%s] live geometry accepted id=%s (queued; hardware application not acknowledged)", kind, control.get("id"))
                        await ws.send_json({"event": "geometry_updated", "id": control.get("id")})
                except (ValueError, TypeError, AttributeError) as exc:
                    logger.warning("[%s] live geometry rejected id=%s: %s", kind, control.get("id") if isinstance(control, dict) else None, exc)
                    await ws.send_json({"event": "geometry_update_error", "id": control.get("id") if isinstance(control, dict) else None, "detail": str(exc)})
    except (WebSocketDisconnect, RuntimeError):
        pass
    if svc.abort_active_scan(owner=owner):
        logger.info("scan stream client disconnected; stopping its scan")


async def _stream_scan(ws: WebSocket, make_gen, *, kind: str | None = None):
    await ws.accept()
    gen = None
    watcher = None
    chunks = 0
    try:
        payload = await ws.receive_json()
        watcher = asyncio.create_task(
            _watch_client_disconnect(ws, asyncio.current_task(), kind))
        gen = make_gen(payload)
        if isinstance(gen, tuple):
            # (generator, metadata): a stream that announces its timing first.
            gen, metadata = gen
            await ws.send_json(metadata)
        async for chunk in gen:
            await ws.send_bytes(chunk)
            chunks += 1
        await ws.send_json({"event": "done", "chunks": chunks})
    except DeviceBusy as e:
        await ws.send_json({"event": "error", "code": "busy",
                            "detail": str(e) or "device busy"})
    except DeviceNotReady as e:
        detail = str(e)
        if detail in {"", "ECONNRESET", "read ECONNRESET", "Connection reset by peer"}:
            detail = "ADC/subtarget presence check failed: device transport reset while reading; verify the physical ADC subtarget and OE/LE/data wiring"
        payload = {"event": "error", "code": "not_ready", "detail": detail}
        if detail.startswith("ADC/subtarget presence check failed:"):
            payload.update({
                "severity": "warning",
                "code": "adc_subtarget_disconnected",
                "validation": {
                    "passed": False,
                    "checks": [{
                        "name": "adc_subtarget_presence",
                        "passed": False,
                        "detail": detail,
                    }],
                },
            })
        await ws.send_json(payload)
    except WebSocketDisconnect:
        pass
    except Exception as e:
        logger.exception("stream error")
        try: await ws.send_json({"event": "error", "message": repr(e)})
        except Exception: pass
    finally:
        if watcher is not None:
            watcher.cancel()
        if gen is not None:
            await gen.aclose()
        try: await ws.close()
        except Exception: pass
