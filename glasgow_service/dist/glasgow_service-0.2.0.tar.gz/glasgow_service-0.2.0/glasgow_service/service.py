"""Hardware-facing service. Lazy single-connection model.

Lifecycle decisions and the reasoning behind them:

* We do NOT connect to the Glasgow during uvicorn lifespan startup.
  IobeamLauncher.run() flashes the FPGA, opens the applet run gate, and
  pipelines 16 reads on the IN endpoint. Sitting in that armed-but-idle
  state for tens of seconds (while the user navigates Swagger) causes the
  FX2 FIFO state to go stale and the next bulk_write fails with
  "device disconnected". Connecting on the first scan request mirrors the
  pattern used by tests/test_raster.py, which works.

* Once connected, we KEEP the connection across requests. The library's
  Connection._disconnect() only nulls a Python reference; it does not
  release the USB interface, cancel demultiplexer tasks, or close the FX2
  handle. So opening a second GlasgowConnection while a previous one is
  still alive results in libusb LIBUSB_ERROR_BUSY on claimInterface(0).
  Reusing the same connection avoids that entirely.

* On any USB-related exception during transfer_multiple, we drop our
  reference to the connection so the NEXT request opens a fresh one. This
  recovers from transient USB drops without needing /admin/reconnect.

* /admin/reconnect just nulls the connection reference. Because the library
  has no clean teardown path, the previous USB handle hangs around until
  Python GCs it. If the very next reconnect fires before that GC happens,
  it can fail with LIBUSB_ERROR_BUSY. If that happens repeatedly, restart
  the uvicorn process.
"""
import asyncio
import concurrent.futures
import copy
import array
import csv
from collections import deque
import io
import itertools
import math
import sys
import time
from pathlib import Path
from typing import AsyncIterator, Iterable, List, Optional, Tuple

import numpy as np

from GlasgowDataIO.IobeamControl.macros import RasterScanCommand
from GlasgowDataIO.IobeamControl.macros.vector import (
    AdaptiveGrayFeedbackConfig, VectorScanCommand,
)
from GlasgowDataIO.IobeamControl.commands import DACCodeRange
from GlasgowDataIO.IobeamControl.commands.structs import OutputMode, BeamType
from GlasgowDataIO.IobeamControl.applet.adcTiming import AdcTiming
from GlasgowDataIO.IobeamControl.transfer.glasgowStream import GlasgowConnection
from GlasgowDataIO.IobeamControl.transfer.adcStream import AdcConnection

from AutomationPy.buildingblocks.automation_config import AutomationConfig
from AutomationPy.buildingblocks.definitions import Consts
import AutomationPy.buildingblocks.utils as util
from AutomationPy.buildingblocks.automation_log import AutomationLog
# Single source of truth for scan parameters — see the module docstring
# in scan_params.py for the design notes. JSON config → params, then
# request → params.override(...) → macro.
from AutomationPy.buildingblocks.scan_params import RasterParams, VectorParams

from .device_lock import DeviceHeld, DeviceLock
from .roi_scaling import dac_step, roi_zoom
from GlasgowDataIO.IobeamControl.transfer.linkStats import LinkStats
from .exposure_lattice_adapter import lattice_stream
from .models import (
    DeviceState, ServiceStatus, RasterRequest, VectorRequest, AdcTestRequest,
    DacRampRequest, DacRampAxis, BeamHoldRequest, BeamHoldState,
    VectorPattern, VectorScanPath, ROIRequest, SimulationBitmapPixel,
    ScanResult, ScanValidation, ValidationCheck,
)

LOG_NAME = r'GlasgowService'
logger      = AutomationLog.GetLogger(LOG_NAME)

class DeviceBusy(RuntimeError):     ...
class DeviceNotReady(RuntimeError): ...


# A disconnected revC3 ADC bus is pulled high and therefore reads as full
# scale forever. The normal SixteenBit stream is OBI-compatible left-aligned
# raw14 (0xfffc); EightBit output is its high byte (0xff). Raw right-aligned
# values remain accepted for diagnostics and older captures.
_ADC_FULL_SCALE_VALUES = frozenset((0x3FFF, 0xFFFC, 0xFF, 0x3F))

# The gateware sends every scan sample the way OBI does: the 14-bit ADC code
# left-aligned in 16 bits (code << 2, full scale 0xFFFC). All four hardware-free
# simulators must produce the same convention, or the same input would look
# four times darker through one of them. Use these helpers, not an inline shift.
_OBI_SAMPLE_SHIFT = 2


def _obi_aligned_int(raw14: int) -> int:
    """One raw 14-bit ADC code -> the 16-bit value the gateware sends."""
    return int(raw14) << _OBI_SAMPLE_SHIFT


def _obi_aligned_np(raw14):
    """Raw 14-bit ADC codes (numpy) -> uint16 values as the gateware sends them."""
    import numpy as np
    return (np.asarray(raw14, dtype=np.uint32) << _OBI_SAMPLE_SHIFT).astype(np.uint16)

_ADC_PRESENCE_MIN_SAMPLES = 256
_ADC_DIAGNOSTIC_UNIQUE_LIMIT = 64
# A scan whose Stop was already requested (operator Stop, or the browser
# closing its stream) is only finishing its hardware cleanup. A new scan that
# arrives in that window waits this long for the lock instead of failing with
# "busy": gateware load cannot be interrupted, so cleanup can take ~10 s.
_BUSY_WAIT_AFTER_ABORT_S = 20.0

# One worker serialises DumpData writes (matplotlib's pyplot is not
# thread-safe) and keeps them off the event loop and the device lock.
_DUMP_EXECUTOR = concurrent.futures.ThreadPoolExecutor(
    max_workers=1, thread_name_prefix="dumpdata")
_ADC_FULL_SCALE_ARRAY = np.array(sorted(_ADC_FULL_SCALE_VALUES), dtype=np.int64)


def _chunk_as_array(chunk) -> "np.ndarray":
    """Numeric view of a sample chunk (array('H'/'B'), bytes, ndarray or list)."""
    if isinstance(chunk, (bytes, bytearray, memoryview)):
        return np.frombuffer(chunk, dtype=np.uint8)
    return np.asarray(chunk)


def _prefix_blocks(size: int, first: int = 4096):
    """Yield growing [start, stop) blocks covering 0..size (4 Ki, 8 Ki, 16 Ki, ...)."""
    start, width = 0, first
    while start < size:
        stop = min(size, start + width)
        yield start, stop
        start, width = stop, width * 2


def _leading_full_scale_run(values: "np.ndarray") -> int:
    """Length of the leading run of full-scale samples (examines only what it needs)."""
    for start, stop in _prefix_blocks(values.size):
        block = values[start:stop]
        non_full = np.flatnonzero(~np.isin(block, _ADC_FULL_SCALE_ARRAY))
        if non_full.size:
            return start + int(non_full[0])
    return int(values.size)


def _collect_first_distinct(values: "np.ndarray", seen: set, limit: int) -> None:
    """Add distinct values to ``seen`` in first-occurrence order until it holds ``limit``."""
    for start, stop in _prefix_blocks(values.size, first=256):
        block = values[start:stop]
        distinct, first_index = np.unique(block, return_index=True)
        for value in distinct[np.argsort(first_index, kind="stable")]:
            if len(seen) >= limit:
                return
            seen.add(int(value))
        if len(seen) >= limit:
            return


def _simulated_pass_samples(kind: str, req) -> int:
    """Samples in one simulated frame (raster) or pass (vector)."""
    if kind == "raster":
        return req.resolution * req.resolution * len(req.parallel_rois or [None])
    if req.pattern is VectorPattern.custom and req.points is not None:
        return len(req.points)
    if req.pattern is VectorPattern.lattice:
        return lattice_stream(req)[1]
    bitmap = getattr(req, "simulation_bitmap", None)
    if req.pattern is VectorPattern.custom and bitmap is not None:
        return int(bitmap.width) * int(bitmap.height)
    return req.vector_resolution * req.vector_resolution * len(req.parallel_rois or [None])


class _FrameRing:
    """Chunk capture for a continuous (live) raster stream.

    A live scan never ends on its own, so keeping every chunk (as the
    single-frame path does for /scan/last/*) would grow without bound.
    This keeps only the chunks of the frame in progress plus the last
    complete frame. ``frame()`` returns the last complete frame, or the
    partial first frame if Stop came before one finished.

    Chunk boundaries always coincide with frame boundaries (each frame is
    chunked independently), so counting pixels is enough to find them.
    """

    def __init__(self, frame_pixels: int):
        self.frame_pixels = max(1, int(frame_pixels))
        self._current: List = []
        self._current_pixels = 0
        self._last: Optional[List] = None
        self.frames_completed = 0

    def append(self, chunk) -> None:
        self._current.append(chunk)
        self._current_pixels += len(chunk)
        if self._current_pixels >= self.frame_pixels:
            self._last = self._current
            self._current = []
            self._current_pixels = 0
            self.frames_completed += 1

    def frame(self) -> List:
        return self._last if self._last is not None else list(self._current)

    def __len__(self) -> int:
        return len(self.frame())


class _AdcPresenceMonitor:
    """Detect the disconnected-bus signature while samples are streaming."""

    def __init__(self, *, enabled: bool,
                 minimum_samples: int = _ADC_PRESENCE_MIN_SAMPLES):
        self.enabled = enabled
        self.minimum_samples = minimum_samples
        self.full_scale_samples = 0
        self.conclusive = False
        self.sample_count = 0
        self.minimum = None
        self.maximum = None
        self.first_samples = []
        self.unique_values = set()

    def observe(self, chunk) -> Optional[str]:
        """Update diagnostics with ``chunk``; return a fault message on the
        disconnected-bus signature.

        Vectorised with numpy. The previous per-sample Python loop ran on the
        event loop that also services USB, costing ~0.27 us per sample
        (~1.1 s per 2048x2048 frame), which stalled the FPGA FIFO. The results
        are identical to that loop, including the early return: when the fault
        fires mid-chunk, only the samples up to and including the one that
        completed the full-scale run are counted.
        """
        if not self.enabled:
            return None
        values = _chunk_as_array(chunk)
        if values.size == 0:
            return None

        fault = None
        if not self.conclusive:
            leading = _leading_full_scale_run(values)
            needed = self.minimum_samples - self.full_scale_samples
            if leading >= needed:
                # The run of full-scale samples reaches the threshold inside
                # this chunk: the loop returned right after that sample.
                values = values[:needed]
                self.full_scale_samples += needed
                self.conclusive = True
                fault = (
                    "ADC/subtarget presence check failed: the first "
                    f"{self.full_scale_samples} returned samples were all full "
                    "scale (0xfffc/0x3fff/0xff). This establishes constant "
                    "full-scale data, not its cause; check scan capture timing "
                    "and compare with an independent ADC capture."
                )
            else:
                self.full_scale_samples += leading
                if leading < values.size:
                    # Presence is established for this scan; later chunks and
                    # ordinary clipped regions are not re-examined.
                    self.conclusive = True

        self.sample_count += int(values.size)
        low, high = int(values.min()), int(values.max())
        self.minimum = low if self.minimum is None else min(self.minimum, low)
        self.maximum = high if self.maximum is None else max(self.maximum, high)
        if len(self.first_samples) < 8:
            self.first_samples.extend(int(v) for v in values[:8 - len(self.first_samples)])
        if len(self.unique_values) < _ADC_DIAGNOSTIC_UNIQUE_LIMIT:
            _collect_first_distinct(values, self.unique_values, _ADC_DIAGNOSTIC_UNIQUE_LIMIT)
        return fault

    def summary(self) -> Optional[str]:
        if not self.enabled or not self.sample_count:
            return None
        unique = len(self.unique_values)
        unique_suffix = ">=" if unique >= _ADC_DIAGNOSTIC_UNIQUE_LIMIT else ""
        first = ",".join(f"0x{value:x}" for value in self.first_samples)
        return (
            "ADC sample summary: samples=%d min=0x%x max=0x%x unique=%s%d "
            "full_scale=%d first=[%s]"
            % (self.sample_count, self.minimum, self.maximum, unique_suffix,
               unique, self.full_scale_samples, first)
        )


def _production_adc_fault(chunks: Iterable, *, minimum_samples: int = _ADC_PRESENCE_MIN_SAMPLES) -> Optional[str]:
    """Return a diagnostic as soon as a scan looks like an undriven bus.

    Requiring a sustained, exact full-scale run avoids classifying ordinary
    images containing a few clipped pixels as disconnected.  Very small
    diagnostic scans are intentionally left alone because they do not provide
    enough evidence for a hardware-presence decision.
    """
    monitor = _AdcPresenceMonitor(
        enabled=True, minimum_samples=minimum_samples)
    for chunk in chunks:
        fault = monitor.observe(chunk)
        if fault is not None:
            return fault
    return None


def _assert_production_adc_present(config, chunks: Iterable) -> None:
    if _simulation_enabled(config):
        return
    fault = _production_adc_fault(chunks)
    if fault is not None:
        raise DeviceNotReady(fault)


def _default_vector_iter(edge: int = 2048, dwell: int = 1) -> Iterable[Tuple[int, int, int]]:
    """Yield (x, y, dwell) triples for a default sweep at the given edge
    resolution. Coverage is always the full 14-bit DAC range; smaller
    edge values produce sparser sampling. Custom edge counts are
    distributed as evenly as possible across the full range."""
    x_range = DACCodeRange.from_resolution(edge)
    y_range = DACCodeRange.from_resolution(edge)
    for x_idx in range(edge):
        x = x_range.start + ((x_idx * x_range.step) >> 8)
        for y_idx in range(edge):
            y = y_range.start + ((y_idx * y_range.step) >> 8)
            yield x, y, dwell


# Host-link pacing.
#
# The macros send a scan as chunks and flush the USB OUT pipe after every
# chunk. On the VirtualBox install each chunk costs milliseconds of host/USB
# time (the scope showed ~9 ms flat steps; the 2026-09-23 vector scan
# averaged ~51 ms wall time per chunk including init and dumps), while one
# 8196-dwell chunk is only ~1.1 ms of beam time. The FPGA then executes a
# burst, runs dry and parks the beam until the next chunk lands: the DAC
# shows short ramps separated by flat steps (4 per 2048-point line at 513
# points/chunk) instead of OBI's continuous sawtooth. Upstream OBI avoids
# this by sending a frame as one chunk (latency=65536*65536).
#
# Whether the per-chunk cost is the OUT flush, IN reads or host processing is
# not yet measured; the macros log a "[link]" summary at the end of every
# scan that splits the time up (see transfer/linkStats.py).
#
# Each chunk must therefore carry more beam time than one flush costs. The
# requested latency stays a lower bound; it is raised to cover
# `minChunkBeamTimeMs` (rasterScan / vectorScan in streamData.json).
FPGA_CLOCK_HZ                    = 48_000_000
DEFAULT_MIN_CHUNK_BEAM_TIME_MS   = 100.0
# Streamed vector points cost 6 bytes each on the OUT pipe; cap one chunk so
# max_pipeline chunks in flight stay well under the ~1.5 MB where bulk writes
# were seen to stall (see VectorScanCommand.transfer).
VECTOR_MAX_CHUNK_POINTS          = 32_768


def _session_frames(req, continuous: bool) -> Optional[int]:
    """Repeat N: frame/pass count for a live session, or None (until Stop).

    Only meaningful on the streaming path with ``continuous``; a blocking
    run or a single-frame stream always scans exactly once."""
    frames = getattr(req, "frames", None)
    return int(frames) if continuous and frames is not None else None


def _command_dwell(cmd) -> int:
    """Dwell the command will run with (raster commands store it; vector
    commands carry it per point, so their effective default is used)."""
    dwell = getattr(cmd, "_dwell", None)
    if dwell is None:
        dwell = getattr(cmd, "link_dwell", None)
    return max(1, int(dwell if dwell is not None else 1))


def _link_chunk_latency(requested: int, dwell: int, conversion_hz: float,
                        min_chunk_ms: float, max_points: Optional[int] = None) -> int:
    """Latency (sum of dwell values per chunk, the macros' unit) such that
    one chunk keeps the FPGA busy for at least `min_chunk_ms`.

    A pixel with dwell d takes d + 1 ADC conversions. `requested` is kept as
    a lower bound so explicit larger values still win."""
    requested = max(1, int(requested))
    if min_chunk_ms <= 0 or conversion_hz <= 0:
        return requested
    dwell = max(0, int(dwell))
    pixels = math.ceil((min_chunk_ms / 1000.0) * conversion_hz / (dwell + 1))
    if max_points is not None:
        pixels = min(pixels, int(max_points))
    return max(requested, pixels * max(1, dwell))


def _roi_bounds(roi) -> Optional[Tuple[int, int, int, int]]:
    if roi is None:
        return None
    x0, x1 = sorted((int(roi.x_start), int(roi.x_end)))
    y0, y1 = sorted((int(roi.y_start), int(roi.y_end)))
    return x0, x1, y0, y1


def _dac_range_for_bounds(start: int, end: int, count: int) -> DACCodeRange:
    lo, _hi = sorted((int(start), int(end)))
    return DACCodeRange(start=lo, count=count, step=dac_step(start, end, count))


def _roi_vector_iter(
    edge: int,
    roi,
    dwell: int = 1,
    scan_path: VectorScanPath = VectorScanPath.vertical_raster,
) -> Iterable[Tuple[int, int, int]]:
    bounds = _roi_bounds(roi)
    if bounds is None:
        x0, x1, y0, y1 = 0, 16383, 0, 16383
    else:
        x0, x1, y0, y1 = bounds
    x_range = _dac_range_for_bounds(x0, x1, edge)
    y_range = _dac_range_for_bounds(y0, y1, edge)
    xs = [x_range.start + ((idx * x_range.step) >> 8) for idx in range(edge)]
    ys = [y_range.start + ((idx * y_range.step) >> 8) for idx in range(edge)]

    if scan_path in (VectorScanPath.horizontal_sawtooth, VectorScanPath.horizontal_triangle):
        for y_idx, y in enumerate(ys):
            row_xs = reversed(xs) if scan_path is VectorScanPath.horizontal_triangle and y_idx % 2 else xs
            for x in row_xs:
                yield x, y, dwell
        return

    for x_idx, x in enumerate(xs):
        column_ys = reversed(ys) if scan_path is VectorScanPath.vertical_serpentine and x_idx % 2 else ys
        for y in column_ys:
            yield x, y, dwell


def _parallel_roi_iter(edge, regions, dwell, scan_path):
    """Round-robin matching scan-path positions across selected ROIs."""
    paths = [
        _roi_vector_iter(edge, region, dwell=dwell, scan_path=scan_path)
        for region in regions
    ]
    return itertools.chain.from_iterable(zip(*paths))


def _normalize_vector_point(
    point,
) -> Tuple[int, int, int, Optional[bool], Optional[int]]:
    if isinstance(point, tuple) or isinstance(point, list):
        if len(point) < 3:
            raise ValueError("vector point tuples must have at least 3 entries")
        blank = None if len(point) < 4 or point[3] is None else bool(point[3])
        pass_index = None if len(point) < 5 or point[4] is None else int(point[4])
        return int(point[0]), int(point[1]), int(point[2]), blank, pass_index

    x = getattr(point, "x", None)
    y = getattr(point, "y", None)
    dwell = getattr(point, "dwell", None)
    if x is None or y is None or dwell is None:
        raise ValueError("vector points must provide x, y, and dwell")
    blank = getattr(point, "blank", None)
    pass_index = getattr(point, "passIndex", None)
    return (
        int(x),
        int(y),
        int(dwell),
        None if blank is None else bool(blank),
        None if pass_index is None else int(pass_index),
    )


def _log_vector_point_flags(points) -> None:
    if not points:
        return
    blank_true = 0
    blank_false = 0
    blank_none = 0
    pass_one = 0
    pass_two = 0
    other_pass = 0
    for point in points:
        _x, _y, _dwell, blank, pass_index = _normalize_vector_point(point)
        if blank is True:
            blank_true += 1
        elif blank is False:
            blank_false += 1
        else:
            blank_none += 1
        if pass_index == 1:
            pass_one += 1
        elif pass_index == 2:
            pass_two += 1
        elif pass_index is not None:
            other_pass += 1
    logger.debug(
        "[vector] custom point flags total=%d blank_true=%d blank_false=%d "
        "blank_none=%d pass1=%d pass2=%d pass_other=%d",
        len(points), blank_true, blank_false, blank_none,
        pass_one, pass_two, other_pass,
    )


# Exception types that indicate the USB connection is dead and we should
# drop our reference so the next request reconnects. Matched by name to
# avoid importing classes that might not be public.
_FATAL_EXC_NAMES = {
    "GlasgowDeviceError",     # "device disconnected"
    "USBError", "USBErrorBusy", "USBErrorNoDevice", "USBErrorIO",
    "ConnectionError", "ConnectionResetError", "BrokenPipeError", "TimeoutError",
}


def _is_fatal_usb_error(exc: BaseException) -> bool:
    return type(exc).__name__ in _FATAL_EXC_NAMES


def _raster_image_from_chunks(chunks, res, dwell, adc_latency):
    """Assemble raster chunks into a (Y, X) image, one row per scan line.

    The FPGA emits raster pixels row-major with X as the fast axis. That is the
    order the frontend canvas, ``scan_display`` and upstream OBI's frame buffer
    all assume, so the frame is a plain reshape. This function used to
    transpose the frame on the assumption of a column-major stream, which made
    the PNG disagree with the on-screen image (verified end to end against the
    gateware: the stream is row-major).

    The per-row latency correction below is unchanged: each row is rolled by
    ``y * (adc_latency - 1) / dwell`` pixels. It now acts on true scan lines.
    """
    import numpy as np
    total = res * res
    flat = np.fromiter(
        (v for chunk in chunks for v in chunk),
        dtype=np.uint16,
        count=total if sum(len(c) for c in chunks) >= total else -1,
    )
    # If the scan was truncated (paused mid-frame), pad with zeros
    # so reshape works; downstream display tools tolerate zeros.
    if flat.size < total:
        flat = np.concatenate([flat, np.zeros(total - flat.size, dtype=np.uint16)])
    else:
        flat = flat[:total]
    img = flat.reshape(res, res)
    line_shift_per_row = ((adc_latency - 1) / dwell) if dwell else 0
    if line_shift_per_row:
        corrected = np.empty_like(img)
        for y in range(res):
            corrected[y] = np.roll(img[y], int(round(y * line_shift_per_row)))
        img = corrected
    return img


# Figure auto-levels trim this share of pixels at each end (matches the web
# wedge's automatic levels).
_FIGURE_CLIP_LO_PCT = 0.5
_FIGURE_CLIP_HI_PCT = 99.5


def _percentile_clip_uint16(values, lo_pct: float = 1.0, hi_pct: float = 99.0):
    """Return (lo, hi) cut-off values for percentile-based display
    auto-leveling. Pure helper, used by the matplotlib figure renderer
    to set imshow's vmin/vmax. numpy is imported lazily by the caller.

    Returns (0, 1) when given an empty array, so downstream imshow
    doesn't error. When all values are equal, returns (v, v+1) so the
    image renders as uniform mid-gray rather than blowing up the
    color-mapper.
    """
    import numpy as np
    arr = np.asarray(values)
    if arr.size == 0:
        return 0, 1
    lo = int(np.percentile(arr, lo_pct))
    hi = int(np.percentile(arr, hi_pct))
    if hi <= lo:
        hi = lo + 1
    return lo, hi


def _sample_chunk_to_wire_bytes(chunk) -> bytes:
    """Return sample bytes for WebSocket frames.

    SixteenBit chunks are array('H') numeric values, so normalize them to
    explicit big-endian bytes. EightBit chunks are array('B') values and
    already match the ImageSerializer wire contract: one byte per pixel.
    """
    if isinstance(chunk, (bytes, bytearray, memoryview)):
        return bytes(chunk)
    if isinstance(chunk, array.array) and chunk.typecode == "B":
        return chunk.tobytes()
    out = array.array("H", chunk)
    if sys.byteorder == "little":
        out.byteswap()
    return out.tobytes()


def _simulation_enabled(config) -> bool:
    return not bool(getattr(config, "IsProduction", True))


def _production_adc_monitor_enabled(config, adc_valid: bool = True) -> bool:
    """Enable the ADC monitor only for production scans that request it."""
    return bool(adc_valid) and not _simulation_enabled(config)


def _bitmap_sample(bitmap, x_norm: float, y_norm: float) -> int:
    x_norm = min(1.0, max(0.0, x_norm if math.isfinite(x_norm) else 0.0))
    y_norm = min(1.0, max(0.0, y_norm if math.isfinite(y_norm) else 0.0))
    x = min(bitmap.width - 1, max(0, round(x_norm * (bitmap.width - 1))))
    y = min(bitmap.height - 1, max(0, round(y_norm * (bitmap.height - 1))))
    return _bitmap_pixel_sample(bitmap.pixels[y * bitmap.width + x], None)


def _bitmap_sample_point(bitmap, roi, x: int, y: int, transforms=None) -> int:
    if roi is None:
        x_norm, y_norm = x / 0x3FFF, y / 0x3FFF
    else:
        x0, x1 = sorted((int(roi.x_start), int(roi.x_end)))
        y0, y1 = sorted((int(roi.y_start), int(roi.y_end)))
        x_norm = (int(x) - x0) / max(1, x1 - x0)
        y_norm = (int(y) - y0) / max(1, y1 - y0)
    return _bitmap_sample(bitmap, x_norm, y_norm)


def _bitmap_pixel_value(pixel) -> int:
    if isinstance(pixel, int):
        return int(pixel)
    if pixel is None:
        return 0
    return int(getattr(pixel, "value", 0))


def _bitmap_pixel_is_highlighted(pixel) -> bool:
    if isinstance(pixel, int) or pixel is None:
        return False
    return bool(getattr(pixel, "isHighlighted", False))


def _bitmap_pixel_is_skipped(pixel):
    if isinstance(pixel, int) or pixel is None:
        return None
    value = getattr(pixel, "isSkipped", None)
    if value is None:
        return None
    return bool(value)


def _bitmap_pixel_blank(pixel):
    if isinstance(pixel, int) or pixel is None:
        return None
    value = getattr(pixel, "blank", None)
    if value is None:
        return None
    return bool(value)


def _infer_bitmap_mode(bitmap) -> Optional[str]:
    for pixel in bitmap.pixels:
        skipped = _bitmap_pixel_is_skipped(pixel)
        if skipped is not None:
            return "splash" if skipped is False else "skip"
    for pixel in bitmap.pixels:
        if _bitmap_pixel_is_highlighted(pixel):
            return "skip"
    return None


def _bitmap_pixel_sample(pixel, mode: Optional[str]) -> int:
    value = min(_bitmap_pixel_value(pixel) * 64, 0x3FFF)
    blank = _bitmap_pixel_blank(pixel)
    if blank is not None:
        return 0 if blank else value
    skipped = _bitmap_pixel_is_skipped(pixel)
    highlighted = _bitmap_pixel_is_highlighted(pixel)

    if mode == "skip":
        return 0 if skipped is True or (skipped is None and highlighted) else value
    if mode == "splash":
        return value if skipped is False else 0
    return 0 if skipped is True or highlighted else value


def _bitmap_pixel_at(bitmap, x_norm: float, y_norm: float):
    x_norm = min(1.0, max(0.0, x_norm if math.isfinite(x_norm) else 0.0))
    y_norm = min(1.0, max(0.0, y_norm if math.isfinite(y_norm) else 0.0))
    x = min(bitmap.width - 1, max(0, round(x_norm * (bitmap.width - 1))))
    y = min(bitmap.height - 1, max(0, round(y_norm * (bitmap.height - 1))))
    return bitmap.pixels[y * bitmap.width + x]


def _interleave_roi_chunks(parts, samples_per_chunk: int):
    sample_counts = [sum(len(chunk) for chunk in part) for part in parts]
    if len(set(sample_counts)) > 1:
        raise ValueError("parallel simulation bitmaps must produce equal sample counts")
    if not parts or not sample_counts[0]:
        return []
    # Fill columns in native code instead of creating one Python tuple per
    # matching ROI pixel. Row-major flattening preserves the wire order.
    samples = np.empty((sample_counts[0], len(parts)), dtype=np.uint16)
    for region, chunks in enumerate(parts):
        offset = 0
        for chunk in chunks:
            samples[offset:offset + len(chunk), region] = np.asarray(chunk)
            offset += len(chunk)
    flat = samples.reshape(-1)
    chunk_size = max(len(parts), math.ceil(max(1, samples_per_chunk) / len(parts)) * len(parts))
    return [array.array("H", flat[start:start + chunk_size].tobytes())
            for start in range(0, len(flat), chunk_size)]


def _bitmap_sample_grid(bitmap, mode=None):
    """Convert bitmap flags and intensity once, rather than for every visit."""
    if mode is None:
        mode = _infer_bitmap_mode(bitmap)
    return np.fromiter(
        (_obi_aligned_int(_bitmap_pixel_sample(pixel, mode)) for pixel in bitmap.pixels),
        dtype=np.uint16, count=len(bitmap.pixels),
    ).reshape(bitmap.height, bitmap.width)


def _target_gray_step_bitmap(bitmap, roi, target: int, steps: int = 1, gray_range=None, skipped=None) -> None:
    """Advance one simulated ROI pass using the old ROI tab's two-level step."""
    source = _roi_bounds(bitmap.source_roi) or (0, 16383, 0, 16383)
    selected = _roi_bounds(roi) or source
    sx0, sx1, sy0, sy1 = source
    rx0, rx1, ry0, ry1 = selected
    x0 = max(0, min(bitmap.width, math.floor((rx0 - sx0) * bitmap.width / max(1, sx1 - sx0))))
    x1 = max(x0, min(bitmap.width, math.ceil((rx1 - sx0) * bitmap.width / max(1, sx1 - sx0))))
    y0 = max(0, min(bitmap.height, math.floor((ry0 - sy0) * bitmap.height / max(1, sy1 - sy0))))
    y1 = max(y0, min(bitmap.height, math.ceil((ry1 - sy0) * bitmap.height / max(1, sy1 - sy0))))
    for y in range(y0, y1):
        for x in range(x0, x1):
            index = y * bitmap.width + x
            pixel = bitmap.pixels[index]
            if isinstance(pixel, SimulationBitmapPixel) and pixel.isSkipped is True:
                continue
            value = _bitmap_pixel_value(pixel)
            spot_range = gray_range is not None and skipped is False
            if (value == target if spot_range else value <= target):
                continue
            if gray_range is not None:
                inside = min(gray_range) <= value <= max(gray_range)
                if (inside if skipped is True else not inside):
                    continue
            delta = 2 * max(1, steps)
            next_value = min(target, value + delta) if spot_range and value < target else max(target, value - delta)
            if isinstance(pixel, int):
                bitmap.pixels[index] = next_value
            else:
                pixel.value = next_value
                if next_value <= target and not spot_range:
                    pixel.isHighlighted = True
                    pixel.isSkipped = True
                    pixel.blank = True


def _target_gray_chunk(chunk, req, offset: int, steps: int):
    """Fade acquired ROI samples at the preview's 60 Hz, two-level cadence."""
    # Spot ranges advance the source bitmap per pass; do not fade blanked samples.
    if req.gray_level_range is not None and req.gray_level_skipped is False:
        return chunk
    if steps <= 0 or req.target_gray_level is None:
        return chunk
    values = np.asarray(chunk, dtype=np.uint16).astype(np.int32)
    target = req.target_gray_level * 256
    processed = np.where(values > target, np.maximum(target, values - 512 * min(128, steps)), values)
    regions = req.parallel_rois or [req.roi]
    if len(regions) > 1 and _roi_bounds(regions[0]) == (0, 16383, 0, 16383):
        # Composite scans interleave the untouched background with the ROI(s).
        background = (np.arange(len(values)) + offset) % len(regions) == 0
        processed[background] = values[background]
    return array.array("H", processed.astype(np.uint16).tobytes())


def _regular_vector_coordinates(edge, roi, scan_path, indices):
    x0, x1, y0, y1 = _roi_bounds(roi) or (0, 16383, 0, 16383)
    xr = _dac_range_for_bounds(x0, x1, edge)
    yr = _dac_range_for_bounds(y0, y1, edge)
    slow, fast = indices // edge, indices % edge
    if scan_path in (VectorScanPath.horizontal_triangle, VectorScanPath.vertical_serpentine):
        fast = np.where(slow % 2, edge - 1 - fast, fast)
    if scan_path in (VectorScanPath.horizontal_sawtooth, VectorScanPath.horizontal_triangle):
        xi, yi = fast, slow
    else:
        xi, yi = slow, fast
    return xr.start + ((xi * xr.step) >> 8), yr.start + ((yi * yr.step) >> 8)


def _bitmap_raster_chunks(req: RasterRequest, transforms=None, _grids=None) -> Optional[List[array.array]]:
    _grids = {} if _grids is None else _grids
    if req.parallel_rois and req.parallel_simulation_bitmaps:
        if len(req.parallel_rois) != len(req.parallel_simulation_bitmaps):
            raise ValueError("parallel_simulation_bitmaps must match parallel_rois")
        parts = []
        for region, bitmap in zip(req.parallel_rois, req.parallel_simulation_bitmaps):
            part = _bitmap_raster_chunks(req.model_copy(update={
                "roi": region, "parallel_rois": None,
                "simulation_bitmap": bitmap, "parallel_simulation_bitmaps": None,
            }), transforms, _grids)
            if part is None:
                return None
            parts.append(part)
        return _interleave_roi_chunks(
            parts, math.ceil(req.latency_bytes / max(1, req.dwell)))
    bitmap = getattr(req, "simulation_bitmap", None)
    if bitmap is None or not bitmap.pixels:
        return None

    key = id(bitmap)
    if key not in _grids:
        _grids[key] = _bitmap_sample_grid(bitmap)
    grid = _grids[key]

    pixels_per_chunk = max(1, math.ceil(req.latency_bytes / req.dwell))
    total = req.resolution * req.resolution
    chunks: List[array.array] = []
    source_bounds = _roi_bounds(bitmap.source_roi) if bitmap.source_roi else None
    scan_bounds = _roi_bounds(req.roi) if req.roi else None
    for start in range(0, total, pixels_per_chunk):
        idx = np.arange(start, min(start + pixels_per_chunk, total), dtype=np.int64)
        if source_bounds:
            scan_x0, scan_x1, scan_y0, scan_y1 = scan_bounds or (0, 16383, 0, 16383)
            source_x0, source_x1, source_y0, source_y1 = source_bounds
            scan_x = scan_x0 + (idx % req.resolution) * (scan_x1 - scan_x0) / max(1, req.resolution - 1)
            scan_y = scan_y0 + (idx // req.resolution) * (scan_y1 - scan_y0) / max(1, req.resolution - 1)
            xs = np.rint(np.clip((scan_x - source_x0) / max(1, source_x1 - source_x0), 0, 1) * (bitmap.width - 1)).astype(np.int64)
            ys = np.rint(np.clip((scan_y - source_y0) / max(1, source_y1 - source_y0), 0, 1) * (bitmap.height - 1)).astype(np.int64)
        else:
            xs = np.rint((idx % req.resolution) / max(1, req.resolution - 1) * (bitmap.width - 1)).astype(np.int64)
            ys = np.rint((idx // req.resolution) / max(1, req.resolution - 1) * (bitmap.height - 1)).astype(np.int64)
        chunks.append(array.array("H", grid[ys, xs].tobytes()))
    return chunks


# ---------------------------------------------------------------------------
# Hardware-free simulation
# ---------------------------------------------------------------------------
# With IsProduction=false and simulation enabled, a scan must not touch a
# Glasgow at all. It must still *be* a scan: the same lock and abort handling as
# a real one, and chunks delivered one at a time as the frame is "acquired",
# because the frontend paints its live canvas from that chunk stream.
#
# Pixel values come from the same source that feeds the FPGA's FakeAdcSimulator
# (GlasgowDataIO/IobeamControl/applet/imageSource.py), addressed by DAC code the
# way the gateware does it, so a simulated frame equals what the fake ADC would
# have returned.

_SIM_DEFAULT_CHUNK_INTERVAL_S = 0.02


class _SimulatedCommand:
    """Stand-in for a scan macro: the service only needs its abort event."""

    def __init__(self) -> None:
        self.abort = asyncio.Event()
        self.continuous = False
        self._geometry_revision = 0
        self._encoding_geometry_revision = 0


def _simulation_chunk_interval(simulation: dict) -> float:
    """Seconds between simulated chunks (``simulation.chunkIntervalMs``, default 20)."""
    try:
        ms = float((simulation or {}).get(
            "chunkIntervalMs", _SIM_DEFAULT_CHUNK_INTERVAL_S * 1000))
    except (TypeError, ValueError):
        ms = _SIM_DEFAULT_CHUNK_INTERVAL_S * 1000
    return max(0.0, ms) / 1000.0


def _dac_codes(start: int, span: int, count: int):
    """The DAC codes an FPGA counter visits: ``start + ((i * step) >> 8)``.

    ``step`` is ``span / count`` in 8.8 fixed point, exactly as
    ``DACCodeRange.from_resolution`` and ``_dac_range_for_bounds`` build it, but
    without their 16-bit step limit, which hardware-free scans do not need.
    """
    import numpy as np
    step = max(1, int((max(1, span) / count) * 256))
    codes = int(start) + ((np.arange(count, dtype=np.int64) * step) >> 8)
    return np.minimum(codes, 0x3FFF)


def _simulation_sampler(simulation: dict):
    """Return raw 14-bit ``f(x_codes, y_codes)`` samples for simulation."""
    import numpy as np
    mode = str((simulation or {}).get("mode", "image")).lower()
    if mode == "zeros":
        return lambda x, y: np.zeros(np.shape(x), dtype=np.uint16)
    if mode == "loopback":
        return lambda x, y: (np.asarray(x, dtype=np.int64) & 0x3FFF).astype(np.uint16)
    if mode != "image":
        raise ValueError(
            f"unknown simulation mode {mode!r}; valid: image, zeros, loopback")

    from GlasgowDataIO.IobeamControl.applet.imageSource import get_image_data
    data, resolution = get_image_data(simulation)
    side = int(resolution)
    if side < 2 or side & (side - 1):
        raise ValueError(f"simulation imageResolution must be a power of two, got {side}")
    image = np.asarray(data, dtype=np.uint16).reshape(side, side)
    shift = 14 - (side.bit_length() - 1)      # x_idx = dac_x_code >> shift
    return lambda x, y: image[np.asarray(y) >> shift, np.asarray(x) >> shift]


async def _paced_chunks(chunks, *, abort, interval: float):
    """Hand out prebuilt chunks one at a time, yielding to the loop between them."""
    for n, chunk in enumerate(chunks):
        await asyncio.sleep(interval if n else 0)
        if abort.is_set():
            return
        yield chunk


async def _simulated_raster_chunks(req: RasterRequest, simulation: dict, *,
                                   abort, interval: float, transforms=None):
    """Raster stream for the configured source, matching the hardware ROI order."""
    import numpy as np
    sampler = await asyncio.to_thread(_simulation_sampler, simulation)
    width = height = req.resolution
    regions = req.parallel_rois or [req.roi]
    coordinates = []
    for region in regions:
        bounds = _roi_bounds(region)
        x0, x1, y0, y1 = bounds if bounds is not None else (0, 0x3FFF, 0, 0x3FFF)
        coordinates.append((
            _dac_codes(x0, x1 - x0 + 1, width),
            _dac_codes(y0, y1 - y0 + 1, height),
        ))
    total = width * height * len(regions)
    pixels_per_chunk = max(1, math.ceil(req.latency_bytes / req.dwell))
    for n, start in enumerate(range(0, total, pixels_per_chunk)):
        await asyncio.sleep(interval if n else 0)
        if abort.is_set():
            return
        idx = np.arange(start, min(start + pixels_per_chunk, total), dtype=np.int64)
        region_indices = idx % len(regions)
        local_indices = idx // len(regions)
        samples = np.empty(len(idx), dtype=np.uint16)
        for region_index, (xs, ys) in enumerate(coordinates):
            mask = region_indices == region_index
            local = local_indices[mask]
            samples[mask] = _obi_aligned_np(sampler(xs[local % width], ys[local // width]))
        yield array.array("H", samples.tobytes())


async def _simulated_vector_chunks(req: VectorRequest, simulation: dict, *,
                                   abort, interval: float, transforms=None):
    """Vector stream for the configured simulation source: one sample per point."""
    import numpy as np
    sampler = await asyncio.to_thread(_simulation_sampler, simulation)
    if req.pattern not in (VectorPattern.custom, VectorPattern.lattice):
        regions = req.parallel_rois or [req.roi]
        count = req.vector_resolution ** 2 * len(regions)
        size = min(65536, max(1, math.ceil(req.latency_bytes / req.dwell)))
        for emitted, start in enumerate(range(0, count, size)):
            await asyncio.sleep(interval if emitted else 0)
            if abort.is_set():
                return
            indices = np.arange(start, min(start + size, count), dtype=np.int64)
            values = np.empty(len(indices), dtype=np.uint16)
            for region_index, region in enumerate(regions):
                mask = indices % len(regions) == region_index
                xs, ys = _regular_vector_coordinates(
                    req.vector_resolution, region, req.scan_path, indices[mask] // len(regions))
                values[mask] = _obi_aligned_np(sampler(np.clip(xs, 0, 0x3FFF), np.clip(ys, 0, 0x3FFF)))
            yield array.array("H", values.tobytes())
        return
    if req.pattern is VectorPattern.custom and req.points is not None:
        iter_points = iter(req.points)
    elif req.pattern is VectorPattern.lattice:
        iter_points = lattice_stream(req)[0]()
    elif req.parallel_rois:
        iter_points = _parallel_roi_iter(
            req.vector_resolution, req.parallel_rois, req.dwell, req.scan_path)
    else:
        iter_points = _roi_vector_iter(
            req.vector_resolution, req.roi, dwell=req.dwell, scan_path=req.scan_path)

    limit = 65536 * (req.lattice.dwell + 1) if req.pattern is VectorPattern.lattice else max(1, req.latency_bytes)
    xs: List[int] = []
    ys: List[int] = []
    blanks: List[bool] = []
    total_dwell = 0
    emitted = 0

    def build() -> array.array:
        x = np.clip(np.asarray(xs, dtype=np.int64), 0, 0x3FFF)
        y = np.clip(np.asarray(ys, dtype=np.int64), 0, 0x3FFF)
        samples = _obi_aligned_np(sampler(x, y))
        samples[np.asarray(blanks, dtype=bool)] = 0
        return array.array("H", samples.tobytes())

    for point in iter_points:
        x, y, dwell, blank, _pass_index = _normalize_vector_point(point)
        xs.append(x)
        ys.append(y)
        blanks.append(bool(blank))
        total_dwell += max(1, int(dwell))
        if total_dwell >= limit or len(xs) >= 65536:
            await asyncio.sleep(interval if emitted else 0)
            if abort.is_set():
                return
            yield build()
            emitted += 1
            xs, ys, blanks, total_dwell = [], [], [], 0
    if xs:
        await asyncio.sleep(interval if emitted else 0)
        if not abort.is_set():
            yield build()


def _bitmap_vector_chunks(req: VectorRequest, transforms=None) -> Optional[List[array.array]]:
    if req.parallel_rois and req.parallel_simulation_bitmaps:
        if len(req.parallel_rois) != len(req.parallel_simulation_bitmaps):
            raise ValueError("parallel_simulation_bitmaps must match parallel_rois")
        parts = []
        for index, (region, bitmap) in enumerate(zip(req.parallel_rois, req.parallel_simulation_bitmaps)):
            background = index == 0 and len(req.parallel_rois) > 1 and _roi_bounds(region) == (0, 16383, 0, 16383)
            part = _bitmap_vector_chunks(req.model_copy(update={
                "roi": region, "parallel_rois": None,
                "simulation_bitmap": bitmap, "parallel_simulation_bitmaps": None,
                "gray_level_range": None if background else req.gray_level_range,
                "gray_level_skipped": None if background else req.gray_level_skipped,
            }), transforms)
            if part is None:
                return None
            parts.append(part)
        return _interleave_roi_chunks(
            parts, math.ceil(req.latency_bytes / max(1, req.dwell)))
    bitmap = getattr(req, "simulation_bitmap", None)
    if bitmap is None or not bitmap.pixels:
        return None

    if req.pattern is not VectorPattern.custom:
        grid = (np.fromiter(
            (_obi_aligned_int(min(_bitmap_pixel_value(pixel) * 64, 0x3FFF)) for pixel in bitmap.pixels),
            dtype=np.uint16, count=len(bitmap.pixels),
        ).reshape(bitmap.height, bitmap.width)
            if req.target_gray_level is not None else _bitmap_sample_grid(
                bitmap, ("skip" if req.gray_level_skipped else "splash")
                if req.gray_level_range is not None and req.gray_level_skipped is not None else None))
        x0, x1, y0, y1 = _roi_bounds(bitmap.source_roi or req.roi) or (0, 16383, 0, 16383)
        size = min(65536, max(1, math.ceil(req.latency_bytes / req.dwell)))
        total = req.vector_resolution ** 2
        chunks = []
        for start in range(0, total, size):
            xs, ys = _regular_vector_coordinates(
                req.vector_resolution, req.roi, req.scan_path,
                np.arange(start, min(start + size, total), dtype=np.int64))
            bx = np.rint(np.clip((xs - x0) / max(1, x1 - x0), 0, 1) * (bitmap.width - 1)).astype(np.int64)
            by = np.rint(np.clip((ys - y0) / max(1, y1 - y0), 0, 1) * (bitmap.height - 1)).astype(np.int64)
            chunks.append(array.array("H", grid[by, bx].tobytes()))
        return chunks

    chunks: List[array.array] = []
    samples = array.array("H")
    total_dwell = 0

    def flush() -> None:
        nonlocal samples, total_dwell
        if samples:
            chunks.append(samples)
            samples = array.array("H")
            total_dwell = 0

    if req.pattern is VectorPattern.custom and req.points:
        iter_points = iter(req.points)
        sample_value = lambda x, y, blank: 0 if blank else _bitmap_sample_point(
            bitmap, req.roi, x, y, transforms)
    elif req.pattern is VectorPattern.custom:
        def generated_points():
            for idx in range(bitmap.width * bitmap.height):
                x = idx // bitmap.height
                y = idx % bitmap.height
                yield x, y, req.dwell, False
        iter_points = generated_points()
        def sample_value(x, y, blank):
            if blank:
                return 0
            x_norm = 0.0 if bitmap.width <= 1 else x / (bitmap.width - 1)
            y_norm = 0.0 if bitmap.height <= 1 else y / (bitmap.height - 1)
            return _bitmap_sample(bitmap, x_norm, y_norm)
    else:
        iter_points = _roi_vector_iter(
            req.vector_resolution, req.roi, dwell=req.dwell, scan_path=req.scan_path
        )
        sample_value = lambda x, y, blank: 0 if blank else _bitmap_sample_point(
            bitmap, req.roi, x, y, transforms)

    for point in iter_points:
        x, y, dwell, blank, _pass_index = _normalize_vector_point(point)
        samples.append(_obi_aligned_int(sample_value(x, y, blank)))
        total_dwell += max(1, int(dwell))
        if total_dwell >= max(1, req.latency_bytes) or len(samples) >= 65536:
            flush()
    flush()
    return chunks


def _gray_range_to_u14(gray_range: Tuple[int, int]) -> Tuple[int, int]:
    lo, hi = sorted((int(gray_range[0]), int(gray_range[1])))
    return min(lo * 64, 0x3FFF), min(hi * 64, 0x3FFF)


class DeviceService:
    """One scan at a time. One USB connection, lazily opened, dropped on error."""

    def __init__(self, config_path: str):
        self._config_path = config_path
        self._config = AutomationConfig(config_path)
        # AutomationConfig keeps top-level JSON keys in its backing mapping,
        # while the scan implementation intentionally reads IsProduction as
        # an attribute. Normalize that boundary once; do not add scan-path
        # conditionals or alter the IobeamTech scan algorithm.
        if not hasattr(self._config, "IsProduction"):
            self._config.IsProduction = self._config.__dict__.get("IsProduction", True)

        action = util.GetStateConfigByName(self._config, "streamData")[Consts.ACTION_DATA]
        # Raw JSON blocks kept for backward compat with existing
        # display-render code that pulls camelCase keys directly
        # (lineShiftPerXRow, adcLatency, xResolution, etc.).
        self._raster_defaults = action.get("rasterScan", {}) or {}
        self._vector_defaults = action.get("vectorScan", {}) or {}
        self._simulation_defaults = action.get("simulation", {}) or {}
        self._action_defaults = action or {}

        # Normalized scan params, single source of truth for the macros.
        # JSON's camelCase keys (frameBlank, latency, drainFloorPixels) are
        # accepted alongside the snake_case API spellings, so streamData.json
        # doesn't need to be migrated in lockstep.
        self._raster_params_defaults = RasterParams.from_json(self._raster_defaults)
        self._vector_params_defaults = VectorParams.from_json(self._vector_defaults)
        try:
            self._conversion_hz = FPGA_CLOCK_HZ / AdcTiming.from_action(action).period
        except Exception as exc:  # malformed timing block: keep the requested latency
            logger.warning("ADC timing unreadable (%s); host-link chunk pacing disabled, "
                           "scans use the requested latency", exc)
            self._conversion_hz = 0.0

        self._conn: Optional[GlasgowConnection] = None
        self._adc_conn: Optional[AdcConnection] = None
        # A connection dropped after a USB error.  It still owns the USB
        # interface until it is hard-closed, which happens before the next
        # connect (see _close_stale_conn); opening a new GlasgowDevice
        # first fails with LIBUSB_ERROR_BUSY.
        self._stale_conn: Optional[GlasgowConnection] = None
        # Cross-process USB ownership (see device_lock.py): the native desktop
        # app and this service must not claim the Glasgow at the same time.
        # Created lazily by the _device_lock property.
        self._active_command = None
        self._abort_requested = False
        # Who holds `_lock` (kind, transport, start time, owning task) and
        # whether Stop was requested for that scan. Unlike
        # `_abort_requested`, `_scan_aborted` survives `_deactivate_command`
        # so the scan-end bookkeeping can report the run as cancelled.
        self._active_scan: Optional[dict] = None
        self._scan_aborted = False
        self._lock = asyncio.Lock()
        self._status = ServiceStatus(state=DeviceState.IDLE)  # IDLE = "ready, not yet connected"

        # In-memory cache of the most recent completed scan. Populated by
        # both run_raster/run_vector (validated) AND the streaming
        # generators (live), so the browser can pull a CSV or PNG figure
        # from /scan/last/* regardless of which path produced the data.
        # Worst case ~16 MB (2048x2048 vector + 2048x2048 raster).
        self._last: Optional[dict] = None

    # -------- lifecycle ---------------------------------------------------

    def _device_lock_owner(self) -> str:
        return "glasgow_service (web UI)"

    @property
    def _device_lock(self) -> DeviceLock:
        lock = self.__dict__.get("_device_lock_obj")
        if lock is None:
            lock = self.__dict__["_device_lock_obj"] = DeviceLock(self._device_lock_owner())
        return lock

    def _claim_device(self) -> None:
        """Take cross-process ownership of the Glasgow before opening USB."""
        try:
            self._device_lock.acquire()
        except DeviceHeld as exc:
            raise DeviceNotReady(
                f"{exc}. Close the scan in that application (or release the device "
                "there) and try again.") from None

    def _release_device_if_idle(self) -> None:
        conn = getattr(self, "_conn", None)
        if (conn is None or not conn.connected) and getattr(self, "_adc_conn", None) is None:
            self._device_lock.release()

    async def start(self) -> None:
        """No hardware action. Connection is opened lazily on first scan."""
        self._status.state = DeviceState.IDLE
        logger.debug("service ready (lazy connect on first scan)")

    async def stop(self) -> None:
        """Close every connection and release the device lock."""
        await self._close_stale_conn()
        if self._adc_conn is not None:
            await self._adc_conn.close()
            self._adc_conn = None
        if self._conn is not None:
            await self._conn._hard_close()
            self._conn = None
        self._device_lock.release()
        self._status.state = DeviceState.DISCONNECTED
        logger.debug("service stopped (connection reference dropped)")
        logger.info("service stopped (connection reference dropped)")

    async def reconnect(self) -> None:
        """Drop the current connection so the next scan opens a fresh one."""
        async with self._lock:
            await self._close_stale_conn()
            if self._adc_conn is not None:
                await self._adc_conn.close()
                self._adc_conn = None
            if self._conn is not None:
                await self._conn._hard_close()
                self._conn = None
            self._device_lock.release()
            self._status.state = DeviceState.IDLE
            self._status.last_error = None
        logger.debug("connection dropped; next scan will reconnect")

    def status(self) -> ServiceStatus:
        return self._status.model_copy()

    def abort_active_scan(self, owner=None) -> bool:
        """Cooperatively stop the active FPGA command without closing USB.

        `owner` (the task that started the scan) restricts the abort to that
        scan, so a stream whose client went away cannot stop a newer scan."""
        if not self._lock.locked():
            return False
        active = getattr(self, "_active_scan", None)
        if owner is not None and (active is None or active.get("owner") is not owner):
            return False
        self._abort_requested = True
        if not getattr(self, "_scan_aborted", False):
            self._abort_time = time.monotonic()  # first Stop request of this scan
        self._scan_aborted = True
        abort = getattr(self._active_command, "abort", None)
        if abort is not None:
            abort.set()
        logger.info("scan abort requested (%s)",
                    "command signalled" if abort is not None
                    else "connection still initialising; applied when the command starts")
        return True

    def update_live_gray_rule(self, kind: str, rule: dict, *, owner=None) -> None:
        """Publish a validated rule for the next pass without replacing the command."""
        active = getattr(self, "_active_scan", None)
        req = getattr(self, "_active_live_request", None)
        cmd = self._active_command
        if (kind != "vector" or active is None or active.get("kind") != kind or
                (owner is not None and active.get("owner") is not owner) or
                req is None or cmd is None or not getattr(cmd, "continuous", False)):
            raise ValueError("no matching continuous vector scan is active")
        fields = {"target_gray_level", "gray_level_range", "gray_level_skipped"}
        if not isinstance(rule, dict) or set(rule) != fields:
            raise ValueError("target_gray_level, gray_level_range and gray_level_skipped are required")
        validated = VectorRequest.model_validate(rule)
        if not isinstance(cmd, _SimulatedCommand):
            raise ValueError("this hardware scan cannot change its gray rule in-band")
        updates = {name: getattr(validated, name) for name in fields}
        selection = validated.gray_level_range
        skipped = validated.gray_level_skipped

        def decorate(bitmap, *, background=False):
            if bitmap is None or background:
                return bitmap
            pixels = []
            for pixel in bitmap.pixels:
                value = _bitmap_pixel_value(pixel)
                if selection is not None and selection[0] <= value <= selection[1]:
                    pixels.append(SimulationBitmapPixel.model_construct(
                        value=value, isHighlighted=True, isSkipped=skipped, blank=skipped))
                else:
                    pixels.append(value)
            return bitmap.model_copy(update={"pixels": pixels})

        updates["simulation_bitmap"] = decorate(req.simulation_bitmap)
        if req.parallel_simulation_bitmaps:
            updates["parallel_simulation_bitmaps"] = [
                decorate(bitmap, background=(index == 0 and len(req.parallel_rois or []) > 1
                         and _roi_bounds(req.parallel_rois[0]) == (0, 16383, 0, 16383)))
                for index, bitmap in enumerate(req.parallel_simulation_bitmaps)
            ]
        if self._active_live_request is not req or self._active_command is not cmd:
            raise ValueError("live scan changed before the gray rule could be applied")
        self._active_live_request = req.model_copy(update=updates)
        if isinstance(cmd, _SimulatedCommand):
            cmd._geometry_revision += 1

    def update_live_scan_geometry(self, kind: str, geometry: dict, *, owner=None) -> None:
        """Update DAC geometry or a gray rule on the current continuous stream."""
        live = getattr(self, "_active_live_request", None)
        if getattr(live, "pattern", None) is VectorPattern.lattice:
            # The lattice is its own geometry (shape, DAC pitch, dwell, passes). A ROI/Zoom update would
            # leave the beam on the old lattice while the display moved, so the exposure takes precedence.
            raise ValueError("live geometry updates (Zoom, regions, gray rule) are not allowed during a lattice exposure")
        if set(geometry) == {"gray_rule"}:
            self.update_live_gray_rule(kind, geometry["gray_rule"], owner=owner)
            return
        active = getattr(self, "_active_scan", None)
        req = getattr(self, "_active_live_request", None)
        cmd = self._active_command
        if (active is None or active.get("kind") != kind or
                (owner is not None and active.get("owner") is not owner) or
                req is None or cmd is None or not getattr(cmd, "continuous", False)):
            raise ValueError("no matching continuous scan is active")
        if set(geometry) - {"roi", "parallel_rois", "points"}:
            raise ValueError("only scan geometry can be updated")
        if "roi" not in geometry or "parallel_rois" not in geometry:
            raise ValueError("roi and parallel_rois are required")
        updates = {
            "roi": ROIRequest.model_validate(geometry["roi"]) if geometry["roi"] is not None else None,
            "parallel_rois": ([ROIRequest.model_validate(item) for item in geometry["parallel_rois"]]
                              if geometry["parallel_rois"] is not None else None),
        }
        if "points" in geometry:
            if kind != "vector" or req.pattern is not VectorPattern.custom or req.points is None:
                raise ValueError("point updates require a custom vector scan")
            updated_points = VectorRequest.model_validate({
                **req.model_dump(), **updates, "points": geometry["points"],
            }).points
            if updated_points is None or len(updated_points) != len(req.points):
                raise ValueError("live point update must preserve the sample count")
            def metadata(point):
                return tuple(point[2:]) if isinstance(point, (tuple, list)) else (
                    point.dwell, point.blank, point.passIndex)
            if any(metadata(before) != metadata(after)
                   for before, after in zip(req.points, updated_points)):
                raise ValueError("live point update cannot change dwell, blanking or pass markers")
            updates["points"] = updated_points
        elif kind == "vector" and req.pattern is VectorPattern.custom and req.points is not None:
            raise ValueError("custom vector zoom requires updated points")
        updated = req.model_copy(update=updates)
        old_count = len(req.parallel_rois or [])
        if len(updated.parallel_rois or []) != old_count:
            raise ValueError("live geometry update cannot change the region count")
        logger.info("[%s] live geometry old_roi=%s new_roi=%s old_regions=%s new_regions=%s max_pipeline=%s command=%s",
                    kind, req.roi, updated.roi, req.parallel_rois, updated.parallel_rois,
                    getattr(cmd, "_max_pipeline", None), type(cmd).__name__)
        stats = getattr(cmd, "_link_stats", None)
        if stats is not None:
            logger.info("[%s] geometry queue snapshot chunks_sent=%d chunks_received=%d outstanding=%d pixels_received=%d",
                        kind, stats.chunks_sent, stats.chunks_recv,
                        stats.chunks_sent - stats.chunks_recv, stats.pixels_recv)
        if isinstance(cmd, _SimulatedCommand):
            cmd._geometry_revision += 1
            logger.info("[%s simulation] geometry queued revision=%d", kind, cmd._geometry_revision)
            self._active_live_request = updated
            return
        replacement = (self._build_raster_cmd(updated, continuous=True) if kind == "raster"
                       else self._build_vector_cmd(updated, continuous=True))
        if type(replacement) is not type(cmd):
            raise ValueError("live geometry update cannot change the scan mode")
        if isinstance(cmd, RasterScanCommand):
            cmd.update_geometry(replacement._x_range, replacement._y_range)
        elif isinstance(cmd, VectorScanCommand):
            cmd.update_geometry(replacement._points_factory, replacement.pass_pixels)
        else:
            raise ValueError("live geometry update is unsupported for this scan")
        self._active_live_request = updated

    def _busy_detail(self) -> str:
        """Human-readable reason for DeviceBusy: who holds the device."""
        active = getattr(self, "_active_scan", None)
        if not active:
            return f"device busy: service state is {self._status.state.value}"
        elapsed = time.monotonic() - active["started"]
        detail = (f"device busy: a {active['kind']} scan ({active['transport']}) "
                  f"started {elapsed:.1f} s ago is still running")
        if getattr(self, "_scan_aborted", False):
            detail += "; Stop was requested and hardware cleanup has not finished"
        return detail

    async def adc_stream(self, req: AdcTestRequest) -> AsyncIterator[bytes]:
        """Stream from the ADC-only image while holding the global device lock.

        Loading this image replaces the scan image. The normal connection is
        therefore closed first and left empty so the next scan reloads its own
        gateware. AdcConnection.close() always clears capture-enable before it
        releases the USB interface.
        """
        async with self._acquire("adc"):
            await self._close_stale_conn()
            if self._conn is not None:
                await self._conn._hard_close()
                self._conn = None
            self._claim_device()

            conn = AdcConnection(
                self._config,
                duration_minutes=req.duration_minutes,
                simulation=req.simulation,
                seed=req.seed,
                chunk_bytes=req.chunk_bytes,
            )
            self._adc_conn = conn
            stop = asyncio.Event()

            class _AdcCommand:
                abort = stop

            command = _AdcCommand()
            self._activate_command(command)
            try:
                await conn.connect()
                async for chunk in conn.chunks(stop=stop):
                    if stop.is_set():
                        break
                    self._status.chunks_in_flight += 1
                    yield chunk
            finally:
                self._deactivate_command(command)
                try:
                    await conn.close()
                finally:
                    self._adc_conn = None
                    self._release_device_if_idle()

    def _activate_command(self, command) -> None:
        self._active_command = command
        # Lets the macros' end-of-scan [link] summary estimate beam time.
        if self._conversion_hz > 0:
            try:
                command.link_beam_hz = self._conversion_hz
            except AttributeError:
                pass
        if self._abort_requested:
            command.abort.set()

    # -------- hardware-free simulation --------------------------------------

    def _hardware_free(self, req) -> bool:
        """True when this scan must run without touching a Glasgow.

        That is the case for IsProduction=false when the simulation is enabled
        (``simulation.enabled``, on unless switched off) or the browser supplied
        a ``simulation_bitmap``. IsProduction=true always uses the hardware.
        """
        if not _simulation_enabled(self._config):
            return False
        if (
            getattr(req, "simulation_bitmap", None) is not None
            or getattr(req, "simulation_bitmap_id", None)
            or getattr(req, "parallel_simulation_bitmaps", None)
            or getattr(req, "parallel_simulation_bitmap_ids", None)
        ):
            return True
        return bool(self._simulation_settings(req).get("enabled", True))

    def _simulation_settings(self, req) -> dict:
        """Resolve a request-scoped browser override without mutating service defaults."""
        override = getattr(req, "simulation", None)
        return dict(override) if isinstance(override, dict) else self._simulation_defaults

    def _prepare_simulated_stream_request(self, req, *, pace: bool):
        if pace and (req.parallel_rois or getattr(req, "target_gray_level", None) is None):
            # Transport packets are not acquisition steps. A small hardware
            # latency must not add 20 ms of artificial delay per ~500 pixels
            # across millions of simulation samples. Use the same batching
            # for sequential ROI passes and parallel acquisition.
            # A standalone target-gray pass retains its smaller packets: their
            # cadence drives the feedback steps within that pass.
            req = req.model_copy(update={
                "latency_bytes": max(req.latency_bytes, req.dwell * 16384),
            })
        if pace and getattr(req, "continuous", False):
            # Keep the effective request as the live baseline. Otherwise the
            # first loop iteration sees the original object as a geometry
            # update and rebuilds thousands of tiny chunks per pass.
            self._active_live_request = req
        return req

    def _simulated_pipeline(self, kind: str, req) -> tuple[int, str]:
        """Select the same queue setting as the hardware command builder.

        Resolve the route without constructing a physical command: software
        simulation also permits coarse grids and bitmap-only custom patterns.
        """
        raster = kind == "raster" and not req.parallel_rois
        if kind == "vector" and not req.parallel_rois:
            feedback = self._adaptive_gray_feedback_config(req)
            if self._vector_runs_on_raster_generator(req, feedback):
                x0, x1, y0, y1 = _roi_bounds(req.roi) or (0, 16383, 0, 16383)
                try:
                    _dac_range_for_bounds(x0, x1, req.vector_resolution)
                    _dac_range_for_bounds(y0, y1, req.vector_resolution)
                except ValueError:
                    pass  # Hardware also falls back to streamed vector points.
                else:
                    raster = True
        params = self._raster_params_defaults if raster else self._vector_params_defaults
        pipeline = int(params.max_pipeline)
        if pipeline < 1:
            raise ValueError("max_pipeline must be positive")
        return pipeline, "raster" if raster else "vector"

    async def _simulated_chunks(self, kind: str, req, command, *, pace: bool):
        """Queue encoded chunks ahead of acquisition, as the hardware sender does.

        The hardware receiver grants one initial credit in addition to
        max_pipeline. Keep that extra chunk here too. Refill only when the
        consumer resumes, so downstream backpressure cannot grow the queue.
        Playback uses simulation.chunkIntervalMs, not a physical USB clock.
        """
        if not pace:
            async for chunk in self._simulated_source_chunks(kind, req, command, pace=pace):
                yield chunk
            return

        pipeline, route = self._simulated_pipeline(kind, req)
        command._max_pipeline = pipeline
        command._link_stats = stats = LinkStats("simulation-" + kind)
        capacity = pipeline + 1
        lattice_exposure = kind == "vector" and req.pattern is VectorPattern.lattice
        interval = 0.0 if lattice_exposure else _simulation_chunk_interval(self._simulation_settings(req))
        pending = deque()
        source = self._simulated_source_chunks(kind, req, command, pace=True, queued=True)
        exhausted = False
        delivered_revision = None
        logger.info("[%s simulation] command queue route=%s max_pipeline=%d capacity=%d chunk_interval_ms=%.3f",
                    kind, route, pipeline, capacity, interval * 1000)
        try:
            while not command.abort.is_set():
                while len(pending) < capacity and not exhausted and not command.abort.is_set():
                    try:
                        chunk = await anext(source)
                    except StopAsyncIteration:
                        exhausted = True
                    else:
                        pending.append((chunk, command._encoding_geometry_revision))
                        stats.sent(0.0)
                if command.abort.is_set() or not pending:
                    break
                chunk, revision = pending.popleft()
                t_read = time.perf_counter()
                # Unlike a plain sleep, Stop also wakes a long simulated chunk.
                if interval:
                    try:
                        await asyncio.wait_for(command.abort.wait(), timeout=interval)
                    except asyncio.TimeoutError:
                        pass
                if command.abort.is_set():
                    break
                if lattice_exposure:
                    await asyncio.sleep(0)
                stats.received(time.perf_counter() - t_read, len(chunk))
                if revision != delivered_revision:
                    delivered_revision = revision
                    logger.info("[%s simulation] geometry output revision=%d chunks_sent=%d chunks_received=%d queued=%d",
                                kind, revision, stats.chunks_sent, stats.chunks_recv, len(pending))
                t_yield = time.perf_counter()
                yield chunk
                stats.consumed(time.perf_counter() - t_yield)
        finally:
            outcome = "aborted" if command.abort.is_set() else "ok" if exhausted and not pending else "closed"
            pending.clear()
            await source.aclose()
            logger.info(stats.summary(outcome))

    async def _simulated_source_chunks(self, kind: str, req, command, *, pace: bool, queued: bool = False):
        """Encode simulation data; geometry is snapshotted at each frame boundary."""
        bitmap_id = getattr(req, "simulation_bitmap_id", None)
        bitmap_ids = getattr(req, "parallel_simulation_bitmap_ids", None)
        if bitmap_id or bitmap_ids:
            from . import scan_assets
            if bitmap_ids and len(bitmap_ids) != len(req.parallel_rois or []):
                raise ValueError("parallel bitmap asset IDs must match parallel ROIs")
            def load_bitmap(asset_id):
                bitmap = scan_assets.load(asset_id)
                # Normal acquisition only reads immutable assets. Target-gray
                # feedback mutates pixels, so only that path needs a private copy.
                return bitmap.model_copy(deep=True) if kind == "vector" and req.target_gray_level is not None else bitmap

            req = req.model_copy(update={
                "simulation_bitmap": await asyncio.to_thread(
                    load_bitmap, bitmap_id) if bitmap_id else req.simulation_bitmap,
                "parallel_simulation_bitmaps": await asyncio.to_thread(
                    lambda: [load_bitmap(asset_id) for asset_id in bitmap_ids]
                ) if bitmap_ids else req.parallel_simulation_bitmaps,
                "simulation_bitmap_id": None,
                "parallel_simulation_bitmap_ids": None,
            })
        simulation = self._simulation_settings(req)
        interval = _simulation_chunk_interval(simulation) if pace and not queued else 0.0
        req = self._prepare_simulated_stream_request(req, pace=pace)
        build_bitmap = _bitmap_raster_chunks if kind == "raster" else _bitmap_vector_chunks
        # Building a bitmap frame is pure Python; keep it off the event loop.
        transforms = self._action_defaults.get("transforms", {}) or {}
        bitmap_chunks = await asyncio.to_thread(build_bitmap, req, transforms)
        # Live raster (Infinite): repeat frames back to back on the same
        # stream until Stop, exactly like the hardware continuous command.
        continuous = pace and bool(getattr(req, "continuous", False))
        frames_left = _session_frames(req, continuous)
        while True:
            live_req = getattr(self, "_active_live_request", None)
            if continuous and live_req is not None and live_req is not req:
                req = live_req
                command._encoding_geometry_revision = command._geometry_revision
                logger.info("[%s simulation] encoding geometry revision=%d roi=%s regions=%s",
                            kind, command._encoding_geometry_revision, req.roi, req.parallel_rois)
                bitmap_chunks = await asyncio.to_thread(build_bitmap, req, transforms)
            if bitmap_chunks is not None:
                source = _paced_chunks(bitmap_chunks, abort=command.abort, interval=interval)
            elif kind == "raster":
                source = _simulated_raster_chunks(
                    req, simulation, abort=command.abort, interval=interval,
                    transforms=transforms)
            else:
                source = _simulated_vector_chunks(
                    req, simulation, abort=command.abort, interval=interval,
                    transforms=transforms)
            frame_started = time.monotonic()
            sample_offset = 0
            encoded_chunks = 0
            playback_interval = _simulation_chunk_interval(simulation) if queued else 0.0
            async for chunk in source:
                if kind == "vector" and req.target_gray_level is not None and bitmap_chunks is not None:
                    # Encoding ahead must not freeze time-based sample feedback.
                    elapsed = max(time.monotonic() - frame_started, encoded_chunks * playback_interval)
                    steps = int(elapsed * 60)
                    yield _target_gray_chunk(chunk, req, sample_offset, steps)
                else:
                    yield chunk
                sample_offset += len(chunk)
                encoded_chunks += 1
            if frames_left is not None:
                frames_left -= 1
            if not continuous or command.abort.is_set() or frames_left == 0:
                return
            if kind == "vector" and req.target_gray_level is not None and bitmap_chunks is not None:
                elapsed = max(time.monotonic() - frame_started, encoded_chunks * playback_interval)
                steps = max(1, int(elapsed * 60))
                def advance_target() -> None:
                    if req.parallel_rois and req.parallel_simulation_bitmaps:
                        for index, (region, bitmap) in enumerate(zip(req.parallel_rois, req.parallel_simulation_bitmaps)):
                            if index == 0 and len(req.parallel_rois) > 1 and _roi_bounds(region) == (0, 16383, 0, 16383):
                                continue  # normal full-field background is never processed
                            _target_gray_step_bitmap(bitmap, region, req.target_gray_level, steps, req.gray_level_range, req.gray_level_skipped)
                    elif req.simulation_bitmap is not None:
                        _target_gray_step_bitmap(req.simulation_bitmap, req.roi, req.target_gray_level, steps, req.gray_level_range, req.gray_level_skipped)
                    return None
                await asyncio.to_thread(advance_target)
                bitmap_chunks = await asyncio.to_thread(build_bitmap, req, transforms)
            # Keep the chunk cadence across the frame boundary.
            await asyncio.sleep(interval)

    def _simulated_last_scan(self, kind: str, req, chunks: List, source: str) -> dict:
        if kind == "raster":
            return {
                "kind": "raster",
                "chunks": chunks,
                "resolution": req.resolution,
                "dwell": req.dwell,
                "latency_bytes": req.latency_bytes,
                "simulation_bitmap": req.simulation_bitmap,
                "source": source,
            }
        return {
            "kind": "vector",
            "chunks": chunks,
            "latency_bytes": req.latency_bytes,
            "dwell": req.dwell,
            "pattern": req.pattern.value if hasattr(req.pattern, "value") else str(req.pattern),
            "scan_path": req.scan_path.value,
            "points": req.points,
            "vector_resolution": req.vector_resolution,
            "roi": req.roi,
            "simulation_bitmap": req.simulation_bitmap,
            "source": source,
        }

    async def _simulated_scan(self, kind: str, req, *, native_samples: bool = False):
        """A streamed scan with no device: same lock, abort and bookkeeping as a real one."""
        captured: List = []
        capture_image = kind != "vector" or req.pattern is not VectorPattern.lattice
        if getattr(req, "continuous", False):
            captured = _FrameRing(_simulated_pass_samples(kind, req))
        async with self._acquire(kind):
            command = _SimulatedCommand()
            command.continuous = bool(getattr(req, "continuous", False))
            self._active_live_request = req if command.continuous else None
            self._activate_command(command)
            source = self._simulated_chunks(kind, req, command, pace=True)
            try:
                async for chunk in source:
                    self._status.chunks_in_flight += 1
                    if capture_image:
                        captured.append(chunk)
                    yield chunk if native_samples else _sample_chunk_to_wire_bytes(chunk)
            finally:
                await source.aclose()
                self._deactivate_command(command)
                self._active_live_request = None
                # Like a real scan: keep whatever was captured, even if stopped.
                if isinstance(captured, _FrameRing):
                    captured = captured.frame()
                if capture_image:
                    self._set_last_scan(req, self._simulated_last_scan(kind, req, captured, "stream"))

    async def _simulated_run_chunks(self, kind: str, req) -> List:
        """All chunks of a blocking simulated scan (caller holds the device lock)."""
        command = _SimulatedCommand()
        self._activate_command(command)
        try:
            return [chunk async for chunk in
                    self._simulated_chunks(kind, req, command, pace=False)]
        finally:
            self._deactivate_command(command)

    def _deactivate_command(self, command) -> None:
        if self._active_command is command:
            self._active_command = None
        self._abort_requested = False

    def defaults(self) -> dict:
        """Return the JSON defaults for the UI.

        Both shapes are present:
          * `raster` / `vector` — raw camelCase JSON keys, for back-compat
            with the existing frontend translation in `applyServerDefaults`
            and the display-render code that pulls `lineShiftPerXRow` etc.
          * `raster_params` / `vector_params` — normalized snake_case dicts
            matching the API request shapes, fed by RasterParams /
            VectorParams. New frontend code should prefer these — no
            client-side translation needed.
        """
        return {
            "exposure_cell_ranges": True,
            "raster": dict(self._raster_defaults),
            "vector": dict(self._vector_defaults),
            "simulation": dict(self._simulation_defaults),
            "adc": {
                "adcHalfPeriod": self._action_defaults.get("adcHalfPeriod", 3),
                "adcSettleCycles": self._action_defaults.get("adcSettleCycles", 1),
                "adcLatchCycles": self._action_defaults.get("adcLatchCycles", 1),
                "busTurnaroundCycles": self._action_defaults.get("busTurnaroundCycles", 0),
                "dacDataSetupCycles": self._action_defaults.get("dacDataSetupCycles", 1),
                "dacLatchCycles": self._action_defaults.get("dacLatchCycles", 1),
            },
            "mag_calibration": dict(self._action_defaults.get("magCalibration", {}) or {}),
            "raster_params": self._raster_params_defaults.to_public_dict(),
            "vector_params": self._vector_params_defaults.to_public_dict(),
            "selected_beam": (
                "ebeam" if bool(self._action_defaults.get("enableEbeam", False)) else "ion"
            ),
            "is_production": bool(getattr(self._config, "IsProduction", True)),
            # Relay switch delay at takeover and at hand-back, for the
            # calculated takeover time shown before Run.
            "takeover": {"ext_switch_delay_ms": self._switch_delay_ms()},
            "adc_test": bool(getattr(
                self._config, "AdcTest", self._action_defaults.get("AdcTest", True)
            )),
            "version": str(getattr(self._config, "Version", "")),
        }

    # -------- internal: effective params (JSON defaults ⊕ request override) ---

    def _effective_raster_params(self, req: "RasterRequest") -> RasterParams:
        """Merge the JSON defaults with the request, with the request
        winning on every field it explicitly carries. Macro-tuning
        constants (max_pipeline, padding_*) come from JSON only. Configuration
        exposes max_pipeline; padding remains JSON-only. Changes apply after
        the service restarts, rather than through per-scan request fields."""
        return self._raster_params_defaults.override(
            resolution    = req.resolution,
            dwell         = req.dwell,
            latency_bytes = req.latency_bytes,
            frame_blank   = (req.frame_blank if "frame_blank" in req.model_fields_set
                             else self._raster_params_defaults.frame_blank),
            cookie        = req.cookie,
            adc_valid     = req.adc_valid,
            output_mode   = req.output_mode,
            beam_type     = req.beam_type,
            external_control = req.external_control,
        )

    def _effective_vector_params(self, req: "VectorRequest") -> VectorParams:
        # `pattern` is a Pydantic enum; normalize to str for the dataclass.
        pattern_str = req.pattern.value if hasattr(req.pattern, "value") else str(req.pattern)
        return self._vector_params_defaults.override(
            pattern           = pattern_str,
            vector_resolution = req.vector_resolution,
            dwell             = req.dwell,
            latency_bytes     = req.latency_bytes,
            output_mode       = req.output_mode,
            adc_valid         = req.adc_valid,
            beam_type         = req.beam_type,
            external_control  = req.external_control,
            cookie            = req.cookie,
            pre_process       = req.pre_process,
            do_validate       = req.do_validate,
            points            = req.points,
        )

    def _chunk_latency(self, kind: str, requested: int, cmd) -> int:
        """Effective transfer latency for a hardware scan (see _link_chunk_latency).

        ``cmd`` is the command actually being sent, not the request kind: a
        horizontal_sawtooth vector request may have been routed to a
        RasterScanCommand, and then the streamed-vector point cap must not
        apply (the raster generator sends a few bytes per chunk)."""
        dwell = _command_dwell(cmd)
        # The DAC-ramp diagnostic is itself the waveform under test.  Splitting
        # the 16,384-code sweep into host-link chunks inserts a USB/flush gap
        # between ramp segments, which appears on a scope as a staircase or
        # as a much-too-slow waveform.  Match upstream OBI's RampControl and
        # keep the complete sweep in one FPGA command stream.
        if kind == "dac_ramp":
            return max(1, int(requested), 16384 * dwell)

        streamed = isinstance(cmd, VectorScanCommand)
        cfg = self._vector_defaults if kind == "vector" else self._raster_defaults
        min_ms = float(cfg.get("minChunkBeamTimeMs", DEFAULT_MIN_CHUNK_BEAM_TIME_MS))
        latency = _link_chunk_latency(
            requested, dwell, self._conversion_hz, min_ms,
            VECTOR_MAX_CHUNK_POINTS if streamed else None)
        if latency != requested:
            logger.info("[%s] chunk latency %d -> %d (>= %.0f ms beam time per host flush%s)",
                        kind, requested, latency, min_ms,
                        ", streamed-point cap" if streamed else "")
        return latency

    def _adaptive_gray_feedback_config(
        self, req: "VectorRequest"
    ) -> Optional[AdaptiveGrayFeedbackConfig]:
        if not bool(self._vector_defaults.get("PixelFallbackBlank", False)):
            return None
        if getattr(req, "feedback_mode", None) != "adaptive_gray_feedback":
            mode = getattr(req, "feedback_mode", None)
            if getattr(mode, "value", None) != "adaptive_gray_feedback":
                return None
        if req.gray_level_range is None or req.gray_level_skipped is None:
            return None

        gray_min, gray_max = _gray_range_to_u14(req.gray_level_range)
        window_points = int(self._vector_defaults.get("adaptiveFeedbackWindowPoints", 1) or 1)
        pipeline_delay_points = int(
            self._vector_defaults.get("adaptiveFeedbackPipelineDelayPoints", 0) or 0
        )
        return AdaptiveGrayFeedbackConfig(
            gray_min=gray_min,
            gray_max=gray_max,
            blank_when_inside=bool(req.gray_level_skipped),
            window_points=window_points,
            pipeline_delay_points=pipeline_delay_points,
        )

    # -------- internal: lazy connect / drop-on-error ----------------------

    async def _ensure_conn(self) -> GlasgowConnection:
        """Return a live connection, opening one if we don't have it."""
        if self._conn is not None and self._conn.connected:
            return self._conn

        # A connection dropped after an error still claims the USB interface:
        # release it first, or the new GlasgowDevice fails with BUSY.
        await self._close_stale_conn()
        if self._conn is not None:
            # Present but no longer connected: close it before replacing it.
            await self._hard_close_quietly(self._conn, "disconnected connection")
            self._conn = None
        logger.debug("opening Glasgow connection")
        self._claim_device()
        self._status.state = DeviceState.CONNECTING
        try:
            self._conn = GlasgowConnection(self._config)
            await self._conn._connect()
            if not self._conn.connected:
                raise DeviceNotReady(
                    "GlasgowConnection._connect() reported not connected")
        except Exception as e:
            failed, self._conn = self._conn, None
            if failed is not None:
                await self._hard_close_quietly(failed, "failed connection")
            self._status.state = DeviceState.ERROR
            self._status.last_error = repr(e)
            if _is_fatal_usb_error(e):
                raise DeviceNotReady(str(e)) from e
            raise

        self._status.state = DeviceState.BUSY if self._lock.locked() else DeviceState.IDLE
        self._status.last_error = None
        return self._conn

    def _drop_conn_on_error(self, exc: BaseException) -> None:
        """Called from a scan's exception path. If the exception looks like
        a USB problem, drop the connection so the next request reconnects."""
        if _is_fatal_usb_error(exc):
            logger.warning("dropping connection after %s: %s",
                        type(exc).__name__, exc)
            stale, self._conn = self._conn, None
            if stale is not None:
                # Called from synchronous exception paths (some inside async
                # generators), so the close is deferred to the next connect.
                previous = getattr(self, "_stale_conn", None)
                if previous is not None and previous is not stale:
                    logger.warning("a previous stale connection was still open")
                self._stale_conn = stale

    async def _close_stale_conn(self) -> None:
        stale = getattr(self, "_stale_conn", None)
        self._stale_conn = None
        if stale is not None:
            await self._hard_close_quietly(stale, "connection dropped after an error")

    @staticmethod
    async def _hard_close_quietly(conn, what: str) -> None:
        try:
            await conn._hard_close()
            logger.info("released the Glasgow USB interface held by the %s", what)
        except Exception as exc:  # noqa: BLE001 - best effort; keep going
            logger.warning("closing the %s raised %s: %s",
                           what, type(exc).__name__, exc)

    # -------- streaming (for WebSocket) -----------------------------------

    async def raster_scan(self, req: RasterRequest, *, native_samples: bool = False):
        transport = "in_process" if native_samples else "websocket"
        if self._hardware_free(req):
            async for wire in self._simulated_scan("raster", req, native_samples=native_samples):
                yield wire
            return

        # Buffer chunks for the /scan/last/* download endpoints. We hold
        # references to the chunks already-yielded; the bytes are still
        # in memory anyway because the WebSocket frame keeps them until
        # the network layer flushes.
        captured: List = []
        scan_started = time.monotonic()
        first_sample_logged = False
        continuous = bool(getattr(req, "continuous", False))
        async with self._acquire("raster", transport=transport):
            conn = await self._ensure_conn()
            cmd = self._build_raster_cmd(req, continuous=continuous)
            self._active_live_request = req if continuous else None
            latency = self._chunk_latency("raster", req.latency_bytes, cmd)
            logger.info("[raster] scan geometry roi=%s regions=%s command=%s max_pipeline=%s latency=%s continuous=%s",
                        req.roi, req.parallel_rois, type(cmd).__name__, getattr(cmd, "_max_pipeline", None),
                        latency, getattr(cmd, "continuous", False))
            if continuous:
                # Live scan: keep only the most recent frame for /scan/last/*
                # instead of every chunk of an unbounded stream.
                captured = _FrameRing(getattr(cmd, "pass_pixels", req.resolution * req.resolution))
                logger.info("[raster] continuous live scan: %d px/frame, %d chunks/frame",
                            captured.frame_pixels,
                            cmd.frame_chunk_count(latency) if hasattr(cmd, "frame_chunk_count") else -1)
            self._activate_command(cmd)
            adc_monitor = _AdcPresenceMonitor(
                enabled=_production_adc_monitor_enabled(self._config, req.adc_valid))
            logger.info("[raster] ADC presence check %s (adc_valid=%s)",
                        "enabled" if adc_monitor.enabled else "disabled", req.adc_valid)
            adc_presence_fault = False
            try:
                async for chunk in conn.transfer_multiple(
                        cmd, latency=latency):
                    self._status.chunks_in_flight += 1
                    if not first_sample_logged:
                        first_sample_logged = True
                        logger.info("scan first-sample kind=raster transport=%s elapsed=%.3fs",
                                    transport, time.monotonic() - scan_started)
                    captured.append(chunk)
                    fault = adc_monitor.observe(chunk)
                    if fault is not None:
                        logger.warning("production ADC presence warning: %s", fault)
                        adc_presence_fault = True
                        if getattr(self, "_scan_aborted", False):
                            # Stop already requested: end as a cancellation,
                            # not a device fault nobody is waiting for.
                            logger.info("ADC presence fault ignored: scan was stopped")
                            break
                        raise DeviceNotReady(fault)
                    yield chunk if native_samples else _sample_chunk_to_wire_bytes(chunk)
            except BaseException as e:
                adc_presence_fault = adc_presence_fault or (
                    isinstance(e, DeviceNotReady) and
                    str(e).startswith("ADC/subtarget presence check failed:"))
                self._drop_conn_on_error(e)
                raise
            finally:
                self._deactivate_command(cmd)
                self._active_live_request = None
                summary = adc_monitor.summary()
                if summary is not None:
                    logger.info("%s", summary)
                # On normal completion AND on cancellation (Pause/Stop),
                # snapshot whatever we got. Partial captures are still
                # downloadable — better than nothing for a paused scan.
                if not adc_presence_fault:
                    self._set_last_scan(req, {
                        "kind": "raster",
                        "chunks": (captured.frame() if isinstance(captured, _FrameRing)
                                   else captured),
                        "resolution": req.resolution,
                        "dwell": req.dwell,
                        "latency_bytes": latency,
                        "source": "stream",
                    })

    async def vector_scan(self, req: VectorRequest, *, native_samples: bool = False):
        transport = "in_process" if native_samples else "websocket"
        if self._hardware_free(req):
            async for wire in self._simulated_scan("vector", req, native_samples=native_samples):
                yield wire
            return

        captured: List = []
        scan_started = time.monotonic()
        first_sample_logged = False
        async with self._acquire("vector", transport=transport):
            conn = await self._ensure_conn()
            cmd = self._build_vector_cmd(
                req, continuous=bool(getattr(req, "continuous", False)))
            self._active_live_request = req if getattr(cmd, "continuous", False) else None
            latency = self._chunk_latency("vector", req.latency_bytes, cmd)
            logger.info("[vector] scan geometry roi=%s regions=%s command=%s max_pipeline=%s latency=%s continuous=%s",
                        req.roi, req.parallel_rois, type(cmd).__name__, getattr(cmd, "_max_pipeline", None),
                        latency, getattr(cmd, "continuous", False))
            multi_pass_adaptive = getattr(cmd, "_adaptive_passes", 1) > 1
            if getattr(cmd, "continuous", False) or multi_pass_adaptive:
                # Live scan or Repeat N: keep only the most recent pass for
                # /scan/last/*, like a single run would leave.
                pass_pixels = getattr(cmd, "pass_pixels", None) or cmd.frame_pixels
                captured = _FrameRing(pass_pixels)
                logger.info("[vector] %s: %d samples/pass (%s), passes=%s",
                            "adaptive repeat session" if multi_pass_adaptive else "continuous live scan",
                            pass_pixels, type(cmd).__name__,
                            getattr(cmd, "_max_passes", None) or getattr(cmd, "_max_frames", None) or "until Stop")
            self._activate_command(cmd)
            if (req.pre_process and hasattr(cmd, "_pre_process_chunks")
                    and not getattr(cmd, "continuous", False)):
                cmd._pre_process_chunks(latency=latency)
            transfer_iter = conn.transfer_multiple(
                cmd, latency=latency)
            adc_monitor = _AdcPresenceMonitor(
                enabled=_production_adc_monitor_enabled(self._config, req.adc_valid))
            logger.info("[vector] ADC presence check %s (adc_valid=%s)",
                        "enabled" if adc_monitor.enabled else "disabled", req.adc_valid)
            adc_presence_fault = False
            try:
                async for chunk in transfer_iter:
                    self._status.chunks_in_flight += 1
                    if not first_sample_logged:
                        first_sample_logged = True
                        logger.info("scan first-sample kind=vector transport=%s elapsed=%.3fs",
                                    transport, time.monotonic() - scan_started)
                    if req.pattern is not VectorPattern.lattice:
                        captured.append(chunk)
                    fault = adc_monitor.observe(chunk)
                    if fault is not None:
                        logger.warning("production ADC presence warning: %s", fault)
                        adc_presence_fault = True
                        if getattr(self, "_scan_aborted", False):
                            # Stop already requested: end as a cancellation,
                            # not a device fault nobody is waiting for.
                            logger.info("ADC presence fault ignored: scan was stopped")
                            break
                        raise DeviceNotReady(fault)
                    yield chunk if native_samples else _sample_chunk_to_wire_bytes(chunk)
            except BaseException as e:
                adc_presence_fault = adc_presence_fault or (
                    isinstance(e, DeviceNotReady) and
                    str(e).startswith("ADC/subtarget presence check failed:"))
                self._drop_conn_on_error(e)
                raise
            finally:
                self._deactivate_command(cmd)
                self._active_live_request = None
                try:
                    # Ensure Stop/disconnect reaches Connection's cleanup
                    # before the service releases this scan generator.
                    await transfer_iter.aclose()
                finally:
                    summary = adc_monitor.summary()
                    if summary is not None:
                        logger.info("%s", summary)
                    # Preserve the previous known-good scan when this frame
                    # is the disconnected/full-scale signature. Partial
                    # operator-stopped captures remain downloadable.
                    if not adc_presence_fault and req.pattern is not VectorPattern.lattice:
                        self._set_last_scan(req, {
                            "kind": "vector",
                            "chunks": (captured.frame() if isinstance(captured, _FrameRing)
                                       else captured),
                            "latency_bytes": latency,
                            "pattern": req.pattern.value if hasattr(req.pattern, "value") else str(req.pattern),
                            "scan_path": req.scan_path.value,
                            "points": req.points,
                            "vector_resolution": req.vector_resolution,
                            "roi": req.roi,
                            "source": "stream",
                        })

    async def dac_ramp_scan(self, req: DacRampRequest, *, native_samples: bool = False):
        """Streaming counterpart of run_dac_ramp, same shape as raster_scan/
        vector_scan so the WebSocket path (live UI) and the blocking REST
        path (/scan/dac_ramp/run) share one command builder and never drift.

        No `_hardware_free`/simulation branch: this is a hardware
        diagnostic by definition (checking the physical DAC/ADC path), so
        it always talks to the real device. If simulation-only operation
        is ever needed here, add it deliberately rather than inheriting
        raster/vector's bitmap-simulation machinery, which doesn't apply.
        """
        captured: List = []
        async with self._acquire("dac_ramp"):
            conn = await self._ensure_conn()
            cmd = self._build_dac_ramp_cmd(req)
            latency = self._chunk_latency("dac_ramp", req.latency_bytes, cmd)
            self._activate_command(cmd)
            # Same disconnected-bus detection raster/vector already run:
            # a floating revC3 ADC bus reads as full scale forever, which
            # looks exactly like a flat line pegged at 16383/16384 on the
            # waveform — indistinguishable from "Complete" without this
            # check. Surfacing it as an error (instead of silently
            # finishing) is what actually explains a flat trace to the
            # operator; the DAC ramp itself may well be fine.
            adc_monitor = _AdcPresenceMonitor(
                enabled=_production_adc_monitor_enabled(self._config, req.adc_valid))
            try:
                async for chunk in conn.transfer_multiple(
                        cmd, latency=latency):
                    self._status.chunks_in_flight += 1
                    captured.append(chunk)
                    yield chunk if native_samples else _sample_chunk_to_wire_bytes(chunk)
                    fault = adc_monitor.observe(chunk)
                    if fault is not None:
                        logger.warning("dac_ramp ADC presence warning: %s", fault)
                        raise DeviceNotReady(fault)
            except BaseException as e:
                self._drop_conn_on_error(e)
                raise
            finally:
                self._deactivate_command(cmd)
                if captured:
                    self._set_last_scan(req, {
                        "kind": "dac_ramp",
                        "chunks": captured,
                        "resolution": 16384,
                        "dwell": req.dwell,
                        "latency_bytes": latency,
                        "source": "stream",
                    })

    # -------- beam hold (blank takeover diagnostic) -----------------------

    #: Samples per parked "frame" for a duration-bounded hold (no `match`).
    #: The frame only bounds how often the gateware re-arms the region.
    BEAM_HOLD_FRAME = 256
    BEAM_HOLD_DEFAULT_DURATION_S = 30.0
    _DAC_AXIS_MAX = 16384

    def _switch_delay_ms(self) -> float:
        timings = self._action_defaults.get("timings", {}) or {}
        try:
            return float(timings.get("ext_switch_delay_ms", 20))
        except (TypeError, ValueError):
            return 20.0

    def check_beam_hold_allowed(self, req=None) -> None:
        """Beam hold takes over a real instrument, so it runs exactly when a
        scan with the same settings would use the hardware (the scan rule,
        _hardware_free): IsProduction=true, or IsProduction=false with
        simulation switched off. A simulated scan touches nothing, so a
        simulated hold would take over nothing and prove nothing."""
        if self._hardware_free(req):
            raise DeviceNotReady(
                "Beam hold takes over the instrument, so it runs only when scans "
                "use the hardware (IsProduction=true, or simulation switched off); "
                "simulation has no takeover")

    def _beam_hold_geometry(self, req: BeamHoldRequest):
        """(x_count, y_count, sample_dwell, frames, frame_blank) for the hold.

        With `match`, each hold frame lasts as long as one frame of that scan
        (frame_pixels x (dwell + 1) conversions), sampled at the finer
        `req.dwell` so millisecond dips stay visible: the hold has the scan's
        frame count, frame time and Frame blank, so its takeover matches the
        scan's. The pixel count is factored into two DAC-range counts; the
        rounding adds at most one row per frame."""
        plan = req.match
        if plan is None:
            n = self.BEAM_HOLD_FRAME
            return n, n, req.dwell, None, False
        sample_dwell = min(req.dwell, plan.dwell)
        conversions = plan.frame_pixels * (plan.dwell + 1)
        while True:
            pixels = max(1, round(conversions / (sample_dwell + 1)))
            x = min(self._DAC_AXIS_MAX, max(1, math.isqrt(pixels - 1) + 1))
            y = -(-pixels // x)
            if y <= self._DAC_AXIS_MAX:
                break
            sample_dwell = sample_dwell * 2 + 1      # coarser samples, same time
        frame_blank = (plan.frame_blank if plan.frame_blank is not None
                       else bool(self._raster_params_defaults.frame_blank))
        return x, y, sample_dwell, plan.frames, frame_blank

    def beam_hold_metadata(self, req: BeamHoldRequest) -> dict:
        """First frame of /scan/beam_hold/stream: sample timing and the
        calculated takeover, so the browser can measure dips and show how
        long control will be held."""
        hz = self._conversion_hz or 8_000_000.0
        x, y, sample_dwell, frames, frame_blank = self._beam_hold_geometry(req)
        frame_s = x * y * (sample_dwell + 1) / hz
        switch_s = 2 * self._switch_delay_ms() / 1000.0
        duration = (frames * frame_s if frames is not None
                    else (req.duration_s or self.BEAM_HOLD_DEFAULT_DURATION_S))
        return {
            "event": "metadata",
            "sample_period_us": (sample_dwell + 1) * 1e6 / hz,
            "conversion_hz": hz,
            "duration_s": duration,
            "takeover_s": duration + switch_s,
            "frames": frames,
            "frame_s": frame_s if frames is not None else None,
            "frame_blank": frame_blank,
            "beam": req.beam.value,
            "external_control": req.external_control,
        }

    def _build_beam_hold_cmd(self, req: BeamHoldRequest) -> RasterScanCommand:
        """A live raster over a step-0 region: every sample lands on
        (x_code, y_code), so the DACs stay frozen while the ADC keeps
        streaming. Same RasterScanCommand path as a real scan, so the relay
        takeover, switch delay, unblank on the first sample, Frame blank
        between frames and hand-back are exactly those of a scan.

        beam=blanked uses BeamType.NoBeam: external control still switches
        the relays, the gateware holds the blank asserted, and the macro
        sends no unblank."""
        x, y, sample_dwell, frames, frame_blank = self._beam_hold_geometry(req)
        beam_type = BeamType.NoBeam if req.beam == BeamHoldState.blanked else BeamType.Ion
        return RasterScanCommand(
            cookie=req.cookie,
            x_range=DACCodeRange(start=req.x_code, count=x, step=0),
            y_range=DACCodeRange(start=req.y_code, count=y, step=0),
            dwell_time=sample_dwell,
            beam_type=beam_type,
            external_control=req.external_control,
            frame_blank=frame_blank,
            continuous=True,
            max_frames=frames,
        )

    async def beam_hold_scan(self, req: BeamHoldRequest, *, native_samples: bool = False):
        """Stream ADC samples with the beam parked until `duration_s` has
        passed or Stop is pressed. No simulation branch: like the DAC ramp,
        this checks the physical instrument by definition."""
        self.check_beam_hold_allowed(req)
        async with self._acquire("beam_hold"):
            conn = await self._ensure_conn()
            cmd = self._build_beam_hold_cmd(req)
            latency = self._chunk_latency("beam_hold", req.latency_bytes, cmd)
            self._activate_command(cmd)
            meta = self.beam_hold_metadata(req)
            logger.info("[beam_hold] x=%d y=%d beam=%s frames=%s frame=%.3fs frame_blank=%s "
                        "takeover=%.3fs external_control=%s",
                        req.x_code, req.y_code, req.beam.value, meta["frames"],
                        meta["frame_s"] or 0.0, meta["frame_blank"], meta["takeover_s"],
                        req.external_control)

            async def stop_after_duration(seconds):
                await asyncio.sleep(seconds)
                logger.info("[beam_hold] duration reached; stopping")
                cmd.abort.set()

            # Matching a scan, the hold ends with its last frame like the
            # scan does; only a duration-bounded hold needs a timer.
            timer = (asyncio.create_task(stop_after_duration(meta["duration_s"]))
                     if req.match is None else None)
            adc_monitor = _AdcPresenceMonitor(
                enabled=_production_adc_monitor_enabled(self._config, req.adc_valid))
            transfer_iter = conn.transfer_multiple(cmd, latency=latency)
            try:
                async for chunk in transfer_iter:
                    self._status.chunks_in_flight += 1
                    fault = adc_monitor.observe(chunk)
                    if fault is not None:
                        logger.warning("beam_hold ADC presence warning: %s", fault)
                        raise DeviceNotReady(fault)
                    yield chunk if native_samples else _sample_chunk_to_wire_bytes(chunk)
            except BaseException as e:
                self._drop_conn_on_error(e)
                raise
            finally:
                if timer is not None:
                    timer.cancel()
                self._deactivate_command(cmd)
                # Closing the transfer runs the hand-back to the instrument.
                await transfer_iter.aclose()

    # -------- blocking wet-run (for REST + pytest) ------------------------

    async def run_raster(self, req: RasterRequest) -> ScanResult:
        if getattr(req, "continuous", False):
            # Blocking REST returns one frame; live streaming is WebSocket-only.
            req = req.model_copy(update={"continuous": False})
        if self._hardware_free(req):
            async with self._acquire("raster"):
                simulated_chunks = await self._simulated_run_chunks("raster", req)
                pixels_per_chunk = math.ceil(req.latency_bytes / req.dwell)
                total_pixels = req.resolution * req.resolution * len(req.parallel_rois or [None])
                expected_chunks = math.ceil(total_pixels / pixels_per_chunk)
                self._set_last_scan(req, {
                    "kind": "raster",
                    "chunks": simulated_chunks,
                    "resolution": req.resolution,
                    "dwell": req.dwell,
                    "latency_bytes": req.latency_bytes,
                    "simulation_bitmap": req.simulation_bitmap,
                    "source": "validated",
                })
                validation = (
                    self._validate_raster(simulated_chunks, pixels_per_chunk, expected_chunks)
                    if req.do_validate else None
                )
                return ScanResult(
                    kind="raster",
                    chunks=len(simulated_chunks),
                    bytes=sum(len(c) * 2 for c in simulated_chunks),
                    resolution=req.resolution,
                    dwell=req.dwell,
                    expected_chunks=expected_chunks,
                    pixels_per_chunk=pixels_per_chunk,
                    send_time_s=0.0,
                    has_data=bool(simulated_chunks),
                    validation=validation,
                )

        chunks: List = []
        async with self._acquire("raster"):
            conn = await self._ensure_conn()
            cmd = self._build_raster_cmd(req)
            latency = self._chunk_latency("raster", req.latency_bytes, cmd)
            logger.info("[raster] scan geometry roi=%s regions=%s command=%s max_pipeline=%s latency=%s continuous=%s",
                        req.roi, req.parallel_rois, type(cmd).__name__, getattr(cmd, "_max_pipeline", None),
                        latency, getattr(cmd, "continuous", False))
            # Log effective params (post-override) — what actually goes to
            # the macro — rather than just the raw request. Makes it easy
            # to confirm a streamData.json default landed where it should.
            eff = self._effective_raster_params(req)
            logger.debug(
                "[raster] %dx%d dwell=%d latency=%d frame_blank=%s "
                "output_mode=%s cookie=%d adc_valid=%s max_pipeline=%d",
                eff.resolution, eff.resolution, eff.dwell, eff.latency_bytes,
                eff.frame_blank, eff.output_mode, eff.cookie, eff.adc_valid, eff.max_pipeline,
            )
            t0 = time.perf_counter()
            adc_monitor = _AdcPresenceMonitor(
                enabled=bool(req.adc_valid) and not _simulation_enabled(self._config))
            try:
                async for chunk in conn.transfer_multiple(
                        cmd, latency=latency):
                    chunks.append(chunk)
                    self._status.chunks_in_flight += 1
                    fault = adc_monitor.observe(chunk)
                    if fault is not None:
                        logger.warning("production ADC presence warning: %s", fault)
                        raise DeviceNotReady(fault)
            except BaseException as e:
                self._drop_conn_on_error(e)
                if _is_fatal_usb_error(e):
                    raise DeviceNotReady(str(e)) from e
                raise
            send_time = time.perf_counter() - t0

        pixels_per_chunk = math.ceil(latency / _command_dwell(cmd))
        total_pixels     = req.resolution * req.resolution * len(req.parallel_rois or [None])
        expected_chunks  = math.ceil(total_pixels / pixels_per_chunk)
        total_bytes      = sum(len(c) * 2 for c in chunks)

        # Cache for /scan/last/csv and /scan/last/figure.
        if chunks:
            self._set_last_scan(req, {
                "kind": "raster",
                "chunks": chunks,
                "resolution": req.resolution,
                "dwell": req.dwell,
                "latency_bytes": latency,
                "source": "validated",
            })

        validation = None
        if req.do_validate:
            validation = self._validate_raster(
                chunks, pixels_per_chunk, expected_chunks)

        return ScanResult(
            kind="raster",
            chunks=len(chunks),
            bytes=total_bytes,
            resolution=req.resolution,
            dwell=req.dwell,
            expected_chunks=expected_chunks,
            pixels_per_chunk=pixels_per_chunk,
            send_time_s=send_time,
            has_data=bool(chunks),
            validation=validation,
        )

    async def run_dac_ramp(self, req: DacRampRequest) -> ScanResult:
        """Blocking single-axis DAC ramp/linearity check (production, not
        a side script).

        This is the end-to-end fix for the DAC-output mismatch: upstream
        OBI verifies the DAC via manual_dac_ctrl.RampControl (one axis
        full-range, the other pinned), which was never ported into this
        fork. Without it, the only way to sanity-check DAC output was
        `/scan/vector/run`, whose default `scan_path` (vertical_raster)
        sweeps the *other* axis fast — on a scope the axis under test then
        shows a staircase (one step per full sweep of the other axis),
        which looks like a hardware fault but is a scan-pattern artifact.
        This reuses the same connection/lock/RasterScanCommand path as
        `/scan/raster/run`, just with one axis pinned to a single code.
        """
        chunks: List = []
        async with self._acquire("dac_ramp"):
            conn = await self._ensure_conn()
            cmd = self._build_dac_ramp_cmd(req)
            latency = self._chunk_latency("dac_ramp", req.latency_bytes, cmd)
            logger.debug(
                "[dac_ramp] axis=%s fixed_code=%d dwell=%d latency=%d cookie=%d",
                req.axis.value, req.fixed_code, req.dwell, req.latency_bytes, req.cookie,
            )
            t0 = time.perf_counter()
            adc_monitor = _AdcPresenceMonitor(
                enabled=_production_adc_monitor_enabled(self._config, req.adc_valid))
            try:
                async for chunk in conn.transfer_multiple(
                        cmd, latency=latency):
                    chunks.append(chunk)
                    self._status.chunks_in_flight += 1
                    fault = adc_monitor.observe(chunk)
                    if fault is not None:
                        logger.warning("dac_ramp ADC presence warning: %s", fault)
                        raise DeviceNotReady(fault)
            except BaseException as e:
                self._drop_conn_on_error(e)
                if _is_fatal_usb_error(e):
                    raise DeviceNotReady(str(e)) from e
                raise
            send_time = time.perf_counter() - t0

        total_bytes = sum(len(c) * 2 for c in chunks)

        # Cache for /scan/last/csv and /scan/last/figure, same as raster/vector.
        if chunks:
            self._set_last_scan(req, {
                "kind": "dac_ramp",
                "chunks": chunks,
                "resolution": 16384,
                "dwell": req.dwell,
                "latency_bytes": latency,
                "source": "validated",
            })

        return ScanResult(
            kind="dac_ramp",
            chunks=len(chunks),
            bytes=total_bytes,
            resolution=16384,
            dwell=req.dwell,
            send_time_s=send_time,
            has_data=bool(chunks),
        )

    async def run_vector(self, req: VectorRequest) -> ScanResult:
        if getattr(req, "continuous", False):
            # Blocking REST returns one pass; live streaming is WebSocket-only.
            req = req.model_copy(update={"continuous": False})
        if self._hardware_free(req):
            async with self._acquire("vector"):
                simulated_chunks = await self._simulated_run_chunks("vector", req)
                self._set_last_scan(req, {
                    "kind": "vector",
                    "chunks": simulated_chunks,
                    "latency_bytes": req.latency_bytes,
                    "dwell": req.dwell,
                    "pattern": req.pattern.value if hasattr(req.pattern, "value") else str(req.pattern),
                    "scan_path": req.scan_path.value,
                    "points": req.points,
                    "vector_resolution": req.vector_resolution,
                    "roi": req.roi,
                    "simulation_bitmap": req.simulation_bitmap,
                    "source": "validated",
                })
                validation = self._validate_vector(simulated_chunks) if req.do_validate else None
                return ScanResult(
                    kind="vector",
                    chunks=len(simulated_chunks),
                    bytes=sum(len(c) * 2 for c in simulated_chunks),
                    dwell=req.dwell,
                    process_time_s=0.0 if req.pre_process else None,
                    send_time_s=0.0,
                    has_data=bool(simulated_chunks),
                    validation=validation,
                )

        chunks: List = []
        process_time = 0.0

        async with self._acquire("vector"):
            conn = await self._ensure_conn()
            cmd = self._build_vector_cmd(req)
            latency = self._chunk_latency("vector", req.latency_bytes, cmd)
            logger.info("[vector] scan geometry roi=%s regions=%s command=%s max_pipeline=%s latency=%s continuous=%s",
                        req.roi, req.parallel_rois, type(cmd).__name__, getattr(cmd, "_max_pipeline", None),
                        latency, getattr(cmd, "continuous", False))
            adaptive_feedback = getattr(cmd, "_adaptive_gray_feedback", None)

            if req.pre_process and hasattr(cmd, "_pre_process_chunks"):
                t0 = time.perf_counter()
                cmd._pre_process_chunks(latency=latency)
                process_time = time.perf_counter() - t0
                logger.debug("[vector] pre-process %.4fs", process_time)

            eff = self._effective_vector_params(req)
            logger.debug(
                "[vector] dwell=%d latency=%d pattern=%s vector_resolution=%d "
                "output_mode=%s feedback_mode=%s adaptive_feedback=%s pre_process=%s cookie=%d "
                "max_pipeline=%d drain_floor=%d",
                eff.dwell, eff.latency_bytes, eff.pattern, eff.vector_resolution,
                cmd._output_mode, req.feedback_mode, adaptive_feedback is not None, eff.pre_process, eff.cookie,
                eff.max_pipeline, eff.effective_drain_floor_pixels,
            )
            t0 = time.perf_counter()
            adc_monitor = _AdcPresenceMonitor(
                enabled=not _simulation_enabled(self._config))
            try:
                async for chunk in conn.transfer_multiple(
                        cmd, latency=latency):
                    chunks.append(chunk)
                    self._status.chunks_in_flight += 1
                    fault = adc_monitor.observe(chunk)
                    if fault is not None:
                        logger.warning("production ADC presence warning: %s", fault)
                        raise DeviceNotReady(fault)
            except BaseException as e:
                self._drop_conn_on_error(e)
                if _is_fatal_usb_error(e):
                    raise DeviceNotReady(str(e)) from e
                raise
            send_time = time.perf_counter() - t0

        total_bytes = sum(len(c) * 2 for c in chunks)

        if chunks:
            self._set_last_scan(req, {
                "kind": "vector",
                "chunks": chunks,
                "latency_bytes": latency,
                "dwell": req.dwell,
                "pattern": req.pattern.value if hasattr(req.pattern, "value") else str(req.pattern),
                "scan_path": req.scan_path.value,
                "points": req.points,
                "vector_resolution": req.vector_resolution,
                "roi": req.roi,
                "source": "validated",
            })

        validation = None
        if req.do_validate:
            validation = self._validate_vector(chunks)

        return ScanResult(
            kind="vector",
            chunks=len(chunks),
            bytes=total_bytes,
            dwell=req.dwell,
            process_time_s=process_time if req.pre_process else None,
            send_time_s=send_time,
            has_data=bool(chunks),
            validation=validation,
        )

    # -------- command construction ---------------------------------------

    def _build_raster_cmd(self, req: RasterRequest, *,
                          continuous: bool = False):
        """Build the macro command from JSON defaults overridden by the
        request. Every field the macro accepts is passed explicitly —
        nothing falls through to a hardcoded macro default.

        ``continuous`` is passed only by the streaming path (raster_scan);
        blocking /scan/raster/run always scans exactly one frame."""
        params = self._effective_raster_params(req)

        if req.parallel_rois:
            vector = self._vector_params_defaults
            points_factory = lambda: _parallel_roi_iter(
                params.resolution, req.parallel_rois, params.dwell,
                VectorScanPath.horizontal_sawtooth,
            )
            cmd = VectorScanCommand(
                cookie=params.cookie,
                output_mode=self._parse_output_mode(params.output_mode),
                beam_type=self._parse_beam_type(params.beam_type),
                external_control=params.external_control,
                iter_points=points_factory(),
                frame_blank=params.frame_blank,
                drain_floor_pixels=vector.effective_drain_floor_pixels,
                max_pipeline=vector.max_pipeline,
                fpga_pipeline_depth_pixels=vector.fpga_pipeline_depth_pixels,
                drain_safety_factor=vector.drain_safety_factor,
                sender_drain_timeout_s=vector.sender_drain_timeout_s,
                continuous=continuous,
                points_factory=points_factory if continuous else None,
                max_passes=_session_frames(req, continuous),
            )
            cmd.link_dwell = params.dwell
            cmd.pass_pixels = params.resolution * params.resolution * len(req.parallel_rois)
            return cmd

        bounds = _roi_bounds(req.roi)
        if bounds is None:
            x_rng = y_rng = DACCodeRange.from_resolution(params.resolution)
        else:
            x0, x1, y0, y1 = bounds
            x_rng = _dac_range_for_bounds(x0, x1, params.resolution)
            y_rng = _dac_range_for_bounds(y0, y1, params.resolution)

        try:
            output_mode = OutputMode[params.output_mode]
        except KeyError:
            raise ValueError(
                f"unknown output_mode {params.output_mode!r}; "
                f"valid: {[m.name for m in OutputMode]}"
            )
        try:
            beam_type = BeamType[params.beam_type]
        except KeyError:
            raise ValueError(
                f"unknown beam_type {params.beam_type!r}; "
                f"valid: {[m.name for m in BeamType]}"
            )

        return RasterScanCommand(
            cookie=params.cookie,
            x_range=x_rng, y_range=y_rng,
            dwell_time=params.dwell,
            output_mode=output_mode,
            beam_type=beam_type,
            external_control=params.external_control,
            frame_blank=params.frame_blank,
            max_pipeline=params.max_pipeline,
            padding_min_pixels=params.padding_min_pixels,
            padding_ratio_denominator=params.padding_ratio_denominator,
            padding_dwell=params.padding_dwell,
            continuous=continuous,
            max_frames=_session_frames(req, continuous),
        )

    def _build_dac_ramp_cmd(self, req: DacRampRequest) -> RasterScanCommand:
        """Mirror upstream OBI's manual_dac_ctrl.RampControl.scan(): full
        resolution on the swept axis, count=1 (a single fixed code) on the
        held axis. Goes through the exact same RasterScanCommand /
        UpstreamBusController path as `/scan/raster/run` — the gateware
        side has already been verified bit-for-bit against upstream, so
        this only needs to reproduce the *stimulus*, not re-implement the
        drive logic."""
        full  = DACCodeRange.from_resolution(16384)
        fixed = DACCodeRange(start=req.fixed_code, count=1, step=1)

        if req.axis == DacRampAxis.y:
            x_rng, y_rng = fixed, full
        else:
            x_rng, y_rng = full, fixed

        try:
            beam_type = BeamType[req.beam_type]
        except KeyError:
            raise ValueError(
                f"unknown beam_type {req.beam_type!r}; "
                f"valid: {[m.name for m in BeamType]}"
            )

        return RasterScanCommand(
            cookie=req.cookie,
            x_range=x_rng, y_range=y_rng,
            dwell_time=req.dwell,
            beam_type=beam_type,
            external_control=req.external_control,
        )

    def _build_vector_cmd(self, req: VectorRequest, *, continuous: bool = False):
        """Same shape as raster: every macro tunable comes from the
        effective params object.

        A default-pattern horizontal_sawtooth sweep is a plain X-fast raster
        over the ROI, so it runs on the FPGA's raster generator, exactly like
        upstream OBI images a frame: the host sends a few bytes per chunk
        instead of 6 bytes per point, the gateware produces a continuous
        sawtooth, and the sample order and DAC codes are identical to
        _roi_vector_iter (same DACCodeRange arithmetic). Every other path
        (custom points, triangle/vertical orders, adaptive feedback) still
        streams points.
        """
        params = self._effective_vector_params(req)
        adaptive_feedback = self._adaptive_gray_feedback_config(req)
        if adaptive_feedback is not None and params.dwell < 16:
            params = params.override(dwell=16)

        ranges = None
        if req.parallel_rois and req.points is not None:
            raise ValueError("parallel_rois cannot be combined with custom points")
        if not req.parallel_rois and self._vector_runs_on_raster_generator(req, adaptive_feedback):
            x0, x1, y0, y1 = _roi_bounds(req.roi) or (0, 16383, 0, 16383)
            try:
                ranges = (_dac_range_for_bounds(x0, x1, params.vector_resolution),
                          _dac_range_for_bounds(y0, y1, params.vector_resolution))
            except ValueError:
                # Coarser than 256 codes per point: the raster generator's
                # UQ8.8 step can't express it, so stream the points instead.
                ranges = None
        if ranges is not None:
            raster = self._raster_params_defaults
            logger.info("[vector] horizontal_sawtooth %dx%d on the FPGA raster generator",
                        params.vector_resolution, params.vector_resolution)
            return RasterScanCommand(
                cookie=params.cookie,
                x_range=ranges[0],
                y_range=ranges[1],
                dwell_time=params.dwell,
                output_mode=self._parse_output_mode(params.output_mode),
                beam_type=self._parse_beam_type(params.beam_type),
                external_control=params.external_control,
                frame_blank=raster.frame_blank,
                max_pipeline=raster.max_pipeline,
                padding_min_pixels=raster.padding_min_pixels,
                padding_ratio_denominator=raster.padding_ratio_denominator,
                padding_dwell=raster.padding_dwell,
                continuous=continuous,
                max_frames=_session_frames(req, continuous),
            )

        if req.pattern is VectorPattern.lattice:
            # Physically spaced exposure: spots are generated lazily here, never as one list.
            points_factory, pass_pixels = lattice_stream(req)
        elif req.pattern is VectorPattern.custom:
            if req.points is None and not (
                req.simulation_bitmap is not None
                and req.roi is not None
                and not _simulation_enabled(self._config)
            ):
                raise ValueError("pattern=custom requires `points` or a production bitmap fallback")
            if req.points is not None:
                _log_vector_point_flags(req.points)
                points_factory = lambda: iter(req.points)
                pass_pixels = len(req.points)
            else:
                # Production compatibility for browser ROI bitmap scans:
                # simulation_bitmap is ignored by hardware, so fall back to
                # the regular ROI vector sweep rather than rejecting the
                # request as custom-without-points.
                points_factory = lambda: _roi_vector_iter(
                    params.vector_resolution, req.roi, dwell=params.dwell, scan_path=req.scan_path
                )
                pass_pixels = params.vector_resolution * params.vector_resolution
        else:
            if req.parallel_rois:
                points_factory = lambda: _parallel_roi_iter(
                    params.vector_resolution, req.parallel_rois, params.dwell, req.scan_path)
                pass_pixels = params.vector_resolution * params.vector_resolution * len(req.parallel_rois)
            else:
                points_factory = lambda: _roi_vector_iter(
                    params.vector_resolution, req.roi, dwell=params.dwell, scan_path=req.scan_path
                )
                pass_pixels = params.vector_resolution * params.vector_resolution
        iter_points = points_factory()
        # Repeat N: a live session of N passes. Adaptive feedback cannot
        # stream passes blindly (each point is decided on the host), but it
        # can still run its N passes on one command stream.
        session_passes = _session_frames(req, continuous)
        # Live passes re-generate their points; adaptive feedback stays per pass.
        continuous = continuous and adaptive_feedback is None

        try:
            output_mode = OutputMode[params.output_mode]
        except KeyError:
            raise ValueError(
                f"unknown output_mode {params.output_mode!r}; "
                f"valid: {[m.name for m in OutputMode]}"
            )
        try:
            beam_type = BeamType[params.beam_type]
        except KeyError:
            raise ValueError(
                f"unknown beam_type {params.beam_type!r}; "
                f"valid: {[m.name for m in BeamType]}"
            )

        cmd = VectorScanCommand(
            cookie=params.cookie,
            output_mode=OutputMode.SixteenBit if adaptive_feedback is not None else output_mode,
            beam_type=beam_type,
            external_control=params.external_control,
            iter_points=iter_points,
            frame_blank=self._raster_params_defaults.frame_blank,
            drain_floor_pixels=params.effective_drain_floor_pixels,
            adaptive_gray_feedback=adaptive_feedback,
            max_pipeline=params.max_pipeline,
            fpga_pipeline_depth_pixels=params.fpga_pipeline_depth_pixels,
            drain_safety_factor=params.drain_safety_factor,
            sender_drain_timeout_s=params.sender_drain_timeout_s,
            continuous=continuous,
            points_factory=points_factory if continuous else None,
            max_passes=session_passes,
            require_sender_completion=req.pattern is VectorPattern.lattice,
        )
        cmd.link_dwell = req.lattice.dwell if req.pattern is VectorPattern.lattice else params.dwell
        cmd.pass_pixels = pass_pixels
        return cmd

    def _vector_runs_on_raster_generator(self, req: VectorRequest, adaptive_feedback) -> bool:
        if not bool(self._vector_defaults.get("sawtoothOnRasterGenerator", True)):
            return False
        if adaptive_feedback is not None or req.scan_path is not VectorScanPath.horizontal_sawtooth:
            return False
        if req.pattern is VectorPattern.default:
            return True
        # custom without points = the production ROI-bitmap fallback, which
        # scans the same ROI sweep (see below)
        return req.pattern is VectorPattern.custom and req.points is None and req.roi is not None

    @staticmethod
    def _parse_output_mode(name: str) -> OutputMode:
        try:
            return OutputMode[name]
        except KeyError:
            raise ValueError(f"unknown output_mode {name!r}; valid: {[m.name for m in OutputMode]}")

    @staticmethod
    def _parse_beam_type(name: str) -> BeamType:
        try:
            return BeamType[name]
        except KeyError:
            raise ValueError(f"unknown beam_type {name!r}; valid: {[m.name for m in BeamType]}")

    # -------- on-demand download bytes (CSV / PNG figure) -----------------

    def _set_last_scan(self, req, last: dict) -> None:
        # Record the parameters this scan actually ran with, so the DumpData
        # files can carry them in their header (see last_dump_csv_bytes).
        last.setdefault("scan_params", self._scan_param_header(req, last))
        last.setdefault("parallel_rois", getattr(req, "parallel_rois", None))
        self._last = last
        self._maybe_dump_last_outputs()

    def _scan_param_header(self, req, last: dict) -> List[Tuple[str, str]]:
        """Ordered (name, value) pairs describing the scan settings.

        Plain strings only, so the list pickles into the desktop artifact
        worker and is written verbatim into the CSV/PNG dump headers.
        """
        def enum_text(value) -> str:
            return str(getattr(value, "value", value))

        kind = last.get("kind", "")
        params: List[Tuple[str, str]] = [
            ("kind", kind),
            ("written", time.strftime("%Y-%m-%d %H:%M:%S")),
            ("source", str(last.get("source") or "")),
        ]
        if kind == "raster":
            res = getattr(req, "resolution", None)
            params.append(("resolution", f"{res}x{res}"))
        elif kind == "vector":
            pattern = enum_text(getattr(req, "pattern", ""))
            params.append(("pattern", pattern))
            if pattern == "default":
                edge = getattr(req, "vector_resolution", None)
                params.append(("resolution", f"{edge}x{edge}"))
            params.append(("scan_path", enum_text(getattr(req, "scan_path", ""))))
        elif kind == "dac_ramp":
            params.append(("axis", enum_text(getattr(req, "axis", ""))))
            params.append(("fixed_code", str(getattr(req, "fixed_code", ""))))

        parallel_rois = getattr(req, "parallel_rois", None)
        if parallel_rois:
            params.append(("parallel_regions", str(len(parallel_rois))))
            for index, region in enumerate(parallel_rois, 1):
                params.append((f"region_{index}_dac", str(_roi_bounds(region))))

        dwell = getattr(req, "dwell", None)
        if dwell is not None:
            dwell = int(dwell)
            period_ns = (1e9 / self._conversion_hz) if getattr(self, "_conversion_hz", 0) else 125.0
            params.append(("dwell", f"{dwell} (+1 = {dwell + 1} x {period_ns:.1f} ns = "
                                    f"{(dwell + 1) * period_ns / 1000.0:.3f} us/pixel)"))
        requested_latency = getattr(req, "latency_bytes", None)
        effective_latency = last.get("latency_bytes", requested_latency)
        if effective_latency is not None:
            text = str(effective_latency)
            if requested_latency is not None and requested_latency != effective_latency:
                text += f" (requested {requested_latency})"
            params.append(("latency_bytes", text))
        for name in ("output_mode", "frame_blank", "adc_valid", "beam_type", "cookie"):
            if hasattr(req, name):
                params.append((name, str(getattr(req, name))))

        if kind == "vector":
            feedback = getattr(req, "feedback_mode", None)
            if feedback is not None:
                params.append(("feedback_mode", enum_text(feedback)))
            gray_range = getattr(req, "gray_level_range", None)
            if gray_range is not None:
                lo, hi = gray_range
                params.append(("gray_level_range", f"{lo}..{hi}"))
                skipped = getattr(req, "gray_level_skipped", None)
                if skipped is not None:
                    params.append(("gray_level_mode", "skip" if skipped else "spot"))

        roi = getattr(req, "roi", None)
        if roi is not None:
            params.append(("roi_dac", f"x {roi.x_start:g}..{roi.x_end:g}, y {roi.y_start:g}..{roi.y_end:g}"))
            params.append(("roi_zoom", f"{roi_zoom(_roi_bounds(roi)):.4g}x"))
        params.append(("chunks", str(len(last.get("chunks") or []))))
        return [(name, value) for name, value in params if value != ""]

    def last_scan_params(self) -> List[Tuple[str, str]]:
        if not self._last:
            return []
        return [tuple(item) for item in (self._last.get("scan_params") or [])]

    def last_dump_csv_bytes(self) -> bytes:
        """DumpData CSV: the scan parameters as ``#`` comment lines, then
        the same rows as :meth:`last_csv_bytes` (``numpy.loadtxt`` and most
        CSV readers skip ``#`` lines by default)."""
        header = "".join(f"# {name}: {value}\n" for name, value in self.last_scan_params())
        return header.encode("utf-8") + self.last_csv_bytes()

    def last_dump_png_bytes(self) -> bytes:
        """DumpData PNG: the figure with the scan parameters stored as PNG
        text chunks (visible in image viewers' metadata / ``identify -verbose``)."""
        return self.last_figure_png(metadata={
            "Title": f"Ion beam {self._last.get('kind', 'scan')} scan",
            "Description": "; ".join(f"{name}={value}" for name, value in self.last_scan_params()),
            **{f"scan.{name}": value for name, value in self.last_scan_params()},
        })

    def _dump_filename(self, file_type: str, timestamp: str) -> str:
        if not self.has_last():
            return f"scan.{file_type}"
        last = self._last
        return self._last_filename(file_type, timestamp)

    def _last_filename(self, file_type: str, timestamp: str) -> str:
        last = self._last
        if not last:
            return f"scan.{file_type}"
        if last["kind"] == "raster":
            r = last.get("resolution") or 0
            return f"raster_{r}x{r}_{timestamp}.{file_type}"
        return f"vector_latency_{last.get('latency_bytes') or 0}_{timestamp}.{file_type}"

    def _maybe_dump_last_outputs(self) -> None:
        """Mirror the unit-test DumpData behavior for service/UI scans.

        The CSV (pure Python) and the matplotlib PNG take seconds for a live
        frame. This runs in the scan's ``finally`` while the device lock is
        held, so doing it inline blocked the event loop and delayed the next
        scan's start (Stop -> Zoom/Parallel restart). The files are therefore
        written by a single background worker from a frozen snapshot, so a
        scan that ends before the worker finishes cannot change their content.
        """
        if not getattr(self._config, "DumpData", False):
            return
        if not self.has_last():
            return
        timestamp = time.strftime("%y%m%d_%H%M%S")
        snapshot = copy.copy(self)   # shares config; freezes ``_last``
        snapshot._last = self._last
        _DUMP_EXECUTOR.submit(snapshot._write_dump_files, timestamp)

    def _write_dump_files(self, timestamp: str) -> None:
        started = time.monotonic()
        try:
            output_dir = Path.home() / "Output"
            output_dir.mkdir(parents=True, exist_ok=True)
            csv_path = output_dir / self._dump_filename("csv", timestamp)
            csv_path.write_bytes(self.last_dump_csv_bytes())
            logger.info("wrote CSV dump: %s", csv_path)
        except Exception as exc:
            logger.warning("failed to write CSV dump: %s", exc)
        try:
            output_dir = Path.home() / "Output"
            output_dir.mkdir(parents=True, exist_ok=True)
            png_path = output_dir / self._dump_filename("png", timestamp)
            png_path.write_bytes(self.last_dump_png_bytes())
            logger.info("wrote PNG dump: %s", png_path)
        except Exception as exc:
            logger.warning("failed to write PNG dump: %s", exc)
        logger.info("DumpData finished in %.3fs (background)", time.monotonic() - started)

    def has_last(self) -> bool:
        return self._last is not None and bool(self._last.get("chunks"))

    def last_meta(self) -> Optional[dict]:
        """Lightweight metadata for the UI to display next to the buttons."""
        if not self.has_last():
            return None
        last = self._last
        return {
            "kind": last["kind"],
            "chunks": len(last["chunks"]),
            "source": last.get("source"),
            "resolution": last.get("resolution"),
            "latency_bytes": last.get("latency_bytes"),
            "pattern": last.get("pattern"),
            "vector_resolution": last.get("vector_resolution"),
        }

    def last_csv_filename(self) -> str:
        if not self.has_last():
            return "scan.csv"
        return self._last_filename("csv", time.strftime("%y%m%d_%H%M%S"))

    def last_csv_bytes(self) -> bytes:
        """Render the last scan as CSV (UTF-8). Format identical to the
        on-disk CSV the previous `save_csv=True` code path produced, so
        downstream tooling that already parses those files keeps working."""
        if not self.has_last():
            raise DeviceNotReady("no scan data cached")
        last = self._last
        buf = io.StringIO()
        writer = csv.writer(buf, delimiter=" ")

        if last["kind"] == "raster":
            res = last["resolution"]
            all_pixels: list = []
            for chunk in last["chunks"]:
                all_pixels.extend(chunk)
            for row_idx in range(res):
                start = row_idx * res
                row = all_pixels[start:start + res]
                if not row:
                    break
                writer.writerow(row)
        else:
            for chunk in last["chunks"]:
                writer.writerow(chunk)

        return buf.getvalue().encode("utf-8")

    def last_figure_filename(self) -> str:
        if not self.has_last():
            return "scan.png"
        return self._last_filename("png", time.strftime("%y%m%d_%H%M%S"))

    def last_figure_png(self, render_mode: str = "decimated",
                        view: str = "figure",
                        metadata: Optional[dict] = None) -> bytes:
        """Render the last scan as a publication-quality PNG using
        matplotlib. Mirrors the layout of the matplotlib figures the
        operator was generating manually before this endpoint existed.

        `render_mode` is "native" or "decimated" (vector only; raster
        scans ignore it):
          - native:   render a 2048x2048 image with stride-block fill
                      so the image is dense even for low-resolution scans.
                      Pixel coords correspond to DAC codes 1:1.
          - decimated: render an edge x edge image where edge is the
                       scan's vector_resolution. Pixel coords correspond
                       to scan indices, NOT DAC codes — but we use
                       imshow's `extent=` to keep the axis labels in DAC
                       coordinates so the figure stays legible.
        """
        if not self.has_last():
            raise DeviceNotReady("no scan data cached")

        # Imported lazily so the service still boots without matplotlib
        # installed — only this endpoint will fail.
        import numpy as np
        import matplotlib
        matplotlib.use("Agg")  # headless backend; required when no display
        import matplotlib.pyplot as plt

        last = self._last
        transforms = self._action_defaults.get("transforms", {}) or {}
        xflip = transforms.get("xflip") is True
        yflip = transforms.get("yflip") is True
        rotate90 = transforms.get("rotate90") is True

        def orient_image(image):
            if rotate90:
                image = np.rot90(image, k=3)
            if xflip:
                image = np.fliplr(image)
            if yflip:
                image = np.flipud(image)
            return image

        def orient_bounds(bounds):
            if bounds is None:
                return None
            x0, x1, y0, y1 = bounds
            if rotate90:
                x0, x1, y0, y1 = 16384 - y1, 16384 - y0, x0, x1
            if xflip:
                x0, x1 = 16384 - x1, 16384 - x0
            if yflip:
                y0, y1 = 16384 - y1, 16384 - y0
            return x0, x1, y0, y1

        simulation_bitmap = last.get("simulation_bitmap")
        if simulation_bitmap is not None and getattr(simulation_bitmap, "pixels", None):
            flat = np.asarray([_bitmap_pixel_value(px) for px in simulation_bitmap.pixels], dtype=np.uint16)
            # 8-bit gray -> OBI-aligned 16-bit (gray * 64 raw 14-bit, << 2), because the
            # display below takes the high byte with ``>> 8``.
            img = flat.reshape(
                int(simulation_bitmap.height),
                int(simulation_bitmap.width),
            ) * 256
            img = orient_image(img)
            fig, ax = plt.subplots(figsize=(6, 6))
            vmin, vmax = _percentile_clip_uint16(img)
            if view == "texture":
                ax.imshow(img, cmap="gray", interpolation="nearest",
                          aspect="equal", vmin=vmin, vmax=vmax)
                ax.set_axis_off()
                fig.subplots_adjust(left=0, right=1, top=1, bottom=0)
            else:
                bounds = orient_bounds(_roi_bounds(last.get("roi")))
                extent = None
                if bounds is not None:
                    x0, x1, y0, y1 = bounds
                    extent = [x0, x1, y1, y0]
                im = ax.imshow(
                    img >> 8,
                    cmap="gray",
                    interpolation="nearest",
                    aspect="equal",
                    vmin=0,
                    vmax=255,
                    extent=extent,
                )
                ax.set_title(f"{last['kind'].title()} scan: extracted ROI source")
                ax.set_xlabel("X (DAC code)" if bounds is not None else "X (pixels)")
                ax.set_ylabel("Y (DAC code)" if bounds is not None else "Y (pixels)")
                fig.colorbar(im, ax=ax, label="ADC sample (14-bit code << 2)")
        elif last["kind"] == "raster":
            res = last["resolution"]
            dwell = int(last.get("dwell") or self._raster_defaults.get("dwell") or 0)
            adc_latency = int(self._raster_defaults.get("adcLatency", 8))
            regions = last.get("parallel_rois")
            if regions:
                flat = np.fromiter((v for chunk in last["chunks"] for v in chunk), dtype=np.uint16)
                img = np.zeros((res, res), dtype=np.uint16)
                region_size = res * res
                for index, region in enumerate(regions):
                    part = flat[index * region_size:(index + 1) * region_size]
                    if part.size < region_size:
                        part = np.pad(part, (0, region_size - part.size))
                    source = _raster_image_from_chunks([part], res, dwell, adc_latency)
                    x0, x1, y0, y1 = _roi_bounds(region)
                    left = max(0, min(res - 1, math.floor(x0 / 16383 * res)))
                    top = max(0, min(res - 1, math.floor(y0 / 16383 * res)))
                    right = max(left + 1, min(res, math.ceil(x1 / 16383 * res)))
                    bottom = max(top + 1, min(res, math.ceil(y1 / 16383 * res)))
                    xs = (np.arange(right - left) * res // (right - left)).astype(int)
                    ys = (np.arange(bottom - top) * res // (bottom - top)).astype(int)
                    img[top:bottom, left:right] = source[np.ix_(ys, xs)]
            else:
                img = _raster_image_from_chunks(last["chunks"], res, dwell, adc_latency)
            img = orient_image(img)

            fig, ax = plt.subplots(figsize=(6, 6))
            # Stretch to the data (trimming dropout / hot pixels) in both views.
            # The old figure view used a fixed 0..255 window on ``img >> 8``,
            # which squeezed a detector signal living in ~0x8000..0xb000 into a
            # washed-out gray band.
            vmin, vmax = _percentile_clip_uint16(img, _FIGURE_CLIP_LO_PCT, _FIGURE_CLIP_HI_PCT)
            im = ax.imshow(img, cmap="gray", interpolation="nearest",
                           aspect="equal", vmin=vmin, vmax=vmax)
            if view == "texture":
                ax.set_axis_off()
                fig.subplots_adjust(left=0, right=1, top=1, bottom=0)
            else:
                ax.set_title(f"Raster scan: {res}x{res}")
                ax.set_xlabel("X (pixels)")
                ax.set_ylabel("Y (pixels)")
                fig.colorbar(im, ax=ax, label="ADC sample (14-bit code << 2)")
        else:
            # ---------- vector ----------------------------------------
            DAC_RANGE = 16384
            DEFAULT_EDGE = 2048
            edge = int(last.get("vector_resolution") or DEFAULT_EDGE)
            samples = np.fromiter(
                (v for chunk in last["chunks"] for v in chunk),
                dtype=np.uint16,
            )
            pattern = last.get("pattern", "default")
            scan_path = VectorScanPath(last.get("scan_path", VectorScanPath.vertical_raster.value))
            points = last.get("points")
            if pattern == "custom" and points:
                iter_list = [
                    (x, y, dwell)
                    for x, y, dwell, _blank, _pass_index in (
                        _normalize_vector_point(point) for point in points
                    )
                ]
            else:
                regions = last.get("parallel_rois")
                iter_list = list(_parallel_roi_iter(edge, regions, 1, scan_path)) if regions else list(_roi_vector_iter(edge, last.get("roi"), scan_path=scan_path))
                if len(iter_list) < samples.size and edge != DEFAULT_EDGE:
                    iter_list = list(_roi_vector_iter(DEFAULT_EDGE, last.get("roi"), scan_path=scan_path))

            if len(iter_list) < samples.size:
                samples = samples[:len(iter_list)]
            elif len(iter_list) > samples.size:
                iter_list = iter_list[:samples.size]

            line_shift = (
                self._vector_defaults.get("lineShiftPerXRow", 0)
                if scan_path is VectorScanPath.vertical_raster else 0
            )
            if line_shift and iter_list:
                first_x = iter_list[0][0]
                row_len = 0
                for point in iter_list:
                    if point[0] != first_x:
                        break
                    row_len += 1
                if row_len > 0 and len(iter_list) % row_len == 0:
                    rows = len(iter_list) // row_len
                    corrected = samples.reshape((rows, row_len)).copy()
                    for x_row in range(rows):
                        corrected[x_row] = np.roll(
                            corrected[x_row],
                            int(round(x_row * float(line_shift))),
                        )
                    samples = corrected.reshape(samples.shape)

            xs = np.fromiter((p[0] for p in iter_list), dtype="float32",
                             count=len(iter_list))
            ys = np.fromiter((p[1] for p in iter_list), dtype="float32",
                             count=len(iter_list))
            if rotate90:
                xs, ys = ys.copy(), xs.copy()
            if xflip:
                xs = 16383 - xs
            if yflip:
                ys = 16383 - ys
            cs = samples
            fig, ax = plt.subplots(figsize=(6, 6))
            vmin, vmax = _percentile_clip_uint16(samples, _FIGURE_CLIP_LO_PCT, _FIGURE_CLIP_HI_PCT)
            marker_size = 8 if view == "texture" else 2
            im = ax.scatter(xs, ys, c=cs, cmap="gray", s=marker_size,
                            vmin=vmin, vmax=vmax, marker="s")
            bounds = orient_bounds(_roi_bounds(last.get("roi")))
            if view == "texture" and bounds is not None:
                x0, x1, y0, y1 = bounds
                ax.set_xlim(x0, x1)
                ax.set_ylim(y1, y0)
            else:
                ax.set_xlim(0, self._vector_defaults.get("xResolution") or 16384)
                ax.set_ylim(self._vector_defaults.get("yResolution") or 16384, 0)
            ax.set_aspect("equal")
            if view == "texture":
                ax.set_axis_off()
                fig.subplots_adjust(left=0, right=1, top=1, bottom=0)
            else:
                ax.set_title(f"Vector scan: {len(iter_list)} points")
                ax.set_xlabel("X (DAC code)")
                ax.set_ylabel("Y (DAC code)")
                fig.colorbar(im, ax=ax, label="ADC sample (14-bit code << 2)")

        out = io.BytesIO()
        if view != "texture":
            fig.tight_layout()
        fig.savefig(
            out,
            format="png",
            dpi=120,
            bbox_inches=None if view == "texture" else "tight",
            pad_inches=0 if view == "texture" else 0.1,
            transparent=view == "texture",
            metadata=metadata,
        )
        plt.close(fig)
        return out.getvalue()

    # -------- validation --------------------------------------------------

    def _validate_raster(self, chunks: List, pixels_per_chunk: int,
                         expected_chunks: int) -> ScanValidation:
        checks: List[ValidationCheck] = []
        checks.append(ValidationCheck(
            name="chunk_count",
            passed=len(chunks) == expected_chunks,
            detail=f"expected {expected_chunks}, got {len(chunks)}",
        ))
        full_bytes = pixels_per_chunk * 2
        bad_sizes = [(i, len(c) * 2) for i, c in enumerate(chunks[:-1])
                     if len(c) * 2 != full_bytes]
        checks.append(ValidationCheck(
            name="full_chunk_sizes",
            passed=not bad_sizes,
            detail=(f"all non-tail chunks = {full_bytes} bytes"
                    if not bad_sizes
                    else f"mismatched chunks: {bad_sizes[:5]}"),
        ))
        if chunks:
            tail = len(chunks[-1]) * 2
            checks.append(ValidationCheck(
                name="tail_chunk_size",
                passed=0 < tail <= full_bytes,
                detail=f"tail = {tail} bytes (max {full_bytes})",
            ))
        return ScanValidation(passed=all(c.passed for c in checks), checks=checks)

    def _validate_vector(self, chunks: List) -> ScanValidation:
        checks: List[ValidationCheck] = []
        checks.append(ValidationCheck(
            name="non_zero_chunks", passed=len(chunks) > 0,
            detail=f"received {len(chunks)} chunks"))
        empties = [i for i, c in enumerate(chunks) if len(c) == 0]
        checks.append(ValidationCheck(
            name="all_chunks_non_empty", passed=not empties,
            detail=("all non-empty" if not empties
                    else f"empty chunk indices: {empties[:5]}")))
        return ScanValidation(passed=all(c.passed for c in checks), checks=checks)

    # -------- state lock --------------------------------------------------

    def _acquire(self, kind: str, *, transport: str = "service"):
        svc = self
        class _Ctx:
            async def __aenter__(self):
                acquired = False
                if svc._lock.locked() or svc._status.state is DeviceState.BUSY:
                    # The previous scan was told to stop (operator Stop, or
                    # its browser stream closed) and is only cleaning up:
                    # wait for it instead of reporting a bare "busy".
                    if not (svc._lock.locked() and getattr(svc, "_scan_aborted", False)):
                        raise DeviceBusy(svc._busy_detail())
                    logger.info("scan start kind=%s waiting up to %.0fs for the stopped "
                                "scan to release the device (%s)", kind,
                                _BUSY_WAIT_AFTER_ABORT_S, svc._busy_detail())
                    try:
                        await asyncio.wait_for(svc._lock.acquire(), _BUSY_WAIT_AFTER_ABORT_S)
                    except asyncio.TimeoutError:
                        raise DeviceBusy(svc._busy_detail()) from None
                    acquired = True
                # IDLE, ERROR, DISCONNECTED are all OK to start from — the
                # _ensure_conn() call inside the scan will (re)open as needed.
                if svc._status.state is DeviceState.CONNECTING:
                    if acquired:
                        svc._lock.release()
                    raise DeviceNotReady("device is connecting")
                if not acquired:
                    await svc._lock.acquire()
                svc._abort_requested = False
                svc._scan_aborted = False
                svc._active_scan = {
                    "kind": kind, "transport": transport,
                    "started": time.monotonic(), "owner": asyncio.current_task(),
                }
                svc._status.state = DeviceState.BUSY
                svc._status.last_error = None
                svc._status.chunks_in_flight = 0
                self.started = time.monotonic()
                logger.info("scan start kind=%s production=%s transport=%s", kind,
                            getattr(svc._config, "IsProduction", None), transport)
                return svc
            async def __aexit__(self, exc_type, exc, tb):
                # A streaming client closing its WebSocket causes the async
                # generator to be closed with GeneratorExit. Treat that (and
                # task cancellation) as a normal, incomplete capture rather
                # than a device fault; the generator's finally block still
                # owns hardware cleanup.
                cancelled = exc_type is not None and issubclass(
                    exc_type, (GeneratorExit, asyncio.CancelledError))
                # An operator Stop (/scan/abort or the client closing the
                # stream) that ended the scan normally is a cancellation too;
                # without this a stopped live scan logged cancelled=False.
                aborted = bool(getattr(svc, "_scan_aborted", False))
                cancelled = cancelled or (aborted and exc is None)
                if exc is None:
                    svc._status.scans_completed += 1
                elif cancelled:
                    svc._status.last_error = None
                else:
                    svc._status.last_error = f"{type(exc).__name__}: {exc}"
                # If we still have a connection, we're IDLE; otherwise reflect that.
                if svc._conn is None:
                    svc._status.state = (
                        DeviceState.ERROR if exc and not cancelled else DeviceState.IDLE)
                else:
                    svc._status.state = DeviceState.IDLE
                chunks = svc._status.chunks_in_flight
                svc._status.chunks_in_flight = 0
                svc._release_device_if_idle()
                svc._active_scan = None
                stop_s = (time.monotonic() - svc._abort_time
                          if aborted and getattr(svc, "_abort_time", None) else None)
                svc._scan_aborted = False
                svc._lock.release()
                logger.info("scan end kind=%s ok=%s cancelled=%s elapsed=%.3fs "
                            "transport=%s chunks=%d error=%s%s",
                            kind, exc is None, cancelled, time.monotonic() - self.started,
                            transport, chunks, None if exc is None or cancelled
                            else f"{type(exc).__name__}: {exc}",
                            "" if stop_s is None else f" stop_to_release={stop_s:.3f}s")
                return False
        return _Ctx()
