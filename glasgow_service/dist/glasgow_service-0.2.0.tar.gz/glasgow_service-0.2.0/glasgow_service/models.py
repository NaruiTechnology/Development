"""Pydantic models shared between the service and the API layer.

API change in this revision: CSV output is no longer a side effect of a
scan run. The browser pulls CSV / PNG figure bytes on demand from
/scan/last/* endpoints. So `save_csv`, `csv_dir`, and `csv_path` are
gone, replaced by `has_data` on the result so the UI knows when the
download buttons can be enabled.

`output_mode` was added to RasterRequest in the scan-params refactor.
It was already a field on RasterScanCommand (defaulting to SixteenBit)
but had no way to flow through the REST API — VectorRequest had it,
RasterRequest didn't, so hardware always got the default. Adding it
here closes that gap. Defaulting to "SixteenBit" keeps the wire format
backward compatible with frontends that don't send the field yet.
"""
from enum import Enum
from typing import List, Literal, Optional, Tuple, Union
from pydantic import BaseModel, Field, field_validator, model_validator


class DeviceState(str, Enum):
    DISCONNECTED = "disconnected"
    CONNECTING   = "connecting"
    IDLE         = "idle"
    BUSY         = "busy"
    ERROR        = "error"


class ServiceStatus(BaseModel):
    state: DeviceState
    last_error: Optional[str] = None
    scans_completed: int = 0
    chunks_in_flight: int = 0


# ---------- vacuum GPIO ---------------------------------------------------

class VacuumPowerRequest(BaseModel):
    power: bool


class VacuumSimulationRequest(BaseModel):
    ready: bool


class VacuumAcquireRequest(BaseModel):
    expected_channels: dict[str, float] = Field(default_factory=dict)


class VacuumPumpState(BaseModel):
    name: str
    power: bool
    threshold: float
    value: Optional[float] = None
    port_a_value: float = 0.0
    port_b_value: float = 0.0
    write: str
    read: str
    border: Literal["off", "waiting", "ready", "error"] = "off"
    ready: bool = False
    group: Optional[str] = None
    simulation_read: bool = False
    # Board mode: False = the pump's "healthy" input is open (fault); None
    # when no fault input is configured for this pump.
    fault: Optional[bool] = None
    # Isolation valve of this pump ("V2"); None when the hardware has no
    # valve for it.  ``valve_open`` is the controller's valve state (board:
    # read back from the solenoid driver).  The dashboard slide switch shows it.
    valve: Optional[str] = None
    valve_open: bool = False
    # True while the pump runs but its reading has risen above its value
    # after it had been ready (vacuum excursion): valve closed, card red.
    excursion: bool = False


class VacuumSystemStatus(BaseModel):
    device_id: str
    voltage: float
    connected: bool
    simulation: bool
    # Derived from Simulate in the SBC vacuum profile for backward-compatible API status.
    is_production: bool = True
    control_transport: Literal[
        "sbc-simulation", "raspberry-pi-gpio", "rpi5-vacuum-io", "rpi5-vacuum-io-emulator"
    ]
    running: bool
    runtime_seconds: float = 0.0
    cascade_stopped: bool
    # Why the cascade is stopped: device_error (clears itself after healthy
    # polls), restart, operator or safety (both need /vacuum/resume); None
    # while the cascade runs automatically.
    cascade_latch: Optional[str] = None
    # A backing-pump restart (power cycle) is in progress.
    restarting: bool = False
    isVacuumSystemReady: bool = False
    high_voltage_power: bool = False
    last_error: Optional[str] = None
    updated_at: Optional[str] = None
    pumps: List[VacuumPumpState]
    # Active interlock conditions (E-stop, output rail, pump faults). These
    # are not communication errors, so they do not affect ``connected``.
    alarms: List[str] = Field(default_factory=list)
    # Vacuum I/O board readback (rails, all 16 inputs, relays, solenoids).
    board: Optional[dict] = None


# ---------- requests -------------------------------------------------------

class RasterRequest(BaseModel):
    resolution:    int  = Field(512,   ge=1, le=2048, description="DAC range (NxN).")
    dwell:         int  = Field(2,     ge=0, le=65535, description="A dwell of N averages N + 1 ADC samples (125 ns each with the current revC3 timing); 0 is the upstream OBI one-sample setting.")
    latency_bytes: int  = Field(16384, ge=2, description="`latency` passed to transfer_multiple.")
    frame_blank:   bool = True
    cookie:        int  = Field(123, ge=0, le=0xFFFF)
    # New in scan-params refactor. Was previously hardcoded to SixteenBit
    # inside the macro because the API had no field for it.
    output_mode:   str  = Field("SixteenBit", description="SixteenBit or EightBit.")
    adc_valid:     bool = Field(True, description="Run the production ADC presence/saturation check.")
    beam_type:     str  = Field("Ion", description="NoBeam, Electron, or Ion.")
    external_control: bool = Field(True, description="Drive external beam control pins during the scan.")
    continuous: bool = Field(
        False,
        description=(
            "WebSocket stream only (Infinite / live scan): keep scanning frame after "
            "frame on one synchronized FPGA command stream until /scan/abort, like "
            "OBI's live scan. Pixels stream continuously and wrap at the frame end; "
            "the `done` event is sent only after Stop. Ignored by /scan/raster/run."
        ),
    )

    frames: Optional[int] = Field(
        None, ge=1, le=100000,
        description=(
            "With `continuous`: end the session by itself after this many frames "
            "(Repeat N). External control is taken once at the start and held for "
            "every frame, then handed back after the last. The caller computes N; "
            "null runs until /scan/abort."
        ),
    )

    # Wet-run extras (REST only; WebSocket streaming ignores these):
    do_validate: bool = Field(True, description="Run chunk-count / size checks and return the report.")
    roi: Optional["ROIRequest"] = Field(
        default=None,
        description="Optional DAC-code ROI bounds. Coordinates are inclusive 0..16383.",
    )
    parallel_rois: Optional[List["ROIRequest"]] = Field(
        default=None, min_length=2,
        description="ROI bounds traversed in one command stream, in display order.",
    )
    parallel_simulation_bitmaps: Optional[List["SimulationBitmap"]] = None
    parallel_simulation_bitmap_ids: Optional[List[str]] = None
    simulation_bitmap_id: Optional[str] = None
    simulation_bitmap: Optional["SimulationBitmap"] = Field(
        default=None,
        description=(
            "Optional browser-provided grayscale crop for simulation-only raster scans. "
            "Ignored for production hardware."
        ),
    )
    simulation: Optional[dict] = Field(
        default=None,
        description="Browser-session simulation override. Ignored in production mode.",
    )

    model_config = {
        "json_schema_extra": {
            "examples": [
                {"resolution": 512,  "dwell": 2, "latency_bytes": 16384,
                 "frame_blank": False, "output_mode": "SixteenBit",
                 "beam_type": "Ion", "external_control": True,
                 "do_validate": True},
                {"resolution": 1024, "dwell": 3, "latency_bytes": 16384,
                 "frame_blank": False, "output_mode": "SixteenBit",
                 "beam_type": "Ion", "external_control": True,
                 "do_validate": True},
            ]
        }
    }


class DacRampAxis(str, Enum):
    x = "x"
    y = "y"


class DacRampRequest(BaseModel):
    """Single-axis DAC linearity/ramp check.

    Production port of upstream OBI's manual_dac_ctrl.RampControl, which
    this fork never carried over. Sweeps one DAC axis across its full
    14-bit range while the other axis is held at `fixed_code`, using the
    same RasterScanCommand / UpstreamBusController path as
    `/scan/raster/run` — not a separate diagnostic implementation that can
    drift out of sync with production.

    Use this (not `/scan/vector/run` with its default `scan_path`) to
    check DAC output against a reference OBI capture: vertical_raster's
    default axis order makes the slow axis look like a staircase on a
    scope, which is a scan-pattern artifact, not a DAC fault.
    """
    axis:          DacRampAxis = DacRampAxis.x
    fixed_code:    int  = Field(8192, ge=0, le=16383,
                                 description="DAC code held on the non-swept axis.")
    dwell:         int  = Field(500,  ge=0, le=65535,
                                 description="ADC cycles per DAC code (OBI RampControl default: 500).")
    latency_bytes: int  = Field(16384, ge=2, description="`latency` passed to transfer_multiple.")
    cookie:        int  = Field(123, ge=0, le=0xFFFF)
    beam_type:     str  = Field("Ion", description="NoBeam, Electron, or Ion.")
    external_control: bool = Field(True, description="Drive external beam control pins during the scan.")
    adc_valid:     bool = Field(True, description="Run the production ADC presence/saturation check.")


class BeamHoldState(str, Enum):
    on = "on"            # beam unblanked: checks the blank takeover
    blanked = "blanked"  # beam held blanked by us: checks the blank level


class BeamHoldScanPlan(BaseModel):
    """The scan a beam hold reproduces: same frames, frame time and Frame
    blank, with the beam parked. Sent by the UI from the current scan
    settings, so the takeover lasts exactly as long as that scan's would."""
    frame_pixels: int  = Field(..., ge=1, le=268_435_456,
                               description="Pixels (raster) or points (vector) in one frame/pass.")
    dwell:        int  = Field(..., ge=0, le=65535, description="The scan's dwell (dwell + 1 conversions per pixel).")
    frames:       int  = Field(1, ge=1, le=100_000, description="Frames in the session (Repeat N).")
    frame_blank:  Optional[bool] = Field(
        None, description="The scan's Frame blank; null uses the service default, as a vector scan does.")


class BeamHoldRequest(BaseModel):
    """Park the beam on one DAC position and record the detector over time.

    Diagnostic for the blank takeover. It runs exactly when a scan with the
    same settings would use the hardware: IsProduction=true, or
    IsProduction=false with simulation switched off (a bench setup).
    With `external_control` the scan and blank-enable relays switch to
    Glasgow exactly as for a scan; the beam is held unblanked (`beam=on`) or
    blanked (`beam=blanked`) with X/Y frozen, so any periodic dark dip in the
    recorded signal comes from outside our scan: typically the instrument's
    own blanker still reaching the column. With `external_control=false`
    nothing is taken over, which records the instrument's own behaviour.

    With `match` (the UI always sends it) the hold reproduces that scan's
    takeover: the same number of frames, each lasting as long as one scan
    frame, with the scan's Frame blank between them. It ends by itself after
    the last frame, like the scan, and hands control back. No timer.
    Without `match`, `duration_s` bounds the hold instead.
    """
    x_code:        int  = Field(8192, ge=0, le=16383, description="DAC code the beam is parked on (X).")
    y_code:        int  = Field(8192, ge=0, le=16383, description="DAC code the beam is parked on (Y).")
    beam:          BeamHoldState = BeamHoldState.on
    dwell:         int  = Field(7, ge=0, le=65535,
                                description="Sampling dwell of the recorded trace; 7 gives ~1 us at 8 MHz.")
    match:         Optional[BeamHoldScanPlan] = Field(
        None, description="Reproduce this scan's takeover (frames, frame time, Frame blank).")
    duration_s:    Optional[float] = Field(
        None, gt=0, le=600, description="Without `match`: stop after this many seconds (default 30).")
    latency_bytes: int  = Field(16384, ge=2, description="`latency` passed to transfer_multiple.")
    cookie:        int  = Field(125, ge=0, le=0xFFFF)
    external_control: bool = Field(True, description="Take over the scan and blank-enable relays while holding.")
    adc_valid:     bool = Field(True, description="Run the production ADC presence/saturation check.")
    simulation:    Optional[dict] = Field(
        None, description="The browser's session simulation override, as scan requests carry it. "
                          "Beam hold runs only when a scan with the same settings would use the hardware.")


class AdcTestRequest(BaseModel):
    """Bounded, DAC-free ADC acquisition request."""
    duration_minutes: Literal[5, 10, 15, 20] = 5
    simulation: bool = Field(
        False,
        description="Use the seeded FPGA random source instead of physical ADC pins.",
    )
    seed: int = Field(42, ge=1, le=0x3FFF)
    chunk_bytes: int = Field(65536, ge=1024, le=1024 * 1024)

    @field_validator("chunk_bytes")
    @classmethod
    def _chunk_bytes_are_even(cls, value: int) -> int:
        if value & 1:
            raise ValueError("chunk_bytes must be even for uint16 samples")
        return value


class VectorPattern(str, Enum):
    default = "default"
    custom  = "custom"
    # Service-generated beam-spot lattice (see exposure_lattice.py); no point list is sent.
    lattice = "lattice"


class VectorScanPath(str, Enum):
    vertical_raster = "vertical_raster"
    vertical_serpentine = "vertical_serpentine"
    horizontal_sawtooth = "horizontal_sawtooth"
    horizontal_triangle = "horizontal_triangle"


class VectorFeedbackMode(str, Enum):
    standard = "standard"
    adaptive_gray_feedback = "adaptive_gray_feedback"


class VectorPoint(BaseModel):
    x: int = Field(..., ge=0, le=16383)
    y: int = Field(..., ge=0, le=16383)
    dwell: int = Field(..., ge=0, le=65535)
    blank: Optional[bool] = None
    passIndex: Optional[int] = Field(None, ge=1, le=2)


class SimulationBitmap(BaseModel):
    width:  int = Field(..., ge=1, le=4096)
    height: int = Field(..., ge=1, le=4096)
    pixels: List[Union[int, "SimulationBitmapPixel"]] = Field(..., max_length=1_000_000)
    source_roi: Optional["ROIRequest"] = None

    @field_validator("pixels")
    @classmethod
    def _pixels_are_bytes(cls, v: List[int]) -> List[int]:
        for px in v:
            if isinstance(px, SimulationBitmapPixel):
                value = px.value
            else:
                value = int(px)
            if value < 0 or value > 255:
                raise ValueError("simulation_bitmap pixels must be 0..255")
        return v


class SimulationBitmapPixel(BaseModel):
    value: int = Field(..., ge=0, le=255)
    isHighlighted: Optional[bool] = None
    isSkipped: Optional[bool] = None
    blank: Optional[bool] = None


class LatticeRect(BaseModel):
    kind: Literal["rect"] = "rect"
    x0: float = Field(..., ge=0, le=16383)
    x1: float = Field(..., ge=0, le=16383)
    y0: float = Field(..., ge=0, le=16383)
    y1: float = Field(..., ge=0, le=16383)


class LatticeEllipse(BaseModel):
    """Solid ellipse, or a ring when both inner radii are given. DAC codes."""
    kind: Literal["ellipse"] = "ellipse"
    cx: float = Field(..., ge=0, le=16383)
    cy: float = Field(..., ge=0, le=16383)
    rx: float = Field(..., gt=0, le=16383)
    ry: float = Field(..., gt=0, le=16383)
    inner_rx: float = Field(0.0, ge=0, le=16383)
    inner_ry: float = Field(0.0, ge=0, le=16383)


class LatticePolygon(BaseModel):
    kind: Literal["polygon"] = "polygon"
    points: List[Tuple[float, float]] = Field(..., min_length=3, max_length=4096)


class LatticeFrame(BaseModel):
    """Frame exposure: include the outer polygon except its inner polygon."""
    kind: Literal["frame"] = "frame"
    outer: List[Tuple[float, float]] = Field(..., min_length=3, max_length=4096)
    inner: List[Tuple[float, float]] = Field(..., min_length=3, max_length=4096)


class LatticeRequest(BaseModel):
    """Shape and spacing of a physically-spaced exposure, in DAC codes.

    The client converts spot size and overlap (um) to DAC-code pitch using the field width,
    so the service needs no calibration knowledge. `dwell` is in ADC-average ticks (N + 1
    conversions), as for `VectorRequest.dwell`.
    """
    shape: Union[LatticeRect, LatticeEllipse, LatticePolygon, LatticeFrame] = Field(..., discriminator="kind")
    pitch_x: float = Field(..., gt=0, description="Spot spacing along X, DAC codes (may be < 1).")
    pitch_y: Optional[float] = Field(None, gt=0, description="Spot spacing along Y; defaults to pitch_x.")
    axis: Literal["long", "x", "y"] = "long"
    dwell: int = Field(..., ge=0, le=65535)
    passes: int = Field(1, ge=1, le=100000)
    cell_start: int = Field(0, ge=0, description="First serpentine lattice cell, inclusive.")
    cell_end: Optional[int] = Field(None, ge=1, description="Last serpentine lattice cell, exclusive.")

    @model_validator(mode="after")
    def _check_geometry(self):
        # Local import keeps models.py free of scan code until a lattice is actually used.
        from .exposure_lattice import MAX_LATTICE_POINTS, build_lattice, total_points
        from .exposure_lattice_adapter import shape_from_request
        shape = shape_from_request(self.shape)
        lattice = build_lattice(shape, self.pitch_x, self.pitch_y, self.axis)
        end = self.cell_end if self.cell_end is not None else lattice.nx * lattice.ny
        if not 0 <= self.cell_start < end <= lattice.nx * lattice.ny:
            raise ValueError("invalid lattice cell range")
        if total_points(shape, lattice, self.passes) > MAX_LATTICE_POINTS:
            raise ValueError(f"lattice exceeds {MAX_LATTICE_POINTS:,} points; increase the pitch or reduce passes")
        return self


class VectorRequest(BaseModel):
    pattern:        VectorPattern = VectorPattern.default
    # Default matches the frontend's VECTOR_SCAN_PATHS ordering (see
    # ionbeam-web/frontend/src/lib/vectorScanPath.ts): horizontal paths
    # (X fast/inner axis) sweep the axis a scope probe is usually on
    # continuously, matching a reference OBI capture. vertical_raster
    # (the old default) makes X the slow/outer axis, which looks like a
    # staircase on a scope even though nothing is actually wrong with the
    # DAC — see /scan/dac_ramp/run for the dedicated single-axis check.
    scan_path:      VectorScanPath = VectorScanPath.horizontal_sawtooth
    points:         Optional[List[Union[
        Tuple[int, int, int],
        Tuple[int, int, int, Optional[bool]],
        Tuple[int, int, int, Optional[bool], Optional[int]],
        VectorPoint,
    ]]] = Field(
        default=None,
        description=(
            "For `custom`: list of (x, y, dwell), (x, y, dwell, blank), "
            "(x, y, dwell, blank, passIndex) tuples or {x, y, dwell, blank, passIndex} objects. "
            "Capped at 1M points."
        ),
        max_length=1_000_000,
    )
    # Density of the default sweep across the 2048-DAC range. Stride is
    # derived as 2048 // vector_resolution; only divisors of 2048 produce
    # an integer stride. Ignored when pattern=custom.
    vector_resolution: int = Field(
        1024,
        description=(
            "Default-pattern sample density on each axis. Allowed: 1..2048. "
            "Coverage is always full DAC range; smaller values just sample sparser. "
            "Ignored when pattern=custom."
        ),
    )
    dwell:          int  = Field(
        7,
        ge=0,
        le=65535,
        description="Default-pattern dwell: N averages N + 1 ADC samples (125 ns each with the current revC3 timing). Ignored when pattern=custom.",
    )
    latency_bytes:  int  = Field(8196, ge=2, description="Matches `vectorScan.latency` in streamData.json.")
    output_mode:    str  = Field("SixteenBit", description="SixteenBit or EightBit.")
    adc_valid:      bool = Field(True, description="Run the production ADC presence/saturation check.")
    feedback_mode:  VectorFeedbackMode = Field(
        VectorFeedbackMode.standard,
        description="Vector blanking mode. adaptive_gray_feedback enables host-side feedback blanking.",
    )
    gray_level_range: Optional[Tuple[int, int]] = Field(
        default=None,
        description="Confirmed gray-level interval in 8-bit UI units (0..255).",
    )
    gray_level_skipped: Optional[bool] = Field(
        default=None,
        description="True blanks values inside the range; false blanks values outside it.",
    )
    target_gray_level: Optional[int] = Field(
        default=None, ge=0, le=255,
        description="Simulation-only ROI target: lower brighter source pixels toward this level after each pass.",
    )
    beam_type:      str  = Field("Ion", description="NoBeam, Electron, or Ion.")
    external_control: bool = Field(True, description="Drive external beam control pins during the scan.")
    cookie:         int  = Field(123, ge=0, le=0xFFFF)
    continuous:     bool = Field(
        False,
        description=(
            "WebSocket stream only (Infinite / live scan): replay the point list pass "
            "after pass on one synchronized FPGA command stream until /scan/abort, "
            "like OBI's live scan. Samples stream continuously and wrap at the pass "
            "end; `done` is sent only after Stop. Ignored by /scan/vector/run and "
            "with feedback_mode=adaptive_gray_feedback."
        ),
    )

    frames: Optional[int] = Field(
        None, ge=1, le=100000,
        description=(
            "With `continuous`: end the session by itself after this many passes "
            "(Repeat N); with adaptive_gray_feedback, runs that many host-decided "
            "passes on one command stream. External control is taken once at the start and held for "
            "every pass, then handed back after the last. The caller computes N; "
            "null runs until /scan/abort."
        ),
    )

    # Wet-run extras (REST only):
    pre_process:    bool = Field(False, description="Call _pre_process_chunks before transfer; time it separately.")
    do_validate:    bool = Field(True,  description="Run chunk presence checks and return the report.")
    roi:            Optional["ROIRequest"] = Field(
        default=None,
        description="Optional DAC-code ROI bounds. Coordinates are inclusive 0..16383.",
    )
    parallel_rois: Optional[List["ROIRequest"]] = Field(
        default=None, min_length=2,
        description="ROI bounds traversed in one command stream, in display order.",
    )
    parallel_simulation_bitmaps: Optional[List[SimulationBitmap]] = None
    parallel_simulation_bitmap_ids: Optional[List[str]] = None
    simulation_bitmap_id: Optional[str] = None
    simulation_bitmap: Optional[SimulationBitmap] = Field(
        default=None,
        description=(
            "Optional browser-provided grayscale crop for simulation-only vector scans. "
            "Ignored for production hardware."
        ),
    )
    simulation: Optional[dict] = Field(
        default=None,
        description="Browser-session simulation override. Ignored in production mode.",
    )
    lattice: Optional[LatticeRequest] = Field(
        default=None,
        description="Required for pattern=lattice: shape, pitch, axis, dwell and passes; the service streams the spots.",
    )

    @model_validator(mode="after")
    def _check_lattice(self):
        if (self.pattern is VectorPattern.lattice) != (self.lattice is not None):
            raise ValueError("`lattice` is required for, and only valid with, pattern=lattice")
        if self.pattern is VectorPattern.lattice and self.pre_process:
            # pre_process encodes every point into memory before transfer; a lattice may have millions.
            raise ValueError("pre_process is not supported with pattern=lattice (the stream is generated lazily)")
        return self

    @field_validator("vector_resolution")
    @classmethod
    def _check_vector_resolution(cls, v: int) -> int:
        if v < 1 or v > 2048:
            raise ValueError(f"vector_resolution must be between 1 and 2048; got {v}")
        return v

    @field_validator("gray_level_range")
    @classmethod
    def _check_gray_level_range(cls, v: Optional[Tuple[int, int]]) -> Optional[Tuple[int, int]]:
        if v is None:
            return None
        if len(v) != 2:
            raise ValueError("gray_level_range must contain exactly two entries")
        lo = int(v[0])
        hi = int(v[1])
        if lo < 0 or lo > 255 or hi < 0 or hi > 255:
            raise ValueError("gray_level_range entries must be 0..255")
        return (min(lo, hi), max(lo, hi))

    model_config = {
        "json_schema_extra": {
            "examples": [
                {"pattern": "default", "vector_resolution": 2048,
                 "dwell": 1, "latency_bytes": 8196, "pre_process": True, "do_validate": True},
                {"pattern": "default", "vector_resolution": 512,
                 "dwell": 4, "latency_bytes": 8196, "pre_process": True, "do_validate": True},
                {"pattern": "custom",
                 "points": [[0, 0, 2], [100, 100, 2], [200, 100, 2], [200, 200, 2]],
                 "latency_bytes": 8196, "do_validate": True},
            ]
        }
    }


# ---------- results --------------------------------------------------------

class ValidationCheck(BaseModel):
    name:   str
    passed: bool
    detail: Optional[str] = None


class ScanValidation(BaseModel):
    passed: bool
    checks: List[ValidationCheck]


class ScanResult(BaseModel):
    """Unified result for both raster and vector blocking scans.

    `has_data=True` means the server is holding the chunk buffer for this
    scan in memory, so /scan/last/csv and /scan/last/figure will return
    its contents.
    """
    kind:             str              # "raster" or "vector"
    chunks:           int
    bytes:            int

    # raster-only (None for vector):
    resolution:       Optional[int]   = None
    dwell:            Optional[int]   = None
    expected_chunks:  Optional[int]   = None
    pixels_per_chunk: Optional[int]   = None

    # vector-only (None for raster):
    process_time_s:   Optional[float] = None

    # shared:
    send_time_s:      Optional[float] = None
    has_data:         bool            = False
    validation:       Optional[ScanValidation] = None


class ROIRequest(BaseModel):
    x_start: float = Field(..., ge=0, le=16383)
    x_end:   float = Field(..., ge=0, le=16383)
    y_start: float = Field(..., ge=0, le=16383)
    y_end:   float = Field(..., ge=0, le=16383)

    @field_validator("x_end")
    @classmethod
    def _x_nonempty(cls, v: int, info) -> int:
        start = info.data.get("x_start")
        if start is not None and v == start:
            raise ValueError("x_end must differ from x_start")
        return v

    @field_validator("y_end")
    @classmethod
    def _y_nonempty(cls, v: int, info) -> int:
        start = info.data.get("y_start")
        if start is not None and v == start:
            raise ValueError("y_end must differ from y_start")
        return v


SimulationBitmap.model_rebuild()
RasterRequest.model_rebuild()
VectorRequest.model_rebuild()
