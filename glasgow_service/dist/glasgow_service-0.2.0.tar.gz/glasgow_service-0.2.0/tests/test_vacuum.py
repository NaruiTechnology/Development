import asyncio
import json
from pathlib import Path

import pytest
from glasgow_service.vacuum import (
    MECHANICAL_PUMP,
    VacuumConfig,
    VacuumController,
    load_vacuum_config,
    vacuum_config_enabled,
)
from glasgow_service.vacuum_device import SimulatedVacuumDevice, VacuumDevice


# A pinned 4-pump profile (vacuumSystem.json as of 8e3d1e3): these tests check
# controller behaviour, not the live equipment list, which changes with the
# installation.  test_live_vacuum_profiles_are_valid covers the live files.
CONFIG_PATH = Path(__file__).parent / "fixtures" / "vacuumSystem.4pump.json"
LIVE_PROFILES = sorted(
    (Path(__file__).parents[2] / "GlasgowDataIO" / "Json").glob("vacuumSystem*.json"))


def make_config(**updates):
    """Stable unit-test fixture derived from, but not controlled by, live settings."""
    payload = json.loads(CONFIG_PATH.read_text())
    config = VacuumConfig.model_validate(payload).model_copy(
        update={"enabled": True, "error_range": 0.005})
    return config.model_copy(update=updates)


def simulated_controller():
    config = make_config(simulate=True)
    controller = VacuumController(config)
    commands: list[str] = []
    return controller, commands


def test_vacuum_config_parses_thresholds_and_port_directions():
    config = make_config()

    assert config.device.id == "raspberry-pi-vacuum"
    assert config.device.voltage == 3.3
    assert config.error_range == pytest.approx(0.005)
    assert [pump.threshold for pump in config.pumps] == [0.1, 0.002, 0.00003, 0.00003]
    assert all(pump.write.startswith("A") for pump in config.pumps)
    assert all(pump.read.startswith("B") for pump in config.pumps)
    assert config.high_voltage_transformer.write == "A4"


def test_vacuum_equipment_count_is_configuration_driven_with_minimum_three():
    payload = json.loads(CONFIG_PATH.read_text())

    three = json.loads(json.dumps(payload))
    three["VacuumPumps"] = three["VacuumPumps"][:3]
    parsed_three = VacuumConfig.model_validate(three)
    assert len(parsed_three.pumps) == 3

    five = json.loads(json.dumps(payload))
    five["VacuumPumps"].append({
        "name": "UHVacuumPump_3",
        "groupName": "UltraHighVacuum",
        "power": "off",
        "value": "4.0e-5",
        "write": "A5",
        "read": "B4",
    })
    five["SBC"]["GPIO"].update({"A5": "GPIO16", "B4": "GPIO13"})
    parsed_five = VacuumConfig.model_validate(five)
    assert [pump.name for pump in parsed_five.pumps][-1] == "UHVacuumPump_3"

    two = json.loads(json.dumps(payload))
    two["VacuumPumps"] = two["VacuumPumps"][:2]
    with pytest.raises(ValueError, match="at least 3"):
        VacuumConfig.model_validate(two)


def test_vacuum_config_requires_unique_names_and_core_sequence_stages():
    payload = json.loads(CONFIG_PATH.read_text())
    payload["VacuumPumps"][1]["name"] = MECHANICAL_PUMP
    with pytest.raises(ValueError, match="names must be unique"):
        VacuumConfig.model_validate(payload)

    payload = json.loads(CONFIG_PATH.read_text())
    payload["VacuumPumps"][0]["name"] = "OtherBackingPump"
    with pytest.raises(ValueError, match="requires MechanicalVacuumPump"):
        VacuumConfig.model_validate(payload)


def test_every_vacuum_equipment_node_declares_a_group_name():
    payload = json.loads(CONFIG_PATH.read_text())
    assert [(p["name"], p["groupName"]) for p in payload["VacuumPumps"]] == [
        ("MechanicalVacuumPump", "MechanicalVacuum"),
        ("TurboVacuumPump", "TurboVacuum"),
        ("UHVacuumPump_1", "UltraHighVacuum"),
        ("UHVacuumPump_2", "UltraHighVacuum"),
    ]
    assert make_config().stages == [
        ("MechanicalVacuum", ["MechanicalVacuumPump"]),
        ("TurboVacuum", ["TurboVacuumPump"]),
        ("UltraHighVacuum", ["UHVacuumPump_1", "UHVacuumPump_2"]),
    ]

    missing = json.loads(CONFIG_PATH.read_text())
    del missing["VacuumPumps"][1]["groupName"]
    with pytest.raises(ValueError, match="groupName"):
        VacuumConfig.model_validate(missing)

    bad = json.loads(CONFIG_PATH.read_text())
    bad["VacuumPumps"][1]["groupName"] = "1 turbo"
    with pytest.raises(ValueError, match="groupName must start with a letter"):
        VacuumConfig.model_validate(bad)


def test_group_name_rules_define_an_unambiguous_cascade():
    split = json.loads(CONFIG_PATH.read_text())
    split["VacuumPumps"][1]["groupName"] = "UltraHighVacuum"
    split["VacuumPumps"][2]["groupName"] = "TurboVacuum"
    with pytest.raises(ValueError, match="is split"):
        VacuumConfig.model_validate(split)

    shared = json.loads(CONFIG_PATH.read_text())
    shared["VacuumPumps"][1]["groupName"] = "MechanicalVacuum"
    with pytest.raises(ValueError, match="first groupName must contain only"):
        VacuumConfig.model_validate(shared)

    single = json.loads(CONFIG_PATH.read_text())
    for pump in single["VacuumPumps"]:
        pump["groupName"] = "Everything"
    with pytest.raises(ValueError, match="first groupName must contain only"):
        VacuumConfig.model_validate(single)

    # The cascade no longer depends on equipment names beyond the backing
    # pump: a renamed turbo works as long as its groupName says where it runs.
    renamed = json.loads(CONFIG_PATH.read_text())
    renamed["VacuumPumps"][1]["name"] = "HiPaceTurbo"
    config = VacuumConfig.model_validate(renamed)
    assert config.stages[1] == ("TurboVacuum", ["HiPaceTurbo"])


def test_sbc_gpio_uses_raspberry_pi_line_names():
    config = make_config()
    assert config.sbc.gpio == {
        "A0": 17, "B0": 27, "A1": 22, "B1": 23, "A2": 24,
        "B2": 25, "A3": 5, "B3": 6, "A4": 12,
    }
    payload = json.loads(CONFIG_PATH.read_text())
    assert all(str(v).startswith("GPIO") for v in payload["SBC"]["GPIO"].values())

    legacy = json.loads(CONFIG_PATH.read_text())
    legacy["SBC"]["GPIO"]["A0"] = 17          # bare BCM number still accepted
    assert VacuumConfig.model_validate(legacy).sbc.gpio["A0"] == 17

    for value, message in [
        ("GPIO0", "reserved for the HAT ID EEPROM"),
        ("GPIO1", "reserved for the HAT ID EEPROM"),
        ("GPIO28", "26 header GPIO lines"),
        ("pin 11", "Raspberry Pi GPIO name"),
        ("GPIO27", "both use GPIO27"),          # already used by B0
    ]:
        bad = json.loads(CONFIG_PATH.read_text())
        bad["SBC"]["GPIO"]["A0"] = value
        with pytest.raises(ValueError, match=message):
            VacuumConfig.model_validate(bad)


def test_raspberry_pi_header_table_has_26_lines_matching_the_emulator():
    from glasgow_service.emulation.raspberry_pi import BCM_TO_HEADER
    from glasgow_service.vacuum import RPI_HEADER_GPIO, rpi_gpio_name

    assert sorted(RPI_HEADER_GPIO) == list(range(2, 28))
    assert len(RPI_HEADER_GPIO) == 26
    for line, pin in RPI_HEADER_GPIO.items():
        assert BCM_TO_HEADER[line] == pin
    assert rpi_gpio_name(17) == "GPIO17 (pin 11)"


def test_disabled_vacuum_bypasses_controller_config_validation(tmp_path):
    disabled_config = tmp_path / "vacuum-disabled.json"
    disabled_config.write_text(json.dumps({"Enable": False}))

    assert vacuum_config_enabled(disabled_config) is False


@pytest.mark.parametrize(
    ("payload", "expected"),
    [
        ({"Enable": False}, False),
        ({"Enable": True}, True),
        ({}, True),
    ],
)
def test_vacuum_enable_flag_contract(tmp_path, payload, expected):
    config_path = tmp_path / "vacuum-toggle.json"
    config_path.write_text(json.dumps(payload))

    assert vacuum_config_enabled(config_path) is expected


def test_vacuum_enable_flag_ignores_misspelled_key(tmp_path):
    config_path = tmp_path / "vacuum-toggle-typo.json"
    config_path.write_text(json.dumps({"Enable": False, "Enalble": True}))

    assert vacuum_config_enabled(config_path) is False


def test_vacuum_enable_flag_rejects_non_boolean_values(tmp_path):
    config_path = tmp_path / "vacuum-invalid-toggle.json"
    config_path.write_text(json.dumps({"Enable": "false"}))

    with pytest.raises(ValueError, match="must be true or false"):
        vacuum_config_enabled(config_path)


def test_simulated_vacuum_cascade_and_stop():
    async def scenario():
        controller, commands = simulated_controller()
        await controller.start()
        try:
            assert controller.status().pumps[0].name == MECHANICAL_PUMP
            assert controller.status().control_transport == "sbc-simulation"
            assert controller.status().pumps[0].power is True
            assert controller.status().pumps[0].port_a_value == pytest.approx(3.3)
            assert controller.status().pumps[0].border == "waiting"
            assert controller.status().pumps[0].value is None
            assert controller.status().pumps[0].port_b_value == 0
            assert controller.gpio.output_level("A0") is True
            with pytest.raises(ValueError, match="requires the vacuum system to be ready"):
                await controller.set_high_voltage_power(True)
            await controller.poll_once()
            assert controller.status().pumps[0].value == pytest.approx(0.148)
            assert all(pump.value is None for pump in controller.status().pumps[1:])

            await controller.set_simulated_read("MechanicalVacuumPump", True)
            states = {pump.name: pump for pump in controller.status().pumps}
            assert states["MechanicalVacuumPump"].border == "ready"
            assert states["MechanicalVacuumPump"].port_b_value == pytest.approx(3.3)
            assert states["MechanicalVacuumPump"].value == states["MechanicalVacuumPump"].threshold
            assert states["TurboVacuumPump"].power is True
            assert states["TurboVacuumPump"].border == "waiting"

            await controller.set_simulated_read("MechanicalVacuumPump", False)
            mechanical = controller.status().pumps[0]
            assert mechanical.border == "waiting"
            assert mechanical.value is not None
            assert mechanical.port_b_value == 0
            assert mechanical.simulation_read is False
            await controller.set_simulated_read("MechanicalVacuumPump", True)

            await controller.set_simulated_read("TurboVacuumPump", True)
            states = {pump.name: pump for pump in controller.status().pumps}
            assert states["MechanicalVacuumPump"].ready is True
            assert states["TurboVacuumPump"].ready is True
            assert states["UHVacuumPump_1"].power is True
            assert states["UHVacuumPump_2"].power is True

            await controller.set_simulated_read("UHVacuumPump_1", True)
            await controller.set_simulated_read("UHVacuumPump_2", True)
            states = {pump.name: pump for pump in controller.status().pumps}
            assert states["UHVacuumPump_1"].value == states["UHVacuumPump_1"].threshold
            assert states["UHVacuumPump_2"].value == states["UHVacuumPump_2"].threshold
            assert states["UHVacuumPump_1"].port_b_value == pytest.approx(3.3)
            assert states["UHVacuumPump_2"].port_b_value == pytest.approx(3.3)
            assert states["UHVacuumPump_1"].ready is True
            assert states["UHVacuumPump_2"].ready is True
            assert controller.status().isVacuumSystemReady is True
            await controller.set_high_voltage_power(True)
            assert controller.status().high_voltage_power is True
            assert controller.gpio.output_level("A4") is True

            await controller.set_simulated_read("TurboVacuumPump", False)
            states = {pump.name: pump for pump in controller.status().pumps}
            assert states["MechanicalVacuumPump"].power is True
            assert states["MechanicalVacuumPump"].ready is True
            assert all(
                state.power is False
                and state.border == "off"
                and state.value is None
                and state.simulation_read is False
                for name, state in states.items()
                if name != MECHANICAL_PUMP
            )
            assert controller.status().cascade_stopped is True
            assert controller.status().isVacuumSystemReady is False
            assert controller.status().high_voltage_power is False
            assert controller.gpio.output_level("A4") is False
            assert controller.gpio.output_level("A0") is True
            assert (await controller.gpio.read_port_b())["B0"] == 1
        finally:
            await controller.close()

    asyncio.run(scenario())


def test_simulated_read_control_is_read_only_for_hardware():
    async def scenario():
        config = make_config(simulate=False)
        device = SimulatedVacuumDevice(
            (pump.write for pump in config.pumps),
            (pump.read for pump in config.pumps),
        )
        controller = VacuumController(config, device=device)
        with pytest.raises(ValueError, match="read-only"):
            await controller.set_simulated_read("MechanicalVacuumPump", True)

    asyncio.run(scenario())


def test_resume_cascade_advances_from_current_ready_state():
    async def scenario():
        controller, _commands = simulated_controller()
        await controller.start()
        try:
            await controller.set_simulated_read(MECHANICAL_PUMP, True)
            await controller.stop_non_mechanical()
            states = {pump.name: pump for pump in controller.status().pumps}
            assert controller.status().cascade_stopped is True
            assert states[MECHANICAL_PUMP].ready is True
            assert states["TurboVacuumPump"].power is False

            await controller.resume_cascade()
            states = {pump.name: pump for pump in controller.status().pumps}
            assert controller.status().cascade_stopped is False
            assert states["TurboVacuumPump"].power is True
        finally:
            await controller.close()

    asyncio.run(scenario())


def test_upstream_interlock_loss_deenergizes_downstream_stages():
    async def scenario():
        controller, _commands = simulated_controller()
        await controller.start()
        try:
            await controller.set_simulated_read(MECHANICAL_PUMP, True)
            await controller.set_simulated_read("TurboVacuumPump", True)
            states = {pump.name: pump for pump in controller.status().pumps}
            assert states["TurboVacuumPump"].power is True
            assert states["UHVacuumPump_1"].power is True
            assert states["UHVacuumPump_2"].power is True

            await controller.set_simulated_read("TurboVacuumPump", False)
            states = {pump.name: pump for pump in controller.status().pumps}
            assert states["TurboVacuumPump"].power is False
            assert states["UHVacuumPump_1"].power is False
            assert states["UHVacuumPump_2"].power is False

            await controller.resume_cascade()
            await controller.set_simulated_read(MECHANICAL_PUMP, False)
            states = {pump.name: pump for pump in controller.status().pumps}
            assert states[MECHANICAL_PUMP].power is True
            assert states["TurboVacuumPump"].power is False
        finally:
            await controller.close()

    asyncio.run(scenario())


def test_cascade_stages_follow_group_name_not_equipment_names():
    """Regrouping in JSON alone turns the UH pair into two sequential stages."""
    payload = json.loads(CONFIG_PATH.read_text())
    payload["VacuumPumps"][2]["groupName"] = "UltraHighVacuumStage1"
    payload["VacuumPumps"][3]["groupName"] = "UltraHighVacuumStage2"
    config = VacuumConfig.model_validate(payload).model_copy(
        update={"enabled": True, "error_range": 0.005, "simulate": True})

    async def scenario():
        controller = VacuumController(config)
        await controller.start()
        try:
            await controller.set_simulated_read(MECHANICAL_PUMP, True)
            await controller.set_simulated_read("TurboVacuumPump", True)
            states = {pump.name: pump for pump in controller.status().pumps}
            assert states["UHVacuumPump_1"].power is True
            assert states["UHVacuumPump_2"].power is False      # waits for stage 1
            assert states["UHVacuumPump_1"].group == "UltraHighVacuumStage1"

            await controller.set_simulated_read("UHVacuumPump_1", True)
            states = {pump.name: pump for pump in controller.status().pumps}
            assert states["UHVacuumPump_2"].power is True

            # Losing stage 1 drops stage 2 only; turbo keeps running.
            await controller.set_simulated_read("UHVacuumPump_1", False)
            states = {pump.name: pump for pump in controller.status().pumps}
            assert states["TurboVacuumPump"].power is True
            assert states["UHVacuumPump_1"].power is False
            assert states["UHVacuumPump_2"].power is False
        finally:
            await controller.close()

    asyncio.run(scenario())


def test_mechanical_pump_cannot_be_turned_off():
    async def scenario():
        controller, _commands = simulated_controller()
        await controller.start()
        try:
            assert controller.status().pumps[0].power is True
            with pytest.raises(ValueError, match="must remain powered on"):
                await controller.set_power(MECHANICAL_PUMP, False)
        finally:
            await controller.close()

    asyncio.run(scenario())


def test_manual_power_on_resumes_downstream_cascade_progression():
    async def scenario():
        controller, _commands = simulated_controller()
        await controller.start()
        try:
            await controller.set_simulated_read(MECHANICAL_PUMP, True)
            states = {pump.name: pump for pump in controller.status().pumps}
            assert states["TurboVacuumPump"].power is True

            # Reproduce an operator-stopped controller whose upstream pump is
            # already powered. Re-engaging it must clear the latch.
            controller._cascade_stopped = True
            await controller.set_power("TurboVacuumPump", True)
            assert controller.status().cascade_stopped is False

            await controller.set_simulated_read("TurboVacuumPump", True)
            states = {pump.name: pump for pump in controller.status().pumps}
            assert states["UHVacuumPump_1"].power is True
            assert states["UHVacuumPump_2"].power is True
        finally:
            await controller.close()

    asyncio.run(scenario())


def test_reacquire_resets_simulated_cascade_to_initial_state():
    async def scenario():
        controller, _commands = simulated_controller()
        await controller.start()
        await controller.set_simulated_read("MechanicalVacuumPump", True)
        await controller.set_simulated_read("TurboVacuumPump", True)
        await controller.set_simulated_read("UHVacuumPump_1", True)
        await controller.set_simulated_read("UHVacuumPump_2", True)
        await controller.close()

        await controller.start()
        try:
            states = {pump.name: pump for pump in controller.status().pumps}
            mechanical = states[MECHANICAL_PUMP]
            assert mechanical.power is True
            assert mechanical.border == "waiting"
            assert mechanical.value is None
            assert mechanical.port_b_value == 0
            assert mechanical.simulation_read is False
            assert all(
                state.power is False
                and state.border == "off"
                and state.value is None
                and state.simulation_read is False
                for name, state in states.items()
                if name != MECHANICAL_PUMP
            )
        finally:
            await controller.close()

    asyncio.run(scenario())


def test_simulated_comparator_goes_high_when_analog_value_reaches_tolerance():
    async def scenario():
        controller, commands = simulated_controller()
        await controller.start()
        try:
            for _ in range(55):
                await controller.poll_once()
            mechanical = controller.status().pumps[0]
            assert mechanical.value == pytest.approx(mechanical.threshold)
            assert mechanical.port_b_value == pytest.approx(3.3)
            assert mechanical.ready is True
            assert mechanical.border == "ready"
            assert controller.status().pumps[1].power is True
            assert controller.config.error_range == pytest.approx(0.005)
            assert (await controller.gpio.read_port_b())["B0"] == 1
        finally:
            await controller.close()

    asyncio.run(scenario())


def test_vacuum_system_ready_requires_every_configured_port_b_pin_high():
    controller, _commands = simulated_controller()

    assert controller.isVacuumSystemReady is False
    assert controller.status().isVacuumSystemReady is False
    for state in controller._states.values():
        state.port_b_value = controller.config.device.voltage
    # Fabricated or previous readings cannot make an unstarted controller ready.
    assert controller.isVacuumSystemReady is False

    async def scenario():
        await controller.start()
        try:
            for name in controller._states:
                await controller.set_simulated_read(name, True)
            assert controller.isVacuumSystemReady is True
            assert controller.status().isVacuumSystemReady is True
            controller._states[MECHANICAL_PUMP].port_b_value = 0
            assert controller.status().isVacuumSystemReady is False
        finally:
            await controller.close()

    asyncio.run(scenario())


def test_simulation_maps_port_a_equipment_values_to_configured_gpio_voltage():
    async def scenario():
        controller, commands = simulated_controller()

        await controller.gpio.write("A0", True)
        await controller.gpio.write("A1", True)

        assert isinstance(controller.gpio, SimulatedVacuumDevice)
        assert isinstance(controller.gpio, VacuumDevice)
        assert controller.gpio.output_level("A0") is True
        assert controller.gpio.output_level("A1") is True

    asyncio.run(scenario())


def test_port_b_levels_are_reported_as_configured_pin_voltage():
    async def scenario():
        config = make_config(simulate=False)
        device = SimulatedVacuumDevice(
            [*(pump.write for pump in config.pumps), config.high_voltage_transformer.write],
            (pump.read for pump in config.pumps),
        )
        controller = VacuumController(config, device=device)

        async def fake_read_port_b() -> dict[str, int]:
            return {"B0": 1, "B1": 0, "B2": 1, "B3": 0}

        controller.gpio.read_port_b = fake_read_port_b
        await controller.start()
        await controller.poll_once()
        states = {state.read: state for state in controller.status().pumps}
        await controller.close()

        assert states["B0"].port_b_value == pytest.approx(config.device.voltage)
        assert states["B1"].port_b_value == 0.0
        assert states["B2"].port_b_value == pytest.approx(config.device.voltage)
        assert states["B3"].port_b_value == 0.0
        assert controller.status().isVacuumSystemReady is False

    asyncio.run(scenario())


def test_numeric_gauge_values_flow_from_sbc_device_into_status():
    async def scenario():
        config = make_config(simulate=False)
        device = SimulatedVacuumDevice(
            [*(pump.write for pump in config.pumps), config.high_voltage_transformer.write],
            (pump.read for pump in config.pumps),
        )
        controller = VacuumController(config, device=device)

        async def fake_read_gauges() -> dict[str, float | None]:
            return {"B0": 8.5e-2, "B1": 1.7e-3, "B2": 2.8e-5, "B3": None}

        controller.gpio.read_gauge_values = fake_read_gauges
        await controller.start()
        await controller.poll_once()
        states = {state.read: state for state in controller.status().pumps}
        await controller.close()

        assert states["B0"].value == pytest.approx(8.5e-2)
        assert states["B1"].value == pytest.approx(1.7e-3)
        assert states["B2"].value == pytest.approx(2.8e-5)
        assert states["B3"].value is None

    asyncio.run(scenario())


def test_port_b_read_failure_clears_stale_voltage_and_readiness():
    async def scenario():
        config = make_config(simulate=False)
        device = SimulatedVacuumDevice(
            (pump.write for pump in config.pumps),
            (pump.read for pump in config.pumps),
        )
        controller = VacuumController(config, device=device)
        for state in controller._states.values():
            state.power = True
            state.port_b_value = config.device.voltage
            state.ready = True
            await device.write(state.write, True)

        async def failed_read_port_b() -> dict[str, int]:
            raise RuntimeError("GPIO read failed")

        controller.gpio.read_port_b = failed_read_port_b
        await controller.poll_once()

        assert controller.status().isVacuumSystemReady is False
        assert all(state.port_b_value == 0.0 for state in controller.status().pumps)
        assert all(state.ready is False for state in controller.status().pumps)
        assert controller.status().cascade_stopped is True
        assert device.output_level("A0") is True
        assert all(device.output_level(pin) is False for pin in ("A1", "A2", "A3"))

    asyncio.run(scenario())


def test_direct_gpio_pump_is_ready_only_when_its_reading_reaches_threshold():
    """With a gauge adapter, a high ready input is not enough on its own."""
    config = make_config(simulate=False)
    readings = {pump.read: None for pump in config.pumps}

    class GaugedDevice(SimulatedVacuumDevice):
        async def read_gauge_values(self):
            return dict(readings)

        async def read_port_b(self):
            return {pin: 1 for pin in readings}

    device = GaugedDevice(
        [*(p.write for p in config.pumps), config.high_voltage_transformer.write],
        (p.read for p in config.pumps))
    controller = VacuumController(config, device=device)

    async def scenario():
        await controller.start()
        mechanical = next(p for p in config.pumps if p.name == MECHANICAL_PUMP)
        readings[mechanical.read] = mechanical.threshold * 5       # not reached
        await controller.poll_once()
        state = controller.status().pumps[0]
        assert state.ready is False and state.border == "waiting"
        assert controller.status().pumps[1].power is False

        readings[mechanical.read] = mechanical.threshold * 0.2     # reached
        await controller.poll_once()
        state = controller.status().pumps[0]
        assert state.ready is True and state.border == "ready"
        assert controller.status().pumps[1].power is True
        await controller.close()

    asyncio.run(scenario())


@pytest.mark.parametrize(("factor", "ready"), [
    (1.0, True),        # exact match
    (0.5, True),        # lower (better vacuum)
    (1.005, False),     # above, even though within errorRange
    (1.01, False),
])
def test_pump_turns_green_only_on_exact_match_or_lower(factor, ready):
    config = make_config(simulate=False, error_range=0.01)
    readings = {pump.read: None for pump in config.pumps}

    class GaugedDevice(SimulatedVacuumDevice):
        async def read_gauge_values(self):
            return dict(readings)

        async def read_port_b(self):
            return {pin: 1 for pin in readings}

    device = GaugedDevice(
        [*(p.write for p in config.pumps), config.high_voltage_transformer.write],
        (p.read for p in config.pumps))
    controller = VacuumController(config, device=device)

    async def scenario():
        await controller.start()
        mechanical = next(p for p in config.pumps if p.name == MECHANICAL_PUMP)
        readings[mechanical.read] = mechanical.threshold * factor
        await controller.poll_once()
        state = controller.status().pumps[0]
        assert state.ready is ready
        assert state.border == ("ready" if ready else "waiting")
        await controller.close()

    asyncio.run(scenario())


@pytest.mark.parametrize("profile", LIVE_PROFILES, ids=lambda path: path.name)
def test_live_vacuum_profiles_are_valid(profile):
    config = VacuumConfig.model_validate(json.loads(profile.read_text()))
    assert config.pumps[0].name == MECHANICAL_PUMP
    assert len(config.stages) >= 2
